import { createFinding, createPhase } from "../../core/result.js";
import type { Finding, InspectorPhase } from "../../core/schema.js";
import { getZodEnumValues } from "../_shared/ast-schema-queries.js";
import { hasCallExpression, hasCallExpressionPath } from "../_shared/ast-helpers.js";
import { getSource } from "./audit-project.js";
import { isThinAbilityGroup } from "./ability-group-shape.js";
import { missingCanonicalFiles } from "./canonical-files.js";
import { CHILDREN, ROOT } from "./constants.js";
import type { Project } from "ts-morph";

const inspectMissingCanonicalFiles = async (): Promise<Finding[]> => {
  const missingFiles = await missingCanonicalFiles();
  return missingFiles.map((file) =>
    createFinding({ lawId: "GRASSEYE-PAGE-STATE-CAPABILITY-004-V1", file, line: 1, severity: "fatal", message: "Required page-state canonical file is missing." }),
  );
};

const inspectAbilityGroupShape = (project: Project): Finding[] => {
  const abilityGroupSource = getSource(project, `${ROOT}/ability-group.ts`);
  return isThinAbilityGroup(abilityGroupSource)
    ? []
    : [createFinding({ lawId: "GRASSEYE-PAGE-STATE-CAPABILITY-001-V1", file: `${ROOT}/ability-group.ts`, line: 1, severity: "fatal", message: "Page State ability-group must stay a thin entrypoint." })];
};

const inspectContractShape = (project: Project): Finding[] => {
  const contractSource = getSource(project, `${ROOT}/contract.ts`);
  return contractSource.getInterface("PageStateChildCapability")
    ? [createFinding({ lawId: "GRASSEYE-PAGE-STATE-CAPABILITY-001-V1", file: `${ROOT}/contract.ts`, line: 1, severity: "fatal", message: "Page State contract must not expose child execute interface." })]
    : [];
};

const inspectSchemaShape = (project: Project): Finding[] => {
  const findings: Finding[] = [];
  const schemaSource = getSource(project, `${ROOT}/schema.ts`);
  const childIds = getZodEnumValues(schemaSource, "PageStateChildCapabilityIdSchema");

  if (childIds.sort().join(",") !== [...CHILDREN].sort().join(",")) {
    findings.push(createFinding({ lawId: "GRASSEYE-PAGE-STATE-CAPABILITY-003-V1", file: `${ROOT}/schema.ts`, line: 1, severity: "fatal", message: "Page State schema child ids must match the frozen child registry." }));
  }
  if (!hasCallExpressionPath(schemaSource, ["PageStateAbilityInputSchema", "extend"]) || !schemaSource.getVariableDeclaration("PageStateOutputSchema")) {
    findings.push(createFinding({ lawId: "GRASSEYE-PAGE-STATE-CAPABILITY-003-V1", file: `${ROOT}/schema.ts`, line: 1, severity: "fatal", message: "Page State schema must expose governed input/output shapes." }));
  }

  return findings;
};

const EXECUTION_ROUTE_SOURCES = {
  gatePageStateInput: `${ROOT}/runtime/page-state-preflight.ts`,
  gatePageStatePayloadBudget: `${ROOT}/runtime/page-state-preflight.ts`,
  gateObservationSources: `${ROOT}/runtime/page-state-preflight.ts`,
  gateObservationProofBinding: `${ROOT}/runtime/page-state-preflight.ts`,
  gateSnapshotFreshness: `${ROOT}/runtime/page-state-preflight.ts`,
  gatePlatformProfile: `${ROOT}/runtime/page-state-preflight.ts`,
  classifyPageState: `${ROOT}/runtime/page-state-success-result.ts`,
  decideProceed: `${ROOT}/runtime/page-state-success-result.ts`,
  createPageStateFingerprint: `${ROOT}/runtime/page-state-success-result.ts`,
  buildPageStateRuntimeProof: `${ROOT}/runtime/page-state-success-result.ts`,
  buildPageStateResult: `${ROOT}/runtime/page-state-success-result.ts`,
} as const;

function inspectExecutorEntry(project: Project): Finding[] {
  const executorSource = getSource(project, `${ROOT}/runtime/page-state-executor.ts`);
  const executorRoutes = [
    { callee: "runPageStatePreflight", message: "Page State executor must route through runPageStatePreflight." },
    { callee: "buildPageStateSuccessResult", message: "Page State executor must route through buildPageStateSuccessResult." },
  ] as const;

  return executorRoutes.flatMap((route) =>
    hasCallExpression(executorSource, route.callee)
      ? []
      : [createFinding({ lawId: "GRASSEYE-PAGE-STATE-CAPABILITY-002-V1", file: `${ROOT}/runtime/page-state-executor.ts`, line: 1, severity: "fatal", message: route.message })],
  );
}

const inspectExecutorShape = (project: Project): Finding[] => {
  const routeFindings = Object.entries(EXECUTION_ROUTE_SOURCES).flatMap(([callee, file]) => {
    const source = getSource(project, file);
    return hasCallExpression(source, callee)
      ? []
      : [createFinding({ lawId: "GRASSEYE-PAGE-STATE-CAPABILITY-002-V1", file, line: 1, severity: "fatal", message: `Page State execution chain must route through ${callee}.` })];
  });

  return [...inspectExecutorEntry(project), ...routeFindings];
};

const inspectBuilderSchemaParsing = (project: Project): Finding[] => {
  const proofBuilder = getSource(project, `${ROOT}/runtime/page-state-proof-builder.ts`);
  const resultBuilder = getSource(project, `${ROOT}/runtime/page-state-result-builder.ts`);
  const dispatchFailure = getSource(project, `${ROOT}/runtime/page-state-dispatch-failure.ts`);
  const findings: Finding[] = [];

  if (!hasCallExpressionPath(proofBuilder, ["PageStateRuntimeProofSchema", "parse"])) {
    findings.push(createFinding({ lawId: "GRASSEYE-PAGE-STATE-CAPABILITY-004-V1", file: `${ROOT}/runtime/page-state-proof-builder.ts`, line: 1, severity: "fatal", message: "Page State proof builder must parse its public proof schema." }));
  }
  if (!hasCallExpressionPath(resultBuilder, ["PageStateAbilityResultSchema", "parse"])) {
    findings.push(createFinding({ lawId: "GRASSEYE-PAGE-STATE-CAPABILITY-003-V1", file: `${ROOT}/runtime/page-state-result-builder.ts`, line: 1, severity: "fatal", message: "Page State result builder must parse its public result schema." }));
  }
  if (!hasCallExpressionPath(dispatchFailure, ["PageStateAbilityResultSchema", "parse"])) {
    findings.push(createFinding({ lawId: "GRASSEYE-PAGE-STATE-CAPABILITY-003-V1", file: `${ROOT}/runtime/page-state-dispatch-failure.ts`, line: 1, severity: "fatal", message: "Invalid input failure must terminate as a governed result envelope." }));
  }

  return findings;
};

export async function runRequiredShape(project: Project): Promise<{ findings: Finding[]; phase: InspectorPhase }> {
  const findings = [
    ...(await inspectMissingCanonicalFiles()),
    ...inspectAbilityGroupShape(project),
    ...inspectContractShape(project),
    ...inspectSchemaShape(project),
    ...inspectExecutorShape(project),
    ...inspectBuilderSchemaParsing(project),
  ];

  const phasePassed = findings.length === 0;
  return {
    findings,
    phase: createPhase("page-state-required-shape", phasePassed ? "PASS" : "CODE VIOLATION", phasePassed, phasePassed ? "Page State canonical package shape is present." : "Page State canonical package shape is incomplete."),
  };
}