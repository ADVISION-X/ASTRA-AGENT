import type { InspectorContext, InspectorResult } from "../../core/schema.js";
import { finalizeInspectorResult } from "../../core/result.js";
import { runDomainOwnerInspection } from "../_shared/owner-foundation-inspection.js";
import { createPageStateAuditProject } from "./audit-project.js";
import { runAntiEscape } from "./anti-escape.js";
import { runBoundaryAttack } from "./boundary-attack.js";
import { runEnforcementCoverage } from "./enforcement-coverage.js";
import { runForbiddenShape } from "./forbidden-shape.js";
import { runNegativeProofHarness } from "./negative-proof-harness.js";
import { runRequiredShape } from "./required-shape.js";

const SKIP_NEGATIVE_PROOF_ENV = "GRASSEYE_SKIP_PAGE_STATE_NEGATIVE_PROOF";

export async function inspectPageStateCapability(context: InspectorContext): Promise<InspectorResult> {
  const base = await runDomainOwnerInspection(context, {
    capabilityDomain: "page-state-capability",
    inspectorId: "page-state-capability-owner",
    inspectorEntry: "scripts/audit/domains/page-state-capability/inspector.ts",
  });
  const project = createPageStateAuditProject();
  const required = await runRequiredShape(project);
  const forbidden = await runForbiddenShape(project);
  const boundary = await runBoundaryAttack(project);
  const antiEscape = await runAntiEscape(project);
  const enforcementCoverage = await runEnforcementCoverage(context);
  const negativeProof = process.env[SKIP_NEGATIVE_PROOF_ENV] === "1"
    ? {
        findings: [],
        phase: {
          name: "negative-proof-harness",
          classification: "PASS" as const,
          passed: true,
          summary: "Page State negative-proof harness was skipped for nested inspector execution.",
        },
      }
    : await runNegativeProofHarness();
  const findings = [
    ...base.findings,
    ...required.findings,
    ...forbidden.findings,
    ...boundary.findings,
    ...antiEscape.findings,
    ...enforcementCoverage.findings,
    ...negativeProof.findings,
  ];
  const phases = [...base.phases, required.phase, forbidden.phase, boundary.phase, antiEscape.phase, enforcementCoverage.phase, negativeProof.phase];

  return finalizeInspectorResult({
    inspector: "GrassEye Page State Capability Owner Inspector",
    inspectorId: "page-state-capability-owner",
    capabilityDomain: "page-state-capability",
    findings,
    phases,
    summary: findings.length === 0
      ? "page-state owner inspector passed required, forbidden, boundary, anti-escape, enforcement-coverage, and negative-proof phases"
      : "page-state owner inspector found capability-boundary, enforcement, or governance violations",
  });
}
