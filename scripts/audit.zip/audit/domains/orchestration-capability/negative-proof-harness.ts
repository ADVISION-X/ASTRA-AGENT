import { buildAuditArtifacts } from "../../build-audit-artifacts.js";
import { pathFromRepoRoot } from "../../core/paths.js";
import { createFinding, createPhase } from "../../core/result.js";
import type { Finding, InspectorPhase } from "../../core/schema.js";
import { createInspectorContext, loadGeneratedArtifacts, loadInspector } from "../../core/runtime.js";
import { applyAuditMutation, readAuditFileState, restoreAuditFileState } from "../_shared/read-audit-file-state.js";

type Mutation = {
  name: string;
  file: string;
  search: string;
  replace: string;
};

const INSPECTOR_ENTRY = "scripts/audit/domains/orchestration-capability/inspector.ts";
const SKIP_NEGATIVE_PROOF_ENV = "GRASSEYE_SKIP_ORCHESTRATION_NEGATIVE_PROOF";

const MUTATIONS: Mutation[] = [
  {
    name: "governed execute type escape mutation",
    file: "src/capabilities/orchestration/contract.ts",
    search: "execute(input: OrchestrationExecuteInput): Promise<OrchestrationExecuteResult>;",
    replace: "execute(input: OrchestrationExecuteInput): Promise<unknown>;",
  },
  {
    name: "floating active map resume mutation",
    file: "src/capabilities/orchestration/runtime/orchestration-executor-resume.ts",
    search: "const mapRecord = await resolveFrozenActivationMapRecord(input.context.mapStore, state);",
    replace: "const mapRecord = await input.context.mapStore.getActiveMapRecord(state.mapId);",
  },
  {
    name: "unknown child proof drop mutation",
    file: "src/capabilities/orchestration/runtime/orchestration-child-runner.ts",
    search: "dataQualityFlags: [\"unknown_child_capability\"],",
    replace: "runtimeProof: null,\n      dataQualityFlags: [\"unknown_child_capability\"],",
  },
  {
    name: "post-action verification gate bypass mutation",
    file: "src/capabilities/orchestration/runtime/step-dispatcher.ts",
    search: "const postActionVerificationReason = ensurePostActionVerificationDispatchGate(input.map, input.step.stepId);",
    replace: "const postActionVerificationReason = null;",
  },
];

async function runInspector(): Promise<{ passed: boolean; violationCount: number }> {
  const previous = process.env[SKIP_NEGATIVE_PROOF_ENV];
  process.env[SKIP_NEGATIVE_PROOF_ENV] = "1";

  try {
    await buildAuditArtifacts();
    const artifacts = await loadGeneratedArtifacts();
    const context = await createInspectorContext(artifacts);
    const inspector = await loadInspector(INSPECTOR_ENTRY);
    const result = await inspector(context);
    return { passed: result.passed, violationCount: result.violationCount };
  } finally {
    if (previous === undefined) {
      delete process.env[SKIP_NEGATIVE_PROOF_ENV];
    } else {
      process.env[SKIP_NEGATIVE_PROOF_ENV] = previous;
    }
  }
}

async function mutateAndVerify(mutation: Mutation): Promise<void> {
  const filePath = pathFromRepoRoot(mutation.file);
  const state = await readAuditFileState(filePath);
  await applyAuditMutation(filePath, state.original, mutation);

  try {
    const result = await runInspector();
    if (result.passed || result.violationCount === 0) {
      throw new Error(`Inspector did not fail for ${mutation.name}`);
    }
  } finally {
    await restoreAuditFileState(filePath, state);
  }

  const restored = await runInspector();
  if (!restored.passed) {
    throw new Error(`Rollback verification failed for ${mutation.name}`);
  }
}

function createPassResult(summary: string): { findings: Finding[]; phase: InspectorPhase } {
  return {
    findings: [],
    phase: createPhase("negative-proof-harness", "PASS", true, summary),
  };
}

function createFatalResult(message: string, summary: string): { findings: Finding[]; phase: InspectorPhase } {
  return {
    findings: [
      createFinding({
        lawId: "GRASSEYE-ORCHESTRATION-CAPABILITY-004-V1",
        file: INSPECTOR_ENTRY,
        line: 1,
        severity: "fatal",
        message,
      }),
    ],
    phase: createPhase("negative-proof-harness", "FAKE ENFORCEMENT", false, summary),
  };
}

async function runMutations(): Promise<void> {
  for (const mutation of MUTATIONS) {
    await mutateAndVerify(mutation);
  }
}

export async function runNegativeProofHarness(): Promise<{ findings: Finding[]; phase: InspectorPhase }> {
  try {
    const baseline = await runInspector();
    if (!baseline.passed) {
      return createFatalResult(
        "Orchestration inspector baseline must pass before negative-proof mutation checks.",
        "Orchestration negative-proof harness cannot start because the baseline inspector is not passing.",
      );
    }

    await runMutations();

    return createPassResult("Orchestration negative-proof harness rejects execute-type escape, floating resume map lookup, unknown-child proof drop, and post-action verification bypass mutations.");
  } catch (error) {
    return createFatalResult(
      error instanceof Error ? error.message : "Orchestration negative-proof harness failed.",
      "Orchestration negative-proof harness failed to prove mutation rejection and rollback recovery.",
    );
  }
}