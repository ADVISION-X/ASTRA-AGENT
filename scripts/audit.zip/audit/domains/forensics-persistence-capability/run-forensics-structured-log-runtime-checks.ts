import { pathFromRepoRoot } from "../../core/paths.js";

import { createFinding } from "../../core/result.js";
import type { Finding } from "../../core/schema.js";
import { hasStringLiteral } from "../_shared/ast-literal-queries.js";
import { getSourceFileOrThrow, hasPropertyAccessPath } from "../_shared/ast-helpers.js";

import { forensicsPersistenceInspectionConstants } from "./inspection-constants.js";

const {
  AI_DEBUG_RECORDER_PATH,
  AI_RUNTIME_ADAPTER_PATH,
  COMMAND_HANDLER_PATH,
  COMMAND_FLOW_RESULT_PATH,
  COMMANDER_DEBUG_PATH,
  LAW_STRUCTURED_LOGGING_COMMAND_FLOW,
  LAW_STRUCTURED_LOGGING_DISCIPLINE,
  LAW_STRUCTURED_LOGGING_EXIT,
  LAW_STRUCTURED_LOGGING_HEALTH,
  STARTUP_ENTRYPOINT_PATH,
  STATUS_PATH,
} = forensicsPersistenceInspectionConstants;

const getStartupSource = (project: import("ts-morph").Project) => {
  const startupPath = pathFromRepoRoot(STARTUP_ENTRYPOINT_PATH);
  return project.addSourceFileAtPathIfExists(startupPath) ?? project.addSourceFileAtPath(startupPath);
};

const collectAiRuntimeWiringFindings = (project: import("ts-morph").Project): Finding[] => {
  const aiDebugRecorderSource = getSourceFileOrThrow(project, AI_DEBUG_RECORDER_PATH);
  const aiRuntimeDebugSource = getSourceFileOrThrow(project, AI_RUNTIME_ADAPTER_PATH);
  const commanderDebugSource = getSourceFileOrThrow(project, COMMANDER_DEBUG_PATH);
  const findings: Finding[] = [];

  if (!hasStringLiteral(aiRuntimeDebugSource, "AI_REQUEST_DEBUG") || !hasStringLiteral(aiRuntimeDebugSource, "AI_RESPONSE_DEBUG") || !hasStringLiteral(aiRuntimeDebugSource, "AI_ERROR_DEBUG")) {
    findings.push(createFinding({ lawId: LAW_STRUCTURED_LOGGING_DISCIPLINE, file: AI_RUNTIME_ADAPTER_PATH, line: 1, severity: "fatal", message: "Structured logging discipline is not wired through the AI runtime and Forensics write path." }));
  }
  if (!hasPropertyAccessPath(aiDebugRecorderSource, ["runtime", "forensicsPersistenceAbilityGroup", "writeStructuredRuntimeEvent"])) {
    findings.push(createFinding({ lawId: LAW_STRUCTURED_LOGGING_DISCIPLINE, file: AI_DEBUG_RECORDER_PATH, line: 1, severity: "fatal", message: "AI debug event persistence must flow through Forensics Persistence structured runtime events." }));
  }
  if (!hasPropertyAccessPath(commanderDebugSource, ["runtime", "forensicsPersistenceAbilityGroup", "writeStructuredRuntimeEvent"])) {
    findings.push(createFinding({ lawId: LAW_STRUCTURED_LOGGING_DISCIPLINE, file: COMMANDER_DEBUG_PATH, line: 1, severity: "fatal", message: "Workbench debug event relays must persist structured runtime events through Forensics Persistence." }));
  }

  return findings;
};

const collectCommandFlowFinding = (project: import("ts-morph").Project): Finding[] => {
  const commandFlowSources = [
    getSourceFileOrThrow(project, COMMAND_HANDLER_PATH),
    getSourceFileOrThrow(project, COMMAND_FLOW_RESULT_PATH),
  ];
  const missingCommandFlowEvents = [
    "HUMAN_COMMAND_DRAFTED",
    "HUMAN_COMMAND_RECEIVED",
    "HUMAN_COMMAND_VALIDATED",
    "MISSION_PREFLIGHT_STARTED",
    "MISSION_PREFLIGHT_PASSED",
    "MISSION_PREFLIGHT_FAILED",
    "COMMAND_ACCEPTED",
    "COMMAND_REJECTED",
  ].filter((eventType) => !commandFlowSources.some((source) => hasStringLiteral(source, eventType)));

  return missingCommandFlowEvents.length > 0
    ? [createFinding({ lawId: LAW_STRUCTURED_LOGGING_COMMAND_FLOW, file: COMMAND_HANDLER_PATH, line: 1, severity: "error", message: "Commander command flow is missing required structured debug events.", detail: missingCommandFlowEvents.join(", ") })]
    : [];
};

const hasStartupHealthSignals = (startupSource: import("ts-morph").SourceFile): boolean => {
  return hasStringLiteral(startupSource, "APP_SHELL_HEALTH_CHECK_STARTED")
    && hasStringLiteral(startupSource, "APP_SHELL_HEALTH_PASSED")
    && hasStringLiteral(startupSource, "MISSION_READINESS_CHECK_STARTED")
    && hasStringLiteral(startupSource, "MISSION_READINESS_PASSED")
    && hasStringLiteral(startupSource, "MISSION_READINESS_DEGRADED");
};

const collectHealthFinding = (project: import("ts-morph").Project): Finding[] => {
  const statusSource = getSourceFileOrThrow(project, STATUS_PATH);
  const commandFlowSource = getSourceFileOrThrow(project, COMMAND_HANDLER_PATH);
  const startupSource = getStartupSource(project);
  const healthWired = hasStringLiteral(statusSource, "app-shell-health")
    && hasStringLiteral(statusSource, "mission-readiness")
    && hasStartupHealthSignals(startupSource)
    && hasStringLiteral(commandFlowSource, "LOCAL_AI_READINESS_DEGRADED");

  return healthWired
    ? []
    : [createFinding({ lawId: LAW_STRUCTURED_LOGGING_HEALTH, file: STARTUP_ENTRYPOINT_PATH, line: 1, severity: "error", message: "AppShellHealth and MissionReadiness structured logging is not fully wired across startup and mission preflight surfaces." })];
};

const collectExitFinding = (project: import("ts-morph").Project): Finding[] => {
  const startupSource = getStartupSource(project);
  const exitWired = hasStringLiteral(startupSource, "SERVICE_STOP_REQUESTED")
    && hasStringLiteral(startupSource, "SERVICE_SHUTDOWN_COMPLETED")
    && hasStringLiteral(startupSource, "SERVICE_UNEXPECTED_EXIT")
    && hasStringLiteral(startupSource, "SERVICE_EXIT_CLASSIFICATION");

  return exitWired
    ? []
    : [createFinding({ lawId: LAW_STRUCTURED_LOGGING_EXIT, file: STARTUP_ENTRYPOINT_PATH, line: 1, severity: "error", message: "Service shutdown and unexpected-exit structured logging is missing required event classifications or persisted fields." })];
};

export function runForensicsStructuredLogRuntimeChecks(project: import("ts-morph").Project): Finding[] {
  return [
    ...collectAiRuntimeWiringFindings(project),
    ...collectCommandFlowFinding(project),
    ...collectHealthFinding(project),
    ...collectExitFinding(project),
  ];
}