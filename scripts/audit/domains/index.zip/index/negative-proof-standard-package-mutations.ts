import type { Mutation } from "./negative-proof-types.js";
import { indexDeleteRebuildMutations } from "./negative-proof-delete-rebuild-mutations.js";
import { indexStandardPackageFoundationMutations } from "./negative-proof-standard-package-foundation-mutations.js";
import { indexStandardPackagePrincipleMutations } from "./negative-proof-standard-package-principle-mutations.js";

export const indexStandardPackageMutations: Mutation[] = [
  ...indexStandardPackageFoundationMutations,
  ...indexStandardPackagePrincipleMutations,
  ...indexDeleteRebuildMutations,
];
