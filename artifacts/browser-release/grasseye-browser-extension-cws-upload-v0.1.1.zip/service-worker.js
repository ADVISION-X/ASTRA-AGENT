// src/lib/browser/transport/command-permit.ts
var browserCommandPermitMacPayload = (permit) => JSON.stringify([
  permit.permitRef,
  permit.authorityRef,
  permit.authorityEpoch,
  permit.certificateHash,
  permit.activationTupleHash,
  permit.executionBindingHash,
  permit.targetLeaseRef,
  permit.targetRef,
  permit.documentRef,
  permit.capabilityId,
  permit.commandId,
  permit.sequence,
  permit.mutationClass,
  permit.deadlineAt,
  permit.replyChannelToken
]);

// src/lib/browser/chrome-extension/command-permit-validator.ts
var currentAuthority = null;
var setExtensionPermitAuthority = (context) => {
  currentAuthority = context;
};
var clearExtensionPermitAuthority = () => {
  currentAuthority = null;
};
var hasRequiredPermitReferences = (permit) => [
  permit.permitRef,
  permit.authorityRef,
  permit.targetLeaseRef,
  permit.targetRef,
  permit.documentRef,
  permit.capabilityId,
  permit.commandId,
  permit.replyChannelToken
].every(Boolean);
var hasValidPermitMetadata = (permit) => permit.authorityEpoch >= 1 && Number.isInteger(permit.sequence) && permit.sequence >= 1 && Date.parse(permit.deadlineAt) > Date.now() && isHash(permit.certificateHash) && isHash(permit.activationTupleHash) && isHash(permit.executionBindingHash) && isHash(permit.commandFrameMac);
var hasValidPermitShape = (permit) => hasRequiredPermitReferences(permit) && hasValidPermitMetadata(permit);
var matchesPermitAuthority = (permit, authority) => permit.authorityRef === authority.authorityRef && permit.authorityEpoch === authority.authorityEpoch && permit.certificateHash === authority.certificateHash && permit.activationTupleHash === authority.activationTupleHash && permit.executionBindingHash === authority.executionBindingHash;
async function assertExtensionCommandPermit(permit) {
  if (!hasValidPermitShape(permit)) {
    throw new Error("BROWSER_COMMAND_PERMIT_INVALID");
  }
  const authority = currentAuthority;
  if (!authority || !matchesPermitAuthority(permit, authority) || !await hasValidPermitMac(permit, authority.commandPermitKey)) {
    throw new Error("BROWSER_COMMAND_PERMIT_INVALID");
  }
}
var isHash = (value) => /^sha256:[a-f0-9]{64}$/u.test(value);
var hasValidPermitMac = async (permit, commandPermitKey) => {
  const rawKey = decodeBase64(commandPermitKey);
  if (!rawKey || rawKey.byteLength !== 32) return false;
  try {
    const key = await globalThis.crypto.subtle.importKey(
      "raw",
      toArrayBuffer(rawKey),
      { name: "HMAC", hash: "SHA-256" },
      false,
      ["sign"]
    );
    const { commandFrameMac, ...unsigned } = permit;
    const signature = new Uint8Array(await globalThis.crypto.subtle.sign(
      "HMAC",
      key,
      toArrayBuffer(new TextEncoder().encode(browserCommandPermitMacPayload(unsigned)))
    ));
    return commandFrameMac === `sha256:${toHex(signature)}`;
  } catch {
    return false;
  }
};
var decodeBase64 = (value) => {
  try {
    return Uint8Array.from(globalThis.atob(value), (char) => char.charCodeAt(0));
  } catch {
    return null;
  }
};
var toHex = (bytes) => Array.from(bytes, (byte) => byte.toString(16).padStart(2, "0")).join("");
var toArrayBuffer = (bytes) => {
  const copy = new Uint8Array(bytes.byteLength);
  copy.set(bytes);
  return copy.buffer;
};

// src/lib/browser/chrome-extension/command-registry.ts
var EXTENSION_COMMAND_REGISTRY = /* @__PURE__ */ new Set([
  "navigate",
  "dom-intent",
  "observe",
  "screenshot",
  "file-input",
  "wait",
  "close-target"
]);
function assertExtensionCommand(kind) {
  if (!EXTENSION_COMMAND_REGISTRY.has(kind)) throw new Error("BROWSER_CAPABILITY_REJECTED");
}
var admitExtensionCommand = async (input) => {
  assertExtensionCommand(input.kind);
  await assertExtensionCommandPermit(input.permit);
};

// src/lib/browser/chrome-extension/debugger-runtime.ts
var ExtensionDebuggerRuntime = class {
  constructor(chromeApi2) {
    this.chromeApi = chromeApi2;
  }
  chromeApi;
  attached = /* @__PURE__ */ new Set();
  async attach(tabId) {
    if (this.attached.has(tabId)) return;
    await this.chromeApi.debugger.attach({ tabId }, "1.3");
    this.attached.add(tabId);
  }
  async detach(tabId) {
    if (!this.attached.delete(tabId)) return;
    await this.chromeApi.debugger.detach({ tabId }).catch(() => void 0);
  }
  async send(tabId, method, parameters) {
    if (!this.attached.has(tabId)) throw new Error("BROWSER_DEVTOOLS_CONFLICT");
    return this.chromeApi.debugger.sendCommand(target(tabId), method, parameters);
  }
  isAttached(tabId) {
    return this.attached.has(tabId);
  }
};
var target = (tabId) => ({ tabId });

// src/lib/browser/chrome-extension/dom-intent-runtime.ts
var executeFindIntent = async (debuggerRuntime, target2, intent) => {
  const selector = intent.selector ?? selectorForLocator(intent.locator);
  const candidates = await queryAll(debuggerRuntime, target2.tabId, selector, intent.maxMatches + 1);
  const nodes = intent.textContains === void 0 ? candidates : await nodesContainingText(debuggerRuntime, target2.tabId, candidates, intent.textContains);
  if (nodes.length > intent.maxMatches) throw new Error("BROWSER_TARGET_INVALID");
  return { count: nodes.length };
};
var executeClickIntent = async (debuggerRuntime, target2, intent) => {
  const expectedMatches = intent.expectedMatches ?? 1;
  const nodes = await queryAll(debuggerRuntime, target2.tabId, intent.selector, expectedMatches + 1);
  const matchingNodes = intent.expectedText === void 0 ? nodes : await nodesContainingText(debuggerRuntime, target2.tabId, nodes, intent.expectedText);
  if (matchingNodes.length !== expectedMatches) throw new Error("BROWSER_TARGET_INVALID");
  const nodeId = matchingNodes[0];
  if (nodeId === void 0) throw new Error("BROWSER_TARGET_INVALID");
  const box = await boxCenter(debuggerRuntime, target2.tabId, nodeId);
  await debuggerRuntime.send(target2.tabId, "Input.dispatchMouseEvent", { type: "mousePressed", x: box.x, y: box.y, button: "left", clickCount: 1 });
  await debuggerRuntime.send(target2.tabId, "Input.dispatchMouseEvent", { type: "mouseReleased", x: box.x, y: box.y, button: "left", clickCount: 1 });
  return { clicked: true };
};
var executeValueIntent = async (debuggerRuntime, target2, intent) => {
  const nodeId = intent.kind === "readText" || intent.kind === "readAttribute" ? await nodeForRead(debuggerRuntime, target2.tabId, intent) : await nodeForSelector(debuggerRuntime, target2.tabId, intent.selector, intent.kind === "fill" ? intent.expectedMatches ?? 1 : 1);
  if (intent.kind === "inspect") return inspectNode(debuggerRuntime, target2.tabId, nodeId, intent.fields);
  if (intent.kind === "readText") return truncate(await nodeText(debuggerRuntime, target2.tabId, nodeId), intent.maxChars);
  if (intent.kind === "readAttribute") return truncate(attribute(await describeNode(debuggerRuntime, target2.tabId, nodeId), intent.name) ?? "", intent.maxChars);
  await debuggerRuntime.send(target2.tabId, "DOM.focus", { nodeId });
  if (intent.clearBeforeType) {
    await debuggerRuntime.send(target2.tabId, "Input.dispatchKeyEvent", { type: "rawKeyDown", key: "a", code: "KeyA", modifiers: 2 });
    await debuggerRuntime.send(target2.tabId, "Input.dispatchKeyEvent", { type: "keyDown", key: "Backspace", code: "Backspace" });
  }
  await debuggerRuntime.send(target2.tabId, "Input.insertText", { text: intent.approvedText });
  return { filled: true };
};
var executeRegisteredDomIntent = async (debuggerRuntime, target2, intent) => {
  if (intent.kind === "document") return documentState(debuggerRuntime, target2.tabId);
  if (intent.kind === "find") return executeFindIntent(debuggerRuntime, target2, intent);
  if (intent.kind === "click") return executeClickIntent(debuggerRuntime, target2, intent);
  return executeValueIntent(debuggerRuntime, target2, intent);
};
var nodeForSelector = async (runtime, tabId, selector, expectedMatches) => {
  const nodes = await queryAll(runtime, tabId, selector, expectedMatches + 1);
  if (nodes.length !== expectedMatches) throw new Error("BROWSER_TARGET_INVALID");
  const nodeId = nodes[0];
  if (nodeId === void 0) throw new Error("BROWSER_TARGET_INVALID");
  return nodeId;
};
var nodeForRead = async (runtime, tabId, intent) => {
  const maximum = intent.expectedMatches ?? intent.maxMatches ?? 1;
  const candidateNodes = await queryAll(runtime, tabId, intent.selector, maximum + 1);
  const nodes = intent.kind === "readAttribute" && intent.textContains !== void 0 ? await nodesContainingText(runtime, tabId, candidateNodes, intent.textContains) : candidateNodes;
  if (intent.expectedMatches !== void 0 ? nodes.length !== intent.expectedMatches : nodes.length > maximum) {
    throw new Error("BROWSER_TARGET_INVALID");
  }
  const index = intent.matchIndex ?? 0;
  const nodeId = nodes[index];
  if (nodeId === void 0) throw new Error("BROWSER_TARGET_INVALID");
  return nodeId;
};
var queryAll = async (runtime, tabId, selector, limit) => {
  const root = record(await runtime.send(tabId, "DOM.getDocument", { depth: 1, pierce: true }));
  const rootNode = record(root.root);
  const result = record(await runtime.send(tabId, "DOM.querySelectorAll", { nodeId: numberValue(rootNode.nodeId, "BROWSER_TARGET_INVALID"), selector }));
  const values = Array.isArray(result.nodeIds) ? result.nodeIds : [];
  return values.slice(0, limit).map((value) => numberValue(value, "BROWSER_TARGET_INVALID"));
};
var nodesContainingText = async (runtime, tabId, nodeIds, expectedText) => {
  const matches = [];
  for (const nodeId of nodeIds) if ((await nodeText(runtime, tabId, nodeId)).includes(expectedText)) matches.push(nodeId);
  return matches;
};
var documentState = async (runtime, tabId) => {
  const history = record(await runtime.send(tabId, "Page.getNavigationHistory"));
  const entries = Array.isArray(history.entries) ? history.entries : [];
  const currentIndex = numberValue(history.currentIndex, "BROWSER_TARGET_INVALID");
  const entry = record(entries[currentIndex]);
  const url = stringValue(entry.url, "BROWSER_TARGET_INVALID");
  const title = stringValue(entry.title, "BROWSER_TARGET_INVALID");
  if (!url.startsWith("https://")) throw new Error("BROWSER_ORIGIN_REJECTED");
  return { url, title };
};
var describeNode = async (runtime, tabId, nodeId) => record(record(await runtime.send(tabId, "DOM.describeNode", { nodeId, depth: 0 })).node);
var nodeText = async (runtime, tabId, nodeId) => {
  const outerHtml = stringValue(record(await runtime.send(tabId, "DOM.getOuterHTML", { nodeId })).outerHTML, "BROWSER_TARGET_INVALID");
  return new DOMParser().parseFromString(outerHtml, "text/html").body.textContent ?? "";
};
var staticFieldReaders = {
  tagName: (node) => stringValue(node.nodeName, "BROWSER_TARGET_INVALID"),
  type: (node) => attribute(node, "type") ?? "",
  role: (node) => attribute(node, "role") ?? "",
  ariaLabel: (node) => attribute(node, "aria-label") ?? "",
  value: (node) => attribute(node, "value") ?? "",
  accept: (node) => attribute(node, "accept") ?? "",
  multiple: (node) => attribute(node, "multiple") !== void 0,
  connected: () => true,
  disabled: (node) => attribute(node, "disabled") !== void 0
};
var inspectStaticField = (node, field, result) => {
  const reader = staticFieldReaders[field];
  if (!reader) return false;
  result[field] = reader(node);
  return true;
};
var inspectGeometryField = async (runtime, tabId, nodeId, field, result) => {
  if (field !== "visible" && field !== "bounds") return false;
  const box = await boxCenter(runtime, tabId, nodeId).catch(() => null);
  if (field === "visible") result.visible = box !== null;
  if (field === "bounds") result.bounds = box;
  return true;
};
var inspectNode = async (runtime, tabId, nodeId, fields) => {
  const node = await describeNode(runtime, tabId, nodeId);
  const result = {};
  for (const field of fields) {
    if (field === "text") {
      result.text = await nodeText(runtime, tabId, nodeId);
      continue;
    }
    if (inspectStaticField(node, field, result)) continue;
    await inspectGeometryField(runtime, tabId, nodeId, field, result);
  }
  return result;
};
var boxCenter = async (runtime, tabId, nodeId) => {
  const boxModel = record(await runtime.send(tabId, "DOM.getBoxModel", { nodeId }));
  const model = record(boxModel.model);
  const content = Array.isArray(model.content) ? model.content : [];
  if (content.length < 8) throw new Error("BROWSER_TARGET_INVALID");
  const x = (numberValue(content[0], "BROWSER_TARGET_INVALID") + numberValue(content[2], "BROWSER_TARGET_INVALID")) / 2;
  const y = (numberValue(content[1], "BROWSER_TARGET_INVALID") + numberValue(content[5], "BROWSER_TARGET_INVALID")) / 2;
  return { x, y };
};
var selectorForLocator = (locator) => {
  const clauses = [
    locator.role ? `[role="${escapeSelectorValue(locator.role)}"]` : "",
    locator.testId ? `[data-testid="${escapeSelectorValue(locator.testId)}"]` : "",
    locator.label ? `[aria-label="${escapeSelectorValue(locator.label)}"]` : "",
    locator.name ? `[name="${escapeSelectorValue(locator.name)}"]` : ""
  ].filter((value) => value.length > 0);
  if (clauses.length === 0) throw new Error("BROWSER_TARGET_INVALID");
  return clauses.join("");
};
var escapeSelectorValue = (value) => {
  if (value.length === 0 || value.length > 512 || /[\u0000-\u001f"\\\\]/u.test(value)) throw new Error("BROWSER_TARGET_INVALID");
  return value;
};
var attribute = (node, name) => {
  const attributes = Array.isArray(node.attributes) ? node.attributes : [];
  for (let index = 0; index + 1 < attributes.length; index += 2) if (attributes[index] === name && typeof attributes[index + 1] === "string") return attributes[index + 1];
  return void 0;
};
var truncate = (value, maxChars) => value.slice(0, maxChars);
var record = (value) => {
  if (typeof value !== "object" || value === null || Array.isArray(value)) throw new Error("BROWSER_TARGET_INVALID");
  return value;
};
var numberValue = (value, errorCode) => {
  if (typeof value !== "number" || !Number.isFinite(value)) throw new Error(errorCode);
  return value;
};
var stringValue = (value, errorCode) => {
  if (typeof value !== "string") throw new Error(errorCode);
  return value;
};

// src/lib/browser/chrome-extension/exact-target-runtime.ts
var assertExactTarget = (target2) => {
  if (!target2.targetRef || !target2.documentRef || !Number.isInteger(target2.tabId)) throw new Error("BROWSER_TARGET_INVALID");
};
var ExtensionExactTargetRegistry = class {
  targets = /* @__PURE__ */ new Map();
  claimOperatorTarget(tabId) {
    if (!Number.isInteger(tabId) || tabId < 0) throw new Error("BROWSER_TARGET_INVALID");
    const target2 = {
      targetRef: `target-${newRef()}`,
      documentRef: `document-${newRef()}`,
      tabId,
      navigationEpoch: 0
    };
    this.targets.set(target2.targetRef, target2);
    return target2;
  }
  describeOperatorClaim(target2, input) {
    assertExactTarget(target2);
    if (typeof input.url !== "string" || !isHttpsUrl(input.url)) {
      throw new Error("BROWSER_ORIGIN_REJECTED");
    }
    return {
      targetRef: target2.targetRef,
      documentRef: target2.documentRef,
      navigationEpoch: target2.navigationEpoch,
      url: input.url,
      title: typeof input.title === "string" ? input.title.slice(0, 512) : ""
    };
  }
  resolve(targetRef, documentRef) {
    const target2 = this.targets.get(targetRef);
    if (!target2) throw new Error("BROWSER_TARGET_INVALID");
    if (target2.documentRef !== documentRef) throw new Error("BROWSER_DOCUMENT_INVALID");
    return target2;
  }
  advanceDocument(targetRef) {
    const current = this.targets.get(targetRef);
    if (!current) throw new Error("BROWSER_TARGET_INVALID");
    const next = {
      ...current,
      documentRef: `document-${newRef()}`,
      navigationEpoch: current.navigationEpoch + 1
    };
    this.targets.set(targetRef, next);
    return next;
  }
  remove(targetRef) {
    this.targets.delete(targetRef);
  }
  invalidateTab(tabId) {
    for (const [targetRef, target2] of this.targets) if (target2.tabId === tabId) this.targets.delete(targetRef);
  }
};
var newRef = () => globalThis.crypto.randomUUID();
var isHttpsUrl = (value) => {
  try {
    return new URL(value).protocol === "https:";
  } catch {
    return false;
  }
};

// src/lib/browser/chrome-extension/native-port-actor.ts
var createExtensionNativePortActor = (chromeApi2, generation) => {
  const port = chromeApi2.runtime.connectNative("com.grasseye.browser_host");
  const debuggerRuntime = new ExtensionDebuggerRuntime(chromeApi2);
  const targets = new ExtensionExactTargetRegistry();
  const sourceChannelToken = globalThis.crypto.randomUUID();
  let closed = false;
  let controllerReady = false;
  const close = (_reasonCode = "BROWSER_HOST_UNAVAILABLE") => {
    if (closed) return;
    closed = true;
    clearExtensionPermitAuthority();
    port.disconnect();
  };
  const send = (message) => {
    if (!closed) port.postMessage(message);
  };
  const onMessage = (value) => {
    handleControllerFrame(value, { chromeApi: chromeApi2, debuggerRuntime, targets, port, sourceChannelToken, isReady: () => controllerReady, setReady: () => {
      controllerReady = true;
    }, send, close }).catch((error) => {
      const command = parseControllerCommand(value);
      if (command) send({ kind: "extension-reply", sourceChannelToken, replyChannelToken: command.permit.replyChannelToken, sequence: command.permit.sequence, errorCode: browserErrorCode(error) });
      else close(browserErrorCode(error));
    });
  };
  return {
    generation,
    start: () => {
      port.onMessage.addListener(onMessage);
      port.onDisconnect.addListener(() => close("BROWSER_HOST_UNAVAILABLE"));
      chromeApi2.action.onClicked.addListener((tab) => {
        if (closed || !Number.isInteger(tab.id)) return;
        const tabId = tab.id;
        if (tabId === void 0) return;
        debuggerRuntime.attach(tabId).then(() => {
          const target2 = targets.claimOperatorTarget(tabId);
          const claim = targets.describeOperatorClaim(target2, tab);
          send({ kind: "operator-target-claimed", sourceChannelToken, claim });
        }).catch(() => close("BROWSER_DEVTOOLS_CONFLICT"));
      });
      chromeApi2.debugger.onDetach.addListener((target2) => {
        targets.invalidateTab(target2.tabId);
        close("BROWSER_DEVTOOLS_CONFLICT");
      });
    },
    close
  };
};
var handleControllerFrame = async (value, context) => {
  const bootstrap = parseBootstrap(value);
  if (bootstrap) {
    context.send({ kind: "extension-hello", controllerToken: bootstrap.controllerToken, sourceChannelToken: context.sourceChannelToken, proof: bootstrap.proof });
    return;
  }
  const ready = parseControllerReady(value);
  if (ready) {
    if (ready.sourceChannelToken !== context.sourceChannelToken) throw new Error("BROWSER_AUTH_TRANSCRIPT_INVALID");
    setExtensionPermitAuthority(ready.authority);
    context.setReady();
    return;
  }
  const command = parseControllerCommand(value);
  if (!command || !context.isReady() || command.sourceChannelToken !== context.sourceChannelToken) throw new Error("BROWSER_AUTH_TRANSCRIPT_INVALID");
  await admitExtensionCommand({ kind: command.command.kind, permit: command.permit });
  const target2 = context.targets.resolve(command.permit.targetRef, command.permit.documentRef);
  const result = await executeCommand(context, target2, command.command);
  context.send({ kind: "extension-reply", sourceChannelToken: context.sourceChannelToken, replyChannelToken: command.permit.replyChannelToken, sequence: command.permit.sequence, result });
};
var executeCommand = async (context, target2, command) => {
  if (command.kind === "navigate") {
    const url = new URL(command.url);
    if (url.protocol !== "https:") throw new Error("BROWSER_ORIGIN_REJECTED");
    await context.debuggerRuntime.send(target2.tabId, "Page.navigate", { url: command.url });
    const next = context.targets.advanceDocument(target2.targetRef);
    return {
      documentRef: next.documentRef,
      targetRef: next.targetRef,
      navigationEpoch: next.navigationEpoch
    };
  }
  if (command.kind === "dom-intent") return executeRegisteredDomIntent(context.debuggerRuntime, target2, command.intent);
  if (command.kind === "observe") {
    const root = await context.debuggerRuntime.send(target2.tabId, "DOM.getDocument", { depth: 1, pierce: true });
    return { capabilityId: command.capabilityId, root };
  }
  if (command.kind === "wait") {
    if (!Number.isInteger(command.durationMs) || command.durationMs < 0 || command.durationMs > 3e4) throw new Error("BROWSER_COMMAND_PERMIT_INVALID");
    await new Promise((resolve) => globalThis.setTimeout(resolve, command.durationMs));
    return { waitedMs: command.durationMs };
  }
  if (command.kind === "close-target") {
    context.targets.remove(target2.targetRef);
    await context.debuggerRuntime.detach(target2.tabId);
    return { closed: true };
  }
  if (command.kind === "file-input") throw new Error("BROWSER_FILE_GRANT_INVALID");
  if (command.kind === "screenshot") throw new Error("BROWSER_CAPABILITY_REJECTED");
  throw new Error("BROWSER_CAPABILITY_REJECTED");
};
var isBrowserHash = (value) => typeof value === "string" && /^sha256:[a-f0-9]{64}$/u.test(value);
var isAuthenticationProof = (value) => isBrowserHash(value.executionBindingHash) && isBrowserHash(value.authTranscriptHash) && isRecord(value.handshake);
var parseBootstrap = (value) => {
  if (!isRecord(value) || value.kind !== "host-bootstrap" || typeof value.controllerToken !== "string") return null;
  if (!isRecord(value.proof) || !isAuthenticationProof(value.proof)) return null;
  return { kind: "host-bootstrap", controllerToken: value.controllerToken, proof: value.proof };
};
var isControllerAuthority = (value) => typeof value.authorityRef === "string" && typeof value.authorityEpoch === "number" && isBrowserHash(value.certificateHash) && isBrowserHash(value.activationTupleHash) && isBrowserHash(value.executionBindingHash) && typeof value.commandPermitKey === "string";
var parseControllerReady = (value) => {
  if (!isRecord(value) || value.kind !== "controller-ready" || typeof value.sourceChannelToken !== "string" || !isRecord(value.authority)) return null;
  if (!isControllerAuthority(value.authority)) return null;
  return { kind: "controller-ready", sourceChannelToken: value.sourceChannelToken, authority: value.authority };
};
var hasStringFields = (value, fields) => fields.every((field) => typeof value[field] === "string");
var isBrowserCommandPermit = (value) => hasStringFields(value, [
  "permitRef",
  "authorityRef",
  "certificateHash",
  "activationTupleHash",
  "executionBindingHash",
  "targetLeaseRef",
  "targetRef",
  "documentRef",
  "capabilityId",
  "commandId",
  "mutationClass",
  "deadlineAt",
  "replyChannelToken",
  "commandFrameMac"
]) && typeof value.authorityEpoch === "number" && typeof value.sequence === "number";
var isBrowserGovernedCommand = (value) => typeof value.kind === "string";
var parseControllerCommand = (value) => {
  if (!isRecord(value) || value.kind !== "controller-command" || typeof value.sourceChannelToken !== "string") return null;
  if (!isRecord(value.permit) || !isBrowserCommandPermit(value.permit)) return null;
  if (!isRecord(value.command) || !isBrowserGovernedCommand(value.command)) return null;
  return {
    kind: "controller-command",
    sourceChannelToken: value.sourceChannelToken,
    permit: value.permit,
    command: value.command
  };
};
var isRecord = (value) => typeof value === "object" && value !== null && !Array.isArray(value);
var browserErrorCode = (error) => error instanceof Error && /^BROWSER_[A-Z_]+$/u.test(error.message) ? error.message : "BROWSER_HOST_UNAVAILABLE";

// src/lib/browser/chrome-extension/extension-runtime-types.ts
var readExtensionChromeApi = () => {
  const candidate = globalThis.chrome;
  return isChromeApi(candidate) ? candidate : null;
};
var isChromeApi = (value) => {
  if (!isRecord2(value) || !isRecord2(value.runtime) || !isRecord2(value.debugger) || !isRecord2(value.action)) return false;
  return typeof value.runtime.connectNative === "function" && typeof value.runtime.getManifest === "function" && typeof value.debugger.attach === "function" && typeof value.debugger.detach === "function" && typeof value.debugger.sendCommand === "function" && isRecord2(value.debugger.onDetach) && typeof value.debugger.onDetach.addListener === "function" && isRecord2(value.action.onClicked) && typeof value.action.onClicked.addListener === "function";
};
var isRecord2 = (value) => typeof value === "object" && value !== null && !Array.isArray(value);

// src/lib/browser/chrome-extension/service-worker.ts
var admitExtensionCommand2 = async (input) => admitExtensionCommand(input);
var chromeApi = readExtensionChromeApi();
if (chromeApi) createExtensionNativePortActor(chromeApi, 1).start();
export {
  admitExtensionCommand2 as admitExtensionCommand
};
