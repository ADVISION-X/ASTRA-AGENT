import { buildAuditArtifacts } from "./build-audit-artifacts.js";
import { hasBlockingFindings } from "./core/result.js";
import { createInspectorContext, loadGeneratedArtifacts, loadInspector, writeRunnerSummary } from "./core/runtime.js";
import type { InspectorResult, RunnerSummary } from "./core/schema.js";

const buildSummary = (input: {
	phase: string;
	results: InspectorResult[];
	artifactBlockingCount: number;
}): RunnerSummary => ({
	generatedAt: new Date().toISOString(),
	phase: input.phase,
	totals: {
		inspectors: input.results.length,
		passed: input.results.filter((result) => result.passed).length,
		failed: input.results.filter((result) => !result.passed).length,
		blocking: input.results.filter((result) => hasBlockingFindings(result.findings)).length + input.artifactBlockingCount,
	},
	results: input.results,
});

const exitNow = (code: number): never => {
	process.exit(code);
};

const main = async (): Promise<void> => {
	await buildAuditArtifacts();

	const artifacts = await loadGeneratedArtifacts();
	const artifactBlockingCount = artifacts.auditConflicts.conflicts.length + (artifacts.auditPlan.owners.length === 0 ? 1 : 0);
	if (artifacts.auditConflicts.conflicts.length > 0) {
		for (const conflict of artifacts.auditConflicts.conflicts) {
			console.error(`[AUDIT-CONFLICT] ${conflict.kind} ${conflict.capabilityDomain ?? "unknown-domain"} ${conflict.lawId ?? "no-law-id"}: ${conflict.message}`);
		}
	}
	if (artifacts.auditPlan.owners.length === 0) {
		console.error("[AUDIT-CONFLICT] audit plan produced zero owners; owner deletion or phase-gate drift is a blocking enforcement failure.");
	}
	if (artifactBlockingCount > 0) {
		await writeRunnerSummary(buildSummary({ phase: artifacts.auditPlan.phase, results: [], artifactBlockingCount }));
		process.stderr.write(`[AUDIT FAIL-FAST] stopped before inspector execution because generated artifacts have ${artifactBlockingCount} blocking issue(s).\n`);
		exitNow(1);
	}

	const context = await createInspectorContext(artifacts);
	const results: InspectorResult[] = [];

	for (const planOwner of artifacts.auditPlan.owners) {
		const inspector = await loadInspector(planOwner.entry);
		const result = await inspector(context);
		results.push(result);
		process.stdout.write(`[${result.classification}] ${result.capabilityDomain}: ${result.summary}\n`);

		if (hasBlockingFindings(result.findings)) {
			const summary = buildSummary({ phase: artifacts.auditPlan.phase, results, artifactBlockingCount });
			await writeRunnerSummary(summary);
			process.stderr.write(`[AUDIT FAIL-FAST] stopped at ${result.capabilityDomain}; ${summary.totals.blocking} blocking issue(s) recorded.\n`);
			exitNow(1);
		}
	}

	const summary = buildSummary({ phase: artifacts.auditPlan.phase, results, artifactBlockingCount });
	await writeRunnerSummary(summary);
	process.stdout.write(`[AUDIT PASS] completed ${summary.totals.passed}/${summary.totals.inspectors} inspections with zero blocking findings.\n`);
	exitNow(0);
};

main().catch((error: unknown) => {
	const message = error instanceof Error ? error.stack ?? error.message : String(error);
	process.stderr.write(`[AUDIT ERROR] ${message}\n`);
	exitNow(1);
});
