# GrassEye Map Authoring Input Package 施工图 FINAL

## 0. 文件身份

```yaml
documentId: GRASSEYE-MAP-AUTHORING-INPUT-PACKAGE-BLUEPRINT-FINAL
documentType: construction-blueprint
owner: map-plugin-package
relatedOwner:
  - ai-capability
  - commander-console-capability
  - orchestration-capability
  - forensics-persistence-capability
status: active
notAbilityGroup: true
notRuntimeOwner: true
```

本文件定义高级 AI 生成地图所需的完整输入包。  
没有完整输入包，高级 AI 只能生成草稿文字，不能生成可验证、可激活、可执行的 GrassEye 地图。

---

## 1. 目标

Map Authoring Input Package 解决 8 个问题：

```txt
1. 用户要做什么？
2. 系统有哪些能力？
3. AI 可以怎么提问和判断？
4. AI 输出有哪些可分支字段？
5. 地图 JSON 应该怎么写？
6. 哪些动作必须人工确认？
7. 哪些步骤必须 PAV / Forensics / Evidence？
8. 当前平台允许和禁止什么？
```

---

## 2. Required Package Shape

```yaml
inputPackageId: required
inputPackageVersion: required
generatedAt: required
requesterRef: required

userRequirement: required
userRequirementRef: required
sourceRequirementHash: required

targetPlatformProfileRef: required
targetPlatformProfile: required

capabilityCatalog: required
promptContractCatalog: required
outputSchemaCatalog: required

mapPackageSchema: required
mapAuthoringOutputSchema: required

safetyPolicy: required
humanApprovalPolicy: required
evidencePolicy: required
pavPolicy: required
forensicsPolicy: required
privacyPolicy: required
secretPolicy: required
rateLimitPolicy: required

exampleMaps: optional
validationPolicy: required
expectedDraftStatus: draft
```

---

## 3. User Requirement

Required minimum：

```yaml
goal: required
targetPlatform: required
allowedAutomationScope: required
mustAskBefore: list
failureHandlingPreference: optional
evidencePreference: optional
runLimit: optional
```

If missing：

```txt
requiredClarifications
```

---

## 4. Capability Catalog

### Ability Group

```yaml
abilityGroupId: required
abilityGroupCode: required
displayName: required
description: required
ownerDomain: required
routableByMap: boolean
publicContractRef: required
inputSchemaRef: required
outputSchemaRef: required
forbiddenResponsibilities: non-empty list
children: non-empty list
```

### Child Capability

```yaml
childCapabilityId: required
childCapabilityCode: required
displayName: required
description: required
inputSchemaRef: required
outputSchemaRef: required
requiredInputRefs: list
producedOutputRefs: list
requiresGeometryProof: boolean
requiresTargetProof: boolean
requiresFocusProof: boolean
requiresApprovedText: boolean
requiresPostActionVerification: boolean
requiresHumanReview: boolean
sensitiveOperation: boolean
sideEffectLevel: none | read | write | submit | delete | purchase
allowedStepKinds: list
supportedTargetKinds: list
forbiddenResponsibilities: non-empty list
proofRequirements: list
failureModes: list
```

---

## 5. Prompt Contract Catalog

```yaml
promptContractId: required
promptContractVersion: required
promptHash: required
displayName: required
description: required
inputSchemaRef: required
outputSchemaRef: required
allowedInputRefs: list
dataPolicy: required
providerPolicy: required
reviewPolicy: required
failurePolicy: required
redactionPolicy: required
forensicsPolicy: required
forbiddenOutputs: list
branchableOutputFields: list
```

---

## 6. Output Schema Catalog

```yaml
outputSchemaRef: required
schemaVersion: required
declaredFields: list
branchableFields: list
fieldTypes: map
requiredFields: list
reviewFields: list
confidenceFields: list
forbiddenFields: list
exampleOutput: optional
```

---

## 7. Safety / Human Approval Policy

```yaml
highRiskOperations:
  sendMessage: humanApprovalRequired
  submitForm: humanApprovalRequired
  purchasePayment: humanApprovalRequired
  deleteContent: humanApprovalRequired
  modifyUserData: humanApprovalRequired
  bulkAction: humanApprovalRequiredWithRateLimit
  textInputCommit: humanApprovalRequired
externalAiTransmission:
  userRequirement: approvalRequired
```

---

## 8. Evidence / PAV / Forensics Policy

```yaml
actionStep:
  requiresRuntimeProof: true
  requiresPavWhenCatalogRequires: true
mouseClick:
  successRequiresPavHandoff: true
textInput:
  successRequiresPavHandoff: true
screenshot:
  requiresRetentionPolicy: true
aiStep:
  requiresAiProofRef: true
  requiresPromptContractRefs: true
evidenceCandidate:
  requiresEvidencePacketRef: true
forensics:
  storesRefsAndHashesOnly: true
  forbidsRawSecrets: true
  forbidsRawPromptBody: true
  forbidsRawSensitiveText: true
  forbidsRawClipboardText: true
```

---

## 9. Platform Profile

```yaml
platformId: required
platformName: required
loginRequired: boolean
authCheckPolicy: required
securityCheckPolicy: required
supportedTargets: list
prohibitedOperations: list
rateLimitPolicyRef: required
captchaPolicy: required
humanReviewPolicyRef: required
safetyPauseConditions: list
```

---

## 10. Example Maps

Rules：

```txt
exampleOnly=true
schema-valid
not active
not approved
not imported without lifecycle
must not contain rawPrompt
must not contain activationSnapshotRef
```

---

## 11. Authoring Prompt Use

The map authoring prompt must receive either：

```txt
full MapAuthoringInputPackage
```

or refs to all required parts.  
It must not receive only userRequirement.

---

## 12. Missing Input Handling

If required package field is missing：

```txt
BLOCKED_AUTHORING_INPUT_INCOMPLETE
```

AI must not generate map.

If user requirement unclear：

```txt
requiredClarifications
```

If ability unavailable：

```txt
needsCapabilityExpansion
```

---

## 13. READY 标准

Map Authoring Input Package READY only when：

```txt
all required fields present
capabilityCatalog detailed
promptContractCatalog present
outputSchemaCatalog present
mapPackageSchema present
mapAuthoringOutputSchema present
safety/humanApproval/evidence/PAV/Forensics policies present
platformProfile present
example maps marked exampleOnly
missing package blocks generation
negative proof PASS
```
