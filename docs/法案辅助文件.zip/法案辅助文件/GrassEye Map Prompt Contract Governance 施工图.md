# GrassEye Map Prompt Contract Governance 施工图 MAP-AUTHORING FINAL

## 0. 文件身份

```yaml
documentId: GRASSEYE-MAP-PROMPT-CONTRACT-GOVERNANCE-BLUEPRINT-MAP-AUTHORING-FINAL
documentType: governance-blueprint
owner: ai-capability
relatedSupportDomain: map-plugin-package
status: active
notAbilityGroup: true
notMapRuntime: true
replace:
  - docs/法案辅助文件/GrassEye Map Prompt Contract Governance 施工图.md
```

Prompt 内容归 AI Capability。  
Map Plugin Package 只引用 `promptContractId`，不拥有 prompt 内容。  
Map Authoring Input Package 给 AI 提供上下文，但不把 prompt 内容写进地图。

---

## 1. 核心边界

```txt
AI Capability owns Prompt Contract Catalog.
Map Plugin Package references promptContractId.
Map Plugin Package validates promptContractId/outputSchemaRef references.
Orchestration consumes frozen active map and sends promptContractId through Nerve Bus.
Nerve Bus transports promptContractId/outputSchemaRef only.
Forensics records promptContractId/promptVersion/promptHash/outputSchemaRef/proof refs.
```

Forbidden：

```txt
rawPrompt in map package
systemPrompt/userPrompt/promptText in map package
prompt text hardcoded in Orchestration
prompt text hardcoded in Nerve Bus
prompt text hidden in map adapter
AI runtime using map-specific hidden prompt outside Prompt Contract Catalog
Map Plugin Package selecting provider
Map Plugin Package reading API key
```

---

## 2. Prompt Contract Catalog Entry

Each prompt contract must define：

```yaml
promptContractId: required
promptContractVersion: required
promptHash: required
displayName: required
description: required
inputSchemaRef: required
outputSchemaRef: required
allowedInputRefs: list
dataPolicy: required
providerPolicy: required
reviewPolicy: required
failurePolicy: required
redactionPolicy: required
forensicsPolicy: required
forbiddenOutputs: list
branchableOutputFields: list
exampleInputRefs: optional
exampleOutput: optional
```

Minimum contracts：

```txt
map-authoring-from-user-requirement-v1
product-video-classification-v1
visual-target-identification-v1
page-state-understanding-v1
post-action-verification-v1
```

---

## 3. Map Authoring Prompt Contract

`map-authoring-from-user-requirement-v1` must consume：

```txt
MapAuthoringInputPackage
```

Required input refs：

```txt
userRequirementRef
capabilityCatalog
promptContractCatalog
outputSchemaCatalog
mapPackageSchema
mapAuthoringOutputSchema
safetyPolicy
humanApprovalPolicy
evidencePolicy
pavPolicy
forensicsPolicy
targetPlatformProfile
exampleMaps
```

It must instruct AI：

```txt
You are GrassEye Map Authoring Agent.
You receive a complete Map Authoring Input Package.
You generate declarative operational-map package candidates only.
You cannot write code.
You cannot write raw prompts.
You cannot execute tools.
You cannot call APIs.
You cannot activate maps.
You cannot approve maps.
You cannot emit humanApprovalRef.
You cannot emit validationReportRef.
You cannot emit activationSnapshotRef.
You cannot invent abilityGroupId.
You cannot invent childCapabilityId.
You cannot invent promptContractId.
You cannot invent outputSchemaRef.
You must use only capabilityCatalog, promptContractCatalog, outputSchemaCatalog, and policy catalogs.
If requirement is unclear, output requiredClarifications.
If current abilities are insufficient, output needsCapabilityExpansion.
If operation sends/deletes/buys/submits/modifies user data, add review gate.
If operation involves commit/send/publish behavior, require explicit human confirmation.
Return strict JSON matching MapAuthoringAiOutputSchema.
```

---

## 4. MapAuthoringAiOutputSchema

Required：

```yaml
authoringRunId: required
userRequirementRef: required
sourceRequirementHash: required
providerPolicyRef: required
promptContractId: map-authoring-from-user-requirement-v1
promptContractVersion: required
promptHash: required
capabilityCatalogVersion: required
promptCatalogVersion: required
outputSchemaCatalogVersion: required
mapPackageSchemaVersion: required
securityPolicyRef: required
safetyPolicyRef: required
humanApprovalPolicyRef: required
evidencePolicyRef: required
pavPolicyRef: required
forensicsPolicyRef: required
platformProfileRef: required
outputFormatVersion: required
generatedAt: required
authoringProofRef: required
draftPackage: required
humanReadableExplanation: required
riskWarnings: list
validationHints: list
requiredClarifications: list
needsCapabilityExpansion: boolean
promptBindings: list
draftStatus: draft | needs_clarification | needs_capability_expansion
```

Forbidden：

```txt
approvalStatus=approved
active=true
activationSnapshotRef
humanApprovalRef
validationReportRef
rawPrompt
functionBody
eval
script
import
require
unknown abilityGroupId
unknown childCapabilityId
unknown promptContractId
unknown outputSchemaRef
```

---

## 5. Output Schema Catalog

Every outputSchemaRef used by prompt contracts must exist in Output Schema Catalog.

Required：

```yaml
outputSchemaRef: required
schemaVersion: required
declaredFields: list
branchableFields: list
fieldTypes: map
requiredFields: list
reviewFields: list
confidenceFields: list
forbiddenFields: list
exampleOutput: optional
```

Branch DSL may read only：

```txt
status
schemaFieldRef:<fieldName> where fieldName ∈ branchableFields
```

---

## 6. Prompt Binding

Each map AI step must bind：

```txt
stepId
promptContractId
requiredInputRefs
outputSchemaRef
confidencePolicy
reviewPolicy
failureBranch
```

Rules：

```txt
promptContractId exists in Prompt Contract Catalog
outputSchemaRef exists in Output Schema Catalog
outputSchemaRef matches Prompt Contract Catalog
requiredInputRefs are available from prior steps or initial command refs
branch DSL reads only outputSchemaRef-declared branchable fields
```

---

## 7. Forensics Proof

For each AI step, Forensics must record refs/hashes：

```txt
promptContractId
promptContractVersion
promptHash
outputSchemaRef
aiInputRefs
aiOutputRef
aiProofRef
modelPolicyRef/providerPolicyRef
activationSnapshotRef
mapPackageId
mapPackageVersion
stepId
capabilityCallId
authoringProofRef when map authoring
userRequirementRef when map authoring
sourceRequirementHash when map authoring
```

Forbidden：

```txt
raw prompt body in map proof
API key in proof/log/map
raw user secret in proof/log/map
```

---

## 8. Negative Proof

Must fail：

```txt
map contains rawPrompt
map step missing promptContractId
prompt binding missing outputSchemaRef
promptContractId unknown
outputSchemaRef unknown
outputSchemaRef mismatch
Orchestration hardcodes prompt text
Nerve Bus carries raw prompt body
branch reads undeclared output field
AI map authoring output emits activationSnapshotRef
AI map authoring output emits approvalStatus=approved
AI map authoring output references unknown outputSchemaRef
Map Authoring Input Package missing outputSchemaCatalog
Map Authoring Input Package missing safetyPolicy
Map Authoring Input Package missing evidencePolicy
```

---

## 9. READY 标准

Prompt Contract Governance READY only when：

```txt
AI owns Prompt Contract Catalog
Map references promptContractId only
Map package contains no raw prompt
Map Authoring Input Package is complete
AI authoring prompt contract consumes complete input package
AI authoring output schema strict
Prompt binding validates against Prompt Contract Catalog
OutputSchemaRef validates against Output Schema Catalog
Branch DSL validates against branchableFields
Forensics records prompt refs/hashes/outputSchemaRef
negative proof PASS
CI-FULL PASS
```
