---
name: "GrassEye Map Plugin Package Governance"
description: "Use when defining controlled declarative operational-map packages, task-template packages, import/quarantine/activation/rollback flow, and map-package enforcement boundaries."
applyTo: ".github/instructions/cursor-rules/modules/module-map-plugin-package.instructions.md, src/map-plugins/**, docs/法案辅助文件/GrassEye 地图插件包治理施工图.md, docs/why/map-plugin-package.WHY.md, scripts/audit/domains/map-plugin-package/**"
---

# GrassEye Map Plugin Package Governance

Scope: governs declarative operational-map packages, task-template packages, package lifecycle, and no-code plugin enforcement.
Boundary: this module governs controlled pluggable map packages only.
Excludes: ability-group ownership, runtime code plugins, direct capability execution, and authority reassignment away from Orchestration.
Authority: this file is authoritative only for the map-plugin-package governance domain.

## Law GRASSEYE-MAP-PLUGIN-001-V1

status: active
tier: P0
capabilityDomain: map-plugin-package
enforcementMode: manual-first
evidenceMode: law

summary: Map plugins are declarative data packages, not runtime code.

### 法条

Map plugins are declarative data packages consumed by Orchestration. They are not runtime code, not ability plugins, and not new owners.

## Law GRASSEYE-MAP-PLUGIN-002-V1

status: active
tier: P0
capabilityDomain: map-plugin-package
enforcementMode: manual-first
evidenceMode: law

summary: Map plugins must enter quarantine on import and cannot become active without validation and approval.

### 法条

Imported map packages must enter quarantine first and cannot become active without validation, approval, and activation records.

## Law GRASSEYE-MAP-PLUGIN-003-V1

status: active
tier: P0
capabilityDomain: map-plugin-package
enforcementMode: manual-first
evidenceMode: law

summary: Map plugins must declare full package governance metadata.

### 法条

Map plugins must declare manifest, task template, operational map, dependencies, compatibility, policy, and prompt bindings.

## Law GRASSEYE-MAP-PLUGIN-004-V1

status: active
tier: P0
capabilityDomain: map-plugin-package
enforcementMode: manual-first
evidenceMode: law

summary: Map plugins must never carry executable payloads or direct ability control.

### 法条

Map plugins must never contain executable code, dynamic imports, JS or TS handlers, shell scripts, eval strings, or direct ability calls.

## Law GRASSEYE-MAP-PLUGIN-005-V1

status: active
tier: P0
capabilityDomain: map-plugin-package
enforcementMode: manual-first
evidenceMode: law

summary: Map plugins expose task-template UX while keeping internal runtime identifiers private in ordinary mode.

### 法条

Map plugins expose user-facing task templates, while mapId, stepId, and childCapabilityId remain developer or internal fields.

## Law GRASSEYE-MAP-PLUGIN-006-V1

status: active
tier: P0
capabilityDomain: map-plugin-package
enforcementMode: manual-first
evidenceMode: law

summary: AI-generated maps are draft-only until validation and human approval.

### 法条

AI-generated maps remain draft-only and must not execute until validation and human approval complete.

## Law GRASSEYE-MAP-PLUGIN-007-V1

status: active
tier: P0
capabilityDomain: map-plugin-package
enforcementMode: manual-first
evidenceMode: law

summary: Map package enforcement closes through the map-plugin-package inspector and audit runner scripts.

### 法条

Map package enforcement closes through the map-plugin-package inspector, its negative-proof harness, and audit-runner-compatible governance scripts.