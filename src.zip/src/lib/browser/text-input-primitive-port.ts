import { createId } from "../local-runtime/ids.js";
import type { TextInputExecutionPort, TextInputExecutionRequest, TextInputExecutionResult } from "../../capabilities/text-input/ports/text-input-execution-port.js";
import type { BrowserController } from "./browser-controller.js";

type CreateBrowserControllerTextInputExecutionPortInput = {
  browserController: BrowserController;
};

export function createBrowserControllerTextInputExecutionPort(
  input: CreateBrowserControllerTextInputExecutionPortInput,
): TextInputExecutionPort {
  return {
    async execute(value: TextInputExecutionRequest): Promise<TextInputExecutionResult> {
      if (value.abortSignal?.aborted) {
        return {
          ok: false,
          primitiveExecutionRef: null,
          message: "text input primitive aborted before dispatch",
          startedAt: null,
          endedAt: null,
          portKind: "browser-controller",
          failureReason: "primitive_aborted",
        };
      }

      const startedAt = new Date().toISOString();
      let timeoutHandle: NodeJS.Timeout | null = null;

      try {
        const result = await Promise.race([
          input.browserController.textInput({
            targetLabel: value.targetLabel,
            action: value.childCapabilityId,
            text: value.approvedText,
            key: value.key,
            fallbackUsed: false,
          }),
          new Promise<never>((_, reject) => {
            value.abortSignal?.addEventListener("abort", () => {
              reject(new Error("text input primitive aborted"));
            }, { once: true });
          }),
          new Promise<never>((_, reject) => {
            timeoutHandle = setTimeout(() => {
              reject(new Error("text input primitive timed out"));
            }, value.timeoutMs);
          }),
        ]);

        if (timeoutHandle) {
          clearTimeout(timeoutHandle);
        }

        return {
          ok: result.ok,
          primitiveExecutionRef: result.browserActionId ?? createId("text_input_primitive"),
          message: result.message,
          startedAt,
          endedAt: new Date().toISOString(),
          portKind: "browser-controller",
          failureReason: result.ok ? null : "primitive_failed",
        };
      } catch (error) {
        if (timeoutHandle) {
          clearTimeout(timeoutHandle);
        }

        const message = error instanceof Error ? error.message : "text input primitive failed";
        const failureReason = message.includes("timed out")
          ? "primitive_timeout"
          : message.includes("aborted")
            ? "primitive_aborted"
            : "primitive_failed";

        return {
          ok: false,
          primitiveExecutionRef: createId("text_input_primitive"),
          message,
          startedAt,
          endedAt: new Date().toISOString(),
          portKind: "browser-controller",
          failureReason,
        };
      }
    },
  };
}