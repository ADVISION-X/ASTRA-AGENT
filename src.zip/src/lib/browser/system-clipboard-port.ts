import { spawn } from "node:child_process";

import type { ClipboardPort, ClipboardReadResult, ClipboardWriteResult } from "../../capabilities/text-input/ports/clipboard-port.js";

function readClipboardText(): Promise<string> {
  return new Promise((resolve, reject) => {
    const child = spawn("pbpaste", [], { stdio: ["ignore", "pipe", "pipe"] });
    let stdout = "";
    let stderr = "";

    child.stdout?.on("data", (chunk) => {
      stdout += String(chunk);
    });
    child.stderr?.on("data", (chunk) => {
      stderr += String(chunk);
    });
    child.once("error", reject);
    child.once("exit", (code) => {
      if (code === 0) {
        resolve(stdout);
        return;
      }

      reject(new Error(stderr.trim() || `pbpaste exited with code ${code ?? "unknown"}`));
    });
  });
}

function writeClipboardText(text: string): Promise<void> {
  return new Promise((resolve, reject) => {
    const child = spawn("pbcopy", [], { stdio: ["pipe", "ignore", "pipe"] });
    let stderr = "";

    child.stderr?.on("data", (chunk) => {
      stderr += String(chunk);
    });
    child.once("error", reject);
    child.once("exit", (code) => {
      if (code === 0) {
        resolve();
        return;
      }

      reject(new Error(stderr.trim() || `pbcopy exited with code ${code ?? "unknown"}`));
    });
    child.stdin?.end(text);
  });
}

export function createSystemClipboardPort(): ClipboardPort {
  return {
    async readText(): Promise<ClipboardReadResult> {
      try {
        const text = await readClipboardText();
        return {
          ok: true,
          text,
          message: "clipboard read succeeded",
          portKind: "system-clipboard",
        };
      } catch (error) {
        return {
          ok: false,
          text: null,
          message: error instanceof Error ? error.message : "clipboard read failed",
          portKind: "system-clipboard",
        };
      }
    },
    async writeText(text: string): Promise<ClipboardWriteResult> {
      try {
        await writeClipboardText(text);
        return {
          ok: true,
          message: "clipboard write succeeded",
          portKind: "system-clipboard",
        };
      } catch (error) {
        return {
          ok: false,
          message: error instanceof Error ? error.message : "clipboard write failed",
          portKind: "system-clipboard",
        };
      }
    },
  };
}