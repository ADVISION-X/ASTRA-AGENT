import type { IncomingMessage, ServerResponse } from "node:http";
import type { URL } from "node:url";

import { createId } from "../lib/local-runtime/ids.js";
import { GrassEyeWorkbench } from "../lib/local-runtime/workbench.js";
import { parseJsonBody } from "./workbench-api-helpers.js";

function normalizeRequestedPlatformId(value?: string): "tiktok-web" | null {
  if (value === "tiktok-web") {
    return value;
  }

  return null;
}

function normalizePositiveInteger(value: unknown, max: number): number | undefined {
  if (typeof value !== "number" || !Number.isInteger(value) || value < 1 || value > max) {
    return undefined;
  }

  return value;
}

export async function handleTaskRequest(
  request: IncomingMessage,
  response: ServerResponse,
  activeWorkbench: GrassEyeWorkbench,
  url: URL,
): Promise<boolean> {
  if (request.method === "POST" && url.pathname === "/api/tasks/start") {
    const body = await parseJsonBody(request) as {
      humanGoal?: string;
      taskTemplateId?: string;
      requestedPlatformId?: string;
      selectedMapId?: string;
      targetProfileRef?: string;
      maxRounds?: number;
      maxMinutes?: number;
    };
    const traceId = createId("trace");
    const attemptId = createId("attempt");
    const taskTemplateId = body.taskTemplateId?.trim() || null;
    const requestedPlatformId = normalizeRequestedPlatformId(body.requestedPlatformId);
    const selectedMapId = body.selectedMapId?.trim() || null;
    const humanGoal = body.humanGoal?.trim() || null;
    const maxRounds = normalizePositiveInteger(body.maxRounds, 9);
    const maxMinutes = normalizePositiveInteger(body.maxMinutes, 180);
    await activeWorkbench.recordCommanderDebugEvent({
      eventType: "HUMAN_COMMAND_DRAFTED",
      status: "started",
      traceId,
      spanId: "human-command-drafted",
      attemptId,
      mapId: selectedMapId,
      taskTemplateId,
      reason: "Commander Console start-mission payload drafted from the local app shell request body.",
      actionableMessage: "Persist the governed human-command draft before validation.",
      ownerResponsible: "Commander Console / Local App Shell",
    });
    await activeWorkbench.recordCommanderDebugEvent({
      eventType: "HUMAN_COMMAND_RECEIVED",
      status: "started",
      traceId,
      spanId: "human-command-received",
      attemptId,
      mapId: selectedMapId,
      taskTemplateId,
      reason: "Commander Console received a start-mission request from the local app shell.",
      actionableMessage: "Validate the human command payload before dispatching it.",
      ownerResponsible: "Commander Console / Local App Shell",
    });
    if (!requestedPlatformId || !selectedMapId) {
      const failureReason = "requestedPlatformId and selectedMapId are both required before mission start.";
      await activeWorkbench.recordCommanderDebugEvent({
        eventType: "COMMAND_REJECTED",
        status: "failed",
        traceId,
        spanId: "command-rejected",
        attemptId,
        mapId: selectedMapId,
        taskTemplateId,
        failureReason,
        actionableMessage: "Select a task template with a governed map binding before retrying.",
        ownerResponsible: "Commander Console / Orchestration",
      });
      response.writeHead(400, { "content-type": "application/json; charset=utf-8" });
      response.end(JSON.stringify({
        error: "requested_platform_and_map_required",
        actionableMessage: "任务无法启动，因为缺少 requestedPlatformId 或 selectedMapId。",
        failureReason,
        nextAction: "选择一个已绑定地图的平台任务模板后再试。",
        ownerResponsible: "Commander Console / Orchestration",
        traceId,
        attemptId,
      }));
      return true;
    }

    await activeWorkbench.recordCommanderDebugEvent({
      eventType: "HUMAN_COMMAND_VALIDATED",
      status: "success",
      traceId,
      spanId: "human-command-validated",
      attemptId,
      mapId: selectedMapId,
      taskTemplateId,
      reason: `requestedPlatformId=${requestedPlatformId}; selectedMapId=${selectedMapId}`,
      actionableMessage: "Run mission preflight before dispatching the governed human command.",
      ownerResponsible: "Commander Console",
    });
    await activeWorkbench.recordCommanderDebugEvent({
      eventType: "MISSION_PREFLIGHT_STARTED",
      status: "started",
      traceId,
      spanId: "mission-preflight-started",
      attemptId,
      mapId: selectedMapId,
      taskTemplateId,
      reason: "Mission preflight is checking readiness before command dispatch.",
      actionableMessage: "Verify browser session, local AI, map binding, and Forensics storage before mission start.",
      ownerResponsible: "Commander Console / Orchestration",
    });

    const preflight = await activeWorkbench.getMissionStartPreflight({
      requestedPlatformId,
      selectedMapId,
    });
    const localAiComponent = preflight.components.find((component) => component.name === "localAi");
    await activeWorkbench.recordCommanderDebugEvent({
      eventType: "LOCAL_AI_READINESS_STARTED",
      status: "started",
      traceId,
      spanId: "local-ai-readiness-started",
      attemptId,
      mapId: selectedMapId,
      taskTemplateId,
      reason: "Mission preflight is evaluating local AI readiness.",
      actionableMessage: "Confirm Ollama reachability and local model availability.",
      ownerResponsible: "AI Capability / Local AI Runtime",
    });
    if (localAiComponent && !localAiComponent.ok) {
      await activeWorkbench.recordCommanderDebugEvent({
        eventType: "LOCAL_AI_READINESS_DEGRADED",
        status: "failed",
        traceId,
        spanId: "local-ai-readiness-degraded",
        attemptId,
        mapId: selectedMapId,
        taskTemplateId,
        failureReason: localAiComponent.detail,
        actionableMessage: localAiComponent.actionableMessage,
        ownerResponsible: localAiComponent.ownerResponsible,
      });
      await activeWorkbench.recordCommanderDebugEvent({
        eventType: "LOCAL_AI_READINESS_BLOCKING_REASON",
        status: "failed",
        traceId,
        spanId: "local-ai-readiness-blocking-reason",
        attemptId,
        mapId: selectedMapId,
        taskTemplateId,
        failureReason: localAiComponent.detail,
        actionableMessage: localAiComponent.actionableMessage,
        ownerResponsible: localAiComponent.ownerResponsible,
      });
    }
    if (preflight.status === "blocked") {
      await activeWorkbench.recordCommanderDebugEvent({
        eventType: "MISSION_PREFLIGHT_FAILED",
        status: "failed",
        traceId,
        spanId: "mission-preflight-failed",
        attemptId,
        mapId: selectedMapId,
        taskTemplateId,
        failureReason: preflight.failureReason,
        actionableMessage: preflight.nextAction,
        ownerResponsible: preflight.ownerResponsible,
      });
      await activeWorkbench.recordCommanderDebugEvent({
        eventType: "COMMAND_REJECTED",
        status: "failed",
        traceId,
        spanId: "command-rejected",
        attemptId,
        mapId: selectedMapId,
        taskTemplateId,
        failureReason: preflight.failureReason,
        actionableMessage: preflight.nextAction,
        ownerResponsible: preflight.ownerResponsible,
      });
      response.writeHead(409, { "content-type": "application/json; charset=utf-8" });
      response.end(JSON.stringify({
        error: "mission_preflight_failed",
        actionableMessage: preflight.actionableMessage,
        failureReason: preflight.failureReason,
        nextAction: preflight.nextAction,
        ownerResponsible: preflight.ownerResponsible,
        traceId,
        attemptId,
        components: preflight.components,
      }, null, 2));
      return true;
    }
    await activeWorkbench.recordCommanderDebugEvent({
      eventType: "MISSION_PREFLIGHT_PASSED",
      status: "success",
      traceId,
      spanId: "mission-preflight-passed",
      attemptId,
      mapId: selectedMapId,
      taskTemplateId,
      reason: preflight.actionableMessage,
      actionableMessage: "Dispatch the governed human command through Commander Console and Nerve Bus.",
      ownerResponsible: "Commander Console / Nerve Bus",
    });

    const result = await activeWorkbench.commanderConsole.execute({
      childCapabilityId: "issue-human-command",
      operatorRef: "commander-console:http",
      input: {
        commandType: "start-mission",
        requestedPlatformId,
        selectedMapId,
        humanGoal,
        maxRounds,
        maxMinutes,
        initialPayload: {
          kind: "start-mission",
          requestedBy: "commander-console",
          requestedPlatformId,
          selectedMapId,
          ...(humanGoal ? { humanGoal } : {}),
          ...(maxRounds ? { maxRounds } : {}),
          ...(maxMinutes ? { maxMinutes } : {}),
        },
      },
    });
    const resultMessage = result.output !== null
      && typeof result.output === "object"
      && "message" in result.output
      && typeof result.output.message === "string"
      ? result.output.message
      : "Commander Console completed the governed human command dispatch.";
    const targetMissionId = result.output !== null
      && typeof result.output === "object"
      && "targetMissionId" in result.output
      && typeof result.output.targetMissionId === "string"
      ? result.output.targetMissionId
      : null;
    if (result.status === "success") {
      await activeWorkbench.recordCommanderDebugEvent({
        eventType: "COMMAND_ACCEPTED",
        status: "success",
        traceId,
        spanId: "command-accepted",
        attemptId,
        missionId: targetMissionId,
        mapId: selectedMapId,
        taskTemplateId,
        reason: resultMessage,
        actionableMessage: "Mission dispatch succeeded. Monitor the mission page and runtime proof timeline.",
        ownerResponsible: "Commander Console / Nerve Bus / Orchestration",
      });
      response.writeHead(200, { "content-type": "application/json; charset=utf-8" });
      response.end(JSON.stringify(result, null, 2));
      return true;
    }

    await activeWorkbench.recordCommanderDebugEvent({
      eventType: "COMMAND_REJECTED",
      status: result.status === "review_required" ? "review_required" : "failed",
      traceId,
      spanId: "command-rejected",
      attemptId,
      missionId: targetMissionId,
      mapId: selectedMapId,
      taskTemplateId,
      failureReason: result.failureReason ?? result.reviewRequiredReason ?? resultMessage,
      actionableMessage: result.reviewRequiredReason
        ? "Open the review queue and inspect the guarded command result before retrying."
        : "Inspect the latest debug bundle and fix the blocking dependency before retrying.",
      ownerResponsible: "Commander Console / Nerve Bus / Orchestration",
    });
    response.writeHead(409, { "content-type": "application/json; charset=utf-8" });
    response.end(JSON.stringify({
      ...result,
      traceId,
      attemptId,
    }, null, 2));
    return true;
  }

  if (request.method === "POST" && url.pathname === "/api/tasks/pause") {
    const body = await parseJsonBody(request) as { targetMissionId?: string; reason?: string };
    const result = await activeWorkbench.commanderConsole.execute({
      childCapabilityId: "pause-mission",
      operatorRef: "commander-console:http",
      input: {
        targetMissionId: body.targetMissionId?.trim() || null,
        operatorNote: body.reason?.trim() || null,
      },
    });
    response.writeHead(200, { "content-type": "application/json; charset=utf-8" });
    response.end(JSON.stringify(result, null, 2));
    return true;
  }

  if (request.method === "POST" && url.pathname === "/api/tasks/resume") {
    const body = await parseJsonBody(request) as { targetMissionId?: string; reason?: string };
    const result = await activeWorkbench.commanderConsole.execute({
      childCapabilityId: "resume-mission",
      operatorRef: "commander-console:http",
      input: {
        targetMissionId: body.targetMissionId?.trim() || null,
        operatorNote: body.reason?.trim() || null,
      },
    });
    response.writeHead(200, { "content-type": "application/json; charset=utf-8" });
    response.end(JSON.stringify(result, null, 2));
    return true;
  }

  if (request.method === "POST" && url.pathname === "/api/tasks/stop") {
    const body = await parseJsonBody(request) as { reason?: string };
    const result = await activeWorkbench.commanderConsole.execute({
      childCapabilityId: "stop-mission",
      operatorRef: "commander-console:http",
      input: { operatorNote: body.reason?.trim() || null },
    });
    response.writeHead(200, { "content-type": "application/json; charset=utf-8" });
    response.end(JSON.stringify(result, null, 2));
    return true;
  }

  if (request.method === "POST" && url.pathname === "/api/tasks/emergency-stop") {
    const body = await parseJsonBody(request) as { reason?: string; targetMissionId?: string };
    const result = await activeWorkbench.commanderConsole.execute({
      childCapabilityId: "emergency-stop",
      operatorRef: "commander-console:http",
      input: {
        targetMissionId: body.targetMissionId?.trim() || null,
        operatorNote: body.reason?.trim() || null,
      },
    });
    response.writeHead(200, { "content-type": "application/json; charset=utf-8" });
    response.end(JSON.stringify(result, null, 2));
    return true;
  }

  return false;
}