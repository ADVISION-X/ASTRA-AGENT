import type { Locale } from "../../lib/localization/dictionaries.js";
import { getDefaultMapPluginRegistry } from "../../map-plugins/registry/map-plugin-registry.js";

import { localizeCommanderText } from "./locale.js";
import type { CommanderConsoleTaskTemplate } from "./types.js";

export function buildCommanderTaskTemplates(locale: Locale): CommanderConsoleTaskTemplate[] {
  return getDefaultMapPluginRegistry().active.listApprovedTaskTemplates().map((definition) => {
    const template: CommanderConsoleTaskTemplate = {
      taskTemplateId: definition.taskTemplateId,
      version: definition.version,
      recommended: definition.recommended,
      taskCategory: definition.taskCategory,
      defaultRunLimit: definition.defaultRunLimit,
      maxAllowedRunLimit: definition.maxAllowedRunLimit,
      safetyLevel: definition.safetyLevel,
      mapBinding: {
        requestedPlatformId: definition.requestedPlatformId,
        platformProfileRef: definition.platformProfileRef,
        targetProfileRef: definition.targetProfileRef,
        mapId: definition.mapId,
      },
      userVisibleCapabilities: definition.userVisibleCapabilities,
      advancedFields: {
        aiMode: localizeCommanderText(locale, "受控地图包", "governed map package"),
        logLevel: "debug",
      },
      availability: definition.availability,
      displayName: definition.displayName,
      description: definition.description,
      defaultHumanGoal: definition.defaultHumanGoal,
    };

    return template;
  });
}