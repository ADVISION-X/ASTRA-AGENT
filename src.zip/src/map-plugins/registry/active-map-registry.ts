import type { OperationalMap } from "../../capabilities/orchestration/contract.js";
import type { MapActivationRecord } from "../shared/map-package-proof.js";
import type { ActiveTaskTemplateFeedItem, MapPackage } from "../shared/map-package-types.js";

type ActiveRegistration = {
  mapPackage: MapPackage;
  activationRecord: MapActivationRecord;
};

function toOperationalMap(mapPackage: MapPackage): OperationalMap {
  const { mapVersion: _mapVersion, proofPolicy: _proofPolicy, ...operationalMap } = mapPackage.operationalMap;
  return operationalMap;
}

export class ActiveMapRegistry {
  private readonly activeByMapId = new Map<string, ActiveRegistration>();

  activate(mapPackage: MapPackage, activationRecord: MapActivationRecord): void {
    this.activeByMapId.set(mapPackage.manifest.mapId, { mapPackage, activationRecord });
  }

  deactivate(mapId: string): void {
    this.activeByMapId.delete(mapId);
  }

  getOperationalMap(mapId: string): OperationalMap | null {
    const registration = this.activeByMapId.get(mapId);
    return registration ? toOperationalMap(registration.mapPackage) : null;
  }

  getRegistration(mapId: string): ActiveRegistration | null {
    return this.activeByMapId.get(mapId) ?? null;
  }

  resolvePreferredMapId(requestedPlatformId: string): string | null {
    for (const registration of this.activeByMapId.values()) {
      if (registration.mapPackage.taskTemplate.requestedPlatformId === requestedPlatformId) {
        return registration.mapPackage.manifest.mapId;
      }
    }
    return null;
  }

  listActivePackages(): MapPackage[] {
    return [...this.activeByMapId.values()].map((registration) => registration.mapPackage);
  }

  listApprovedTaskTemplates(): ActiveTaskTemplateFeedItem[] {
    return [...this.activeByMapId.values()].map((registration) => ({
      packageId: registration.mapPackage.manifest.packageId,
      packageVersion: registration.mapPackage.manifest.packageVersion,
      activationId: registration.activationRecord.activationId,
      mapId: registration.mapPackage.manifest.mapId,
      taskTemplateId: registration.mapPackage.taskTemplate.taskTemplateId,
      displayName: registration.mapPackage.taskTemplate.displayName,
      description: registration.mapPackage.taskTemplate.description,
      recommended: registration.mapPackage.taskTemplate.recommended,
      taskCategory: registration.mapPackage.taskTemplate.taskCategory,
      version: registration.mapPackage.taskTemplate.version,
      defaultRunLimit: registration.mapPackage.taskTemplate.defaultRunLimit,
      maxAllowedRunLimit: registration.mapPackage.taskTemplate.maxAllowedRunLimit,
      safetyLevel: registration.mapPackage.taskTemplate.safetyLevel,
      userVisibleCapabilities: registration.mapPackage.taskTemplate.userVisibleCapabilities,
      availability: registration.mapPackage.taskTemplate.availabilityPolicy === "active" ? "ready" : "disabled",
      defaultHumanGoal: registration.mapPackage.taskTemplate.defaultHumanGoal,
      requestedPlatformId: registration.mapPackage.taskTemplate.requestedPlatformId,
      platformProfileRef: registration.mapPackage.taskTemplate.platformProfileRef,
      targetProfileRef: registration.mapPackage.taskTemplate.targetProfileRef
    }));
  }
}
