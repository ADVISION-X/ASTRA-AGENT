import { z } from "zod";

import { OperationalMapSchema } from "../../capabilities/orchestration/schema.js";

export const OperationalMapProofPolicySchema = z.object({
  runtimeProof: z.literal("required"),
  recordPackageSelection: z.literal(true)
}).strict();

export const OperationalMapPackageSchema = z.object({
  mapVersion: z.string().min(1),
  proofPolicy: OperationalMapProofPolicySchema
}).passthrough().superRefine((value, context) => {
  const { mapVersion: _mapVersion, proofPolicy: _proofPolicy, ...operationalMap } = value;
  const parsed = OperationalMapSchema.safeParse(operationalMap);
  if (parsed.success) {
    return;
  }

  for (const issue of parsed.error.issues) {
    context.addIssue(issue);
  }
}).transform((value) => {
  const { mapVersion, proofPolicy, ...operationalMap } = value;
  return {
    ...OperationalMapSchema.parse(operationalMap),
    mapVersion,
    proofPolicy
  };
});
