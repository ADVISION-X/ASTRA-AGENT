import type { MapPackageValidationIssue } from "../shared/map-package-failure.js";
import type { MapPackage } from "../shared/map-package-types.js";

const ALLOWED_ABILITY_GROUPS = new Set([
  "open",
  "screenshot",
  "ai",
  "visual-target",
  "geometry-guard",
  "mouse-click",
  "mouse-scroll",
  "post-action-verification",
  "forensics-persistence",
  "page-state"
]);

export function validateCapabilityRegistry(mapPackage: MapPackage): MapPackageValidationIssue[] {
  const issues: MapPackageValidationIssue[] = [];
  for (const step of mapPackage.operationalMap.steps) {
    if (step.targetAbilityGroupId && !ALLOWED_ABILITY_GROUPS.has(step.targetAbilityGroupId)) {
      issues.push({
        code: "missing_dependency",
        message: `Target ability group ${step.targetAbilityGroupId} is outside the governed registry allowlist.`,
        path: `operationalMap.steps.${step.stepId}`,
        severity: "fatal"
      });
    }
  }
  return issues;
}
