import type { MapPackageValidationIssue } from "../shared/map-package-failure.js";
import type { MapPackage } from "../shared/map-package-types.js";

function isTargetAbilityGroup(
  targetAbilityGroupId: MapPackage["operationalMap"]["steps"][number]["targetAbilityGroupId"],
  expected: string
): boolean {
  return targetAbilityGroupId === expected;
}

export function validateMapDryRun(mapPackage: MapPackage): MapPackageValidationIssue[] {
  const issues: MapPackageValidationIssue[] = [];
  const steps = mapPackage.operationalMap.steps;
  const stepIndex = new Map(steps.map((step, index) => [step.stepId, index]));

  const aiStepIndex = steps.findIndex((step) => step.stepKind === "ai");
  if (aiStepIndex >= 0) {
    const hasPrepareAiInput = steps.some((step, index) => index < aiStepIndex && step.childCapabilityId.includes("prepare-ai-input"));
    if (!hasPrepareAiInput) {
      issues.push({
        code: "missing_dependency",
        message: "AI vision step requires a preceding prepare-ai-input step.",
        path: "operationalMap.steps",
        severity: "error"
      });
    }
  }

  const clickStepIndex = steps.findIndex((step) => isTargetAbilityGroup(step.targetAbilityGroupId, "mouse-click"));
  if (clickStepIndex >= 0) {
    const hasVisualTarget = steps.some((step, index) => index < clickStepIndex && isTargetAbilityGroup(step.targetAbilityGroupId, "visual-target"));
    const hasGeometryGuard = steps.some((step, index) => index < clickStepIndex && isTargetAbilityGroup(step.targetAbilityGroupId, "geometry-guard"));
    if (!hasVisualTarget || !hasGeometryGuard) {
      issues.push({
        code: "missing_dependency",
        message: "mouse-click step requires preceding visual-target and geometry-guard steps.",
        path: "operationalMap.steps",
        severity: "error"
      });
    }
    const hasVerification = steps.some((step, index) => index > clickStepIndex && isTargetAbilityGroup(step.targetAbilityGroupId, "post-action-verification"));
    if (!hasVerification) {
      issues.push({
        code: "missing_dependency",
        message: "Action step requires a following post-action-verification step.",
        path: "operationalMap.steps",
        severity: "error"
      });
    }
  }

  const hasForensics = steps.some((step) => isTargetAbilityGroup(step.targetAbilityGroupId, "forensics-persistence"));
  if (!hasForensics) {
    issues.push({
      code: "missing_dependency",
      message: "Operational map must route evidence output into forensics-persistence.",
      path: "operationalMap.steps",
      severity: "error"
    });
  }

  for (const binding of mapPackage.promptBindings.bindings) {
    if (!stepIndex.has(binding.stepId)) {
      issues.push({
        code: "missing_prompt_contract",
        message: `Prompt binding step ${binding.stepId} does not exist in operationalMap.steps.`,
        path: "promptBindings.bindings",
        severity: "error"
      });
    }
  }

  return issues;
}
