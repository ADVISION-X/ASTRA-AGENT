import type { z } from "zod";
import {
  RuntimeProofSchema,
  type MissionHumanCommandKindSchema,
  type MissionInternalOperationKindSchema,
  type SelectedMapSourceSchema,
  type AllowedAbilityGroupIdSchema,
  type AbortDecisionSchema,
  type NerveBusDispatchDecisionSchema,
  type TransitionEvaluationDecisionSchema,
  type TransitionConditionSourceSchema,
} from "../schema.js";
import type { OperationalMapId } from "../contract.js";

export type BuildProofInput = {
  missionId: string;
  mapId: OperationalMapId;
  selectedMapSource?: z.output<typeof SelectedMapSourceSchema> | null;
  stepId: string;
  targetAbilityGroupId?: z.output<typeof AllowedAbilityGroupIdSchema> | null;
  targetChildCapabilityId?: string | null;
  childCapabilityId: string;
  commandKind: z.output<typeof MissionHumanCommandKindSchema>;
  internalOperationKind?: z.output<typeof MissionInternalOperationKindSchema> | null;
  caller: "commander-console" | "orchestration";
  idempotencyKey: string;
  sequenceNo: number;
  stateRevisionBefore?: number | null;
  stateRevisionAfter?: number | null;
  stateHashBefore?: string | null;
  stateHashAfter?: string | null;
  stepDispatchCallId?: string | null;
  stepTimeoutMs?: number | null;
  timeoutDecision?: z.output<typeof AbortDecisionSchema> | null;
  abortDecision?: z.output<typeof AbortDecisionSchema> | null;
  nerveBusEnvelopeId?: string | null;
  nerveBusDispatchDecision?: z.output<typeof NerveBusDispatchDecisionSchema> | null;
  transitionId?: string | null;
  transitionEvaluationDecision?: z.output<typeof TransitionEvaluationDecisionSchema> | null;
  transitionConditionSource?: z.output<typeof TransitionConditionSourceSchema> | null;
  transitionConditionExpected?: string | boolean | null;
  transitionConditionActual?: string | boolean | null;
  inputRef?: string | null;
  outputRef?: string | null;
  abilityResultRef?: string | null;
  reviewDispatchEnvelopeId?: string | null;
  finalizationDecision?: "finalized" | "pending" | "skipped" | null;
  structuredRuntimeEventRef?: string | null;
  previousStepId?: string | null;
  nextStepId?: string | null;
  startedAt: string;
  endedAt: string;
  durationMs: number;
  status: "completed" | "failed" | "review_required" | "stopped";
  failureReason?: string | null;
  reviewRequiredReason?: string | null;
  mapDecision: "selected" | "rejected";
  transitionDecision: "continue" | "finalize" | "review_required" | "failed";
  loopDecision: "continue" | "stop_completed" | "stop_failed" | "stop_review_required";
  stateDecision: "created" | "updated" | "paused" | "resumed" | "stopped" | "emergency_stopped" | "finalized";
  emergencyDecision: "none" | "latched" | "executed";
  dataQualityFlags?: string[];
};

export function buildOrchestrationRuntimeProof(input: BuildProofInput) {
  return RuntimeProofSchema.parse({
    proofId: `${input.missionId}:${input.sequenceNo}:${input.stepId}`,
    missionId: input.missionId,
    mapId: input.mapId,
    selectedMapSource: input.selectedMapSource ?? null,
    stepId: input.stepId,
    targetAbilityGroupId: input.targetAbilityGroupId ?? null,
    targetChildCapabilityId: input.targetChildCapabilityId ?? null,
    childCapabilityId: input.childCapabilityId,
    commandKind: input.commandKind,
    internalOperationKind: input.internalOperationKind ?? null,
    caller: input.caller,
    idempotencyKey: input.idempotencyKey,
    sequenceNo: input.sequenceNo,
    stateRevisionBefore: input.stateRevisionBefore ?? null,
    stateRevisionAfter: input.stateRevisionAfter ?? null,
    stateHashBefore: input.stateHashBefore ?? null,
    stateHashAfter: input.stateHashAfter ?? null,
    stepDispatchCallId: input.stepDispatchCallId ?? null,
    stepTimeoutMs: input.stepTimeoutMs ?? null,
    timeoutDecision: input.timeoutDecision ?? null,
    abortDecision: input.abortDecision ?? null,
    nerveBusEnvelopeId: input.nerveBusEnvelopeId ?? null,
    nerveBusDispatchDecision: input.nerveBusDispatchDecision ?? null,
    transitionId: input.transitionId ?? null,
    transitionEvaluationDecision: input.transitionEvaluationDecision ?? null,
    transitionConditionSource: input.transitionConditionSource ?? null,
    transitionConditionExpected: input.transitionConditionExpected ?? null,
    transitionConditionActual: input.transitionConditionActual ?? null,
    inputRef: input.inputRef ?? null,
    outputRef: input.outputRef ?? null,
    abilityResultRef: input.abilityResultRef ?? null,
    reviewDispatchEnvelopeId: input.reviewDispatchEnvelopeId ?? null,
    finalizationDecision: input.finalizationDecision ?? null,
    structuredRuntimeEventRef: input.structuredRuntimeEventRef ?? null,
    previousStepId: input.previousStepId ?? null,
    nextStepId: input.nextStepId ?? null,
    startedAt: input.startedAt,
    endedAt: input.endedAt,
    durationMs: input.durationMs,
    status: input.status,
    failureReason: input.failureReason ?? null,
    reviewRequiredReason: input.reviewRequiredReason ?? null,
    mapDecision: input.mapDecision,
    transitionDecision: input.transitionDecision,
    loopDecision: input.loopDecision,
    stateDecision: input.stateDecision,
    emergencyDecision: input.emergencyDecision,
    dataQualityFlags: input.dataQualityFlags ?? [],
  });
}
