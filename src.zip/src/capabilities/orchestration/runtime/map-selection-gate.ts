import type { MissionCommand, OperationalMap } from "../contract.js";
import { OperationalMapSchema } from "../schema.js";
import type { OrchestrationMapStorePort } from "../ports/orchestration-map-store-port.js";

export type SelectedMapSource =
  | "preferred_map_id"
  | "initial_payload_map_id"
  | "platform_policy"
  | "rejected_missing";

export type MapSelectionResult =
  | { selected: true; map: OperationalMap; selectedMapSource: Exclude<SelectedMapSource, "rejected_missing"> }
  | { selected: false; selectedMapSource: "rejected_missing"; failureReason: string };

export async function selectOperationalMap(input: {
  command: MissionCommand;
  mapStore: OrchestrationMapStorePort;
}): Promise<MapSelectionResult> {
  if (input.command.preferredMapId) {
    const map = await input.mapStore.getMap(input.command.preferredMapId);
    if (!map) {
      return {
        selected: false,
        selectedMapSource: "rejected_missing",
        failureReason: `Preferred map id "${input.command.preferredMapId}" is not registered.`,
      };
    }
    return { selected: true, map: OperationalMapSchema.parse(map), selectedMapSource: "preferred_map_id" };
  }

  if (input.command.initialPayload.selectedMapId) {
    const map = await input.mapStore.getMap(input.command.initialPayload.selectedMapId);
    if (!map) {
      return {
        selected: false,
        selectedMapSource: "rejected_missing",
        failureReason: `Initial payload map id "${input.command.initialPayload.selectedMapId}" is not registered.`,
      };
    }
    return { selected: true, map: OperationalMapSchema.parse(map), selectedMapSource: "initial_payload_map_id" };
  }

  const platformPolicyMapId = await input.mapStore.resolvePreferredMapId(input.command.requestedPlatform);

  if (platformPolicyMapId) {
    const map = await input.mapStore.getMap(platformPolicyMapId);
    if (!map) {
      return {
        selected: false,
        selectedMapSource: "rejected_missing",
        failureReason: `Platform policy map id "${platformPolicyMapId}" is not registered.`,
      };
    }
    return { selected: true, map: OperationalMapSchema.parse(map), selectedMapSource: "platform_policy" };
  }

  return {
    selected: false,
    selectedMapSource: "rejected_missing",
    failureReason: `No map id could be determined for platform "${input.command.requestedPlatform}".`,
  };
}

export function createStaticOrchestrationMapStore(maps: readonly OperationalMap[]): OrchestrationMapStorePort {
  const mapById = new Map(maps.map((map) => [map.mapId, map]));
  return {
    async getMap(mapId) {
      return mapById.get(mapId) ?? null;
    },
    async listMaps() {
      return maps;
    },
    async resolvePreferredMapId(_requestedPlatformId) {
      return null;
    },
  };
}
