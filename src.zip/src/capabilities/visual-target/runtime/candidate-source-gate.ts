import type { ParsedVisualTargetAbilityInput, VisualTargetCandidate, VisualTargetDataQualityFlag, VisualTargetFailureReason } from "../contract.js";
import type { ResolvedVisualTargetProfile } from "./visual-target-input-gate.js";
import { parseVisualTargetIsoTimestamp } from "./visual-target-clock.js";
import {
  collectVisualTargetFlags,
  createVisualTargetGateBlocked,
  createVisualTargetGateReviewRequired,
  createVisualTargetGateSuccess,
  type VisualTargetGateBlocked,
  type VisualTargetGateReviewRequired,
  type VisualTargetGateSuccess,
} from "./visual-target-gate-results.js";

type CandidateSourceAllow = VisualTargetGateSuccess<"allow", {
  bindingDecision: "allow";
  candidates: VisualTargetCandidate[];
  rejectedCandidateRefs: string[];
}>;

type CandidateSourceBlocked = VisualTargetGateBlocked<"block", {
  bindingDecision: "block";
  rejectedCandidateRefs: string[];
}>;

type CandidateSourceReviewRequired = VisualTargetGateReviewRequired<"review_required", {
  bindingDecision: "review_required";
  rejectedCandidateRefs: string[];
}>;

type CandidateSourceInspection = {
  acceptedCandidate: VisualTargetCandidate | null;
  rejectedCandidateRef: string | null;
  dataQualityFlag: VisualTargetDataQualityFlag | null;
  failure: CandidateSourceReviewRequired | null;
};

const EMPTY_CANDIDATE_SOURCE_INSPECTION: CandidateSourceInspection = {
  acceptedCandidate: null,
  rejectedCandidateRef: null,
  dataQualityFlag: null,
  failure: null,
};

function createCandidateSourceBlocked(
  failureReason: VisualTargetFailureReason,
  statusMessage: string,
  rejectedCandidateRefs: string[],
  dataQualityFlags: VisualTargetDataQualityFlag[],
): CandidateSourceBlocked {
  return createVisualTargetGateBlocked({
    decision: "block",
    failureReason,
    statusMessage,
    dataQualityFlags,
    extra: { bindingDecision: "block", rejectedCandidateRefs },
  });
}

function createCandidateSourceReview(
  input: {
    failureReason: VisualTargetFailureReason;
    statusMessage: string;
    reviewRequiredReason: string;
    rejectedCandidateRefs: string[];
    dataQualityFlags: VisualTargetDataQualityFlag[];
  },
): CandidateSourceReviewRequired {
  return createVisualTargetGateReviewRequired({
    decision: "review_required",
    failureReason: input.failureReason,
    statusMessage: input.statusMessage,
    reviewRequiredReason: input.reviewRequiredReason,
    dataQualityFlags: input.dataQualityFlags,
    extra: { bindingDecision: "review_required", rejectedCandidateRefs: input.rejectedCandidateRefs },
  });
}

function createRejectedCandidateSourceInspection(
  rejectedCandidateRef: string,
  dataQualityFlag: VisualTargetDataQualityFlag,
): CandidateSourceInspection {
  return { acceptedCandidate: null, rejectedCandidateRef, dataQualityFlag, failure: null };
}

function createAcceptedCandidateSourceInspection(candidate: VisualTargetCandidate): CandidateSourceInspection {
  return { acceptedCandidate: candidate, rejectedCandidateRef: null, dataQualityFlag: null, failure: null };
}

function createOperatorApprovalInspection(candidateRef: string): CandidateSourceInspection {
  return {
    acceptedCandidate: null,
    rejectedCandidateRef: null,
    dataQualityFlag: null,
    failure: createCandidateSourceReview({
      failureReason: "operator_approval_required",
      statusMessage: "operator_manual candidate requires operator approval proof.",
      reviewRequiredReason: "Visual Target requires operator approval proof for operator_manual candidate sources.",
      rejectedCandidateRefs: [candidateRef],
      dataQualityFlags: ["operator_manual_review_required"],
    }),
  };
}

function findCandidateSourceBindingInspection(input: {
  request: ParsedVisualTargetAbilityInput;
  profile: ResolvedVisualTargetProfile;
  candidate: VisualTargetCandidate;
}): CandidateSourceInspection | null {
  const { candidate } = input;
  if (candidate.sourceProofRef !== input.request.sourceProof.sourceProofRef) {
    return createRejectedCandidateSourceInspection(candidate.candidateRef, "candidate_source_binding_mismatch");
  }
  if (!input.profile.allowedCandidateKinds.includes(candidate.candidateKind)) {
    return createRejectedCandidateSourceInspection(candidate.candidateRef, "candidate_source_kind_mismatch");
  }
  return candidate.candidateKind === "ai_candidate" && !candidate.sourceFrameRef
    ? createRejectedCandidateSourceInspection(candidate.candidateRef, "candidate_source_frame_missing")
    : null;
}

function findOperatorManualInspection(input: {
  request: ParsedVisualTargetAbilityInput;
  profile: ResolvedVisualTargetProfile;
  candidate: VisualTargetCandidate;
}): CandidateSourceInspection | null {
  const { candidate } = input;
  if (candidate.candidateKind !== "operator_manual") {
    return null;
  }
  if (!input.profile.allowOperatorManual) {
    return createRejectedCandidateSourceInspection(candidate.candidateRef, "operator_manual_review_required");
  }
  return !input.request.sourceProof.operatorApproval
    ? createOperatorApprovalInspection(candidate.candidateRef)
    : null;
}

function findCandidateSourceReadinessInspection(input: {
  candidate: VisualTargetCandidate;
  nowEpochMs: number;
  freshnessTtlMs: number;
}): CandidateSourceInspection | null {
  const { candidate } = input;
  if (candidate.blockedReason) {
    return createRejectedCandidateSourceInspection(candidate.candidateRef, "candidate_blocked");
  }
  if (!candidate.isVisible) {
    return createRejectedCandidateSourceInspection(candidate.candidateRef, "candidate_invisible");
  }

  const ageMs = Math.max(0, input.nowEpochMs - parseVisualTargetIsoTimestamp(candidate.capturedAt));
  return ageMs > input.freshnessTtlMs
    ? createRejectedCandidateSourceInspection(candidate.candidateRef, "stale_candidate")
    : null;
}

function inspectCandidateSourceCandidate(input: {
  request: ParsedVisualTargetAbilityInput;
  nowEpochMs: number;
  profile: ResolvedVisualTargetProfile;
  candidate: VisualTargetCandidate;
}): CandidateSourceInspection {
  const bindingInspection = findCandidateSourceBindingInspection(input);
  if (bindingInspection) {
    return bindingInspection;
  }
  const operatorManualInspection = findOperatorManualInspection(input);
  if (operatorManualInspection) {
    return operatorManualInspection;
  }
  const readinessInspection = findCandidateSourceReadinessInspection({
    candidate: input.candidate,
    nowEpochMs: input.nowEpochMs,
    freshnessTtlMs: input.profile.freshnessTtlMs,
  });
  return readinessInspection ?? createAcceptedCandidateSourceInspection(input.candidate);
}

function resolveEmptyCandidateSourceReviewReason(dataQualityFlags: Set<VisualTargetDataQualityFlag>): VisualTargetFailureReason | null {
  if (dataQualityFlags.has("candidate_source_frame_missing")) {
    return "candidate_source_frame_missing";
  }
  if (dataQualityFlags.has("candidate_source_binding_mismatch")) {
    return "candidate_source_binding_mismatch";
  }
  if (dataQualityFlags.has("candidate_invisible")) {
    return "invisible_candidate";
  }
  return dataQualityFlags.has("operator_manual_review_required") ? "operator_approval_required" : null;
}

function createEmptyCandidateSourceFailure(
  rejectedCandidateRefs: string[],
  dataQualityFlags: Set<VisualTargetDataQualityFlag>,
): CandidateSourceBlocked | CandidateSourceReviewRequired {
  const flags = collectVisualTargetFlags(dataQualityFlags);
  if (dataQualityFlags.has("candidate_blocked")) {
    return createCandidateSourceBlocked("blocked_candidate", "All visual target candidates were blocked by source policy.", rejectedCandidateRefs, flags);
  }
  const reviewReason = resolveEmptyCandidateSourceReviewReason(dataQualityFlags);
  if (reviewReason) {
    return createCandidateSourceReview({
      failureReason: reviewReason,
      statusMessage: "Visual Target requires review because no governed candidate survived source gating.",
      reviewRequiredReason: "Visual Target source gating left no bindable visible candidate for success.",
      rejectedCandidateRefs,
      dataQualityFlags: flags,
    });
  }
  return createCandidateSourceBlocked(
    "missing_candidate_source_proof",
    "Visual Target candidate source proof validation rejected every candidate.",
    rejectedCandidateRefs,
    flags,
  );
}

function collectCandidateSourceResults(input: {
  request: ParsedVisualTargetAbilityInput;
  nowEpochMs: number;
  profile: ResolvedVisualTargetProfile;
}): {
  candidates: VisualTargetCandidate[];
  rejectedCandidateRefs: string[];
  dataQualityFlags: Set<VisualTargetDataQualityFlag>;
  failure: CandidateSourceReviewRequired | null;
} {
  const candidates: VisualTargetCandidate[] = [];
  const rejectedCandidateRefs: string[] = [];
  const dataQualityFlags = new Set<VisualTargetDataQualityFlag>();

  for (const candidate of input.request.candidates) {
    const inspection = inspectCandidateSourceCandidate({ ...input, candidate });
    if (inspection.failure) {
      return { candidates, rejectedCandidateRefs, dataQualityFlags, failure: inspection.failure };
    }
    if (inspection.rejectedCandidateRef) {
      rejectedCandidateRefs.push(inspection.rejectedCandidateRef);
    }
    if (inspection.dataQualityFlag) {
      dataQualityFlags.add(inspection.dataQualityFlag);
    }
    if (inspection.acceptedCandidate) {
      candidates.push(inspection.acceptedCandidate);
    }
  }

  return { candidates, rejectedCandidateRefs, dataQualityFlags, failure: null };
}

export function validateCandidateSources(input: {
  request: ParsedVisualTargetAbilityInput;
  nowEpochMs: number;
  profile: ResolvedVisualTargetProfile;
}): CandidateSourceAllow | CandidateSourceBlocked | CandidateSourceReviewRequired {
  if (input.request.candidates.length === 0) {
    return createCandidateSourceBlocked("no_candidates", "Visual Target request contains no candidates.", [], []);
  }

  if (!input.profile.allowedSourceAbilityGroups.includes(input.request.sourceAbilityGroupId)) {
    return createCandidateSourceBlocked(
      "invalid_source_ability",
      "Visual Target sourceAbilityGroupId is outside the child policy allowlist.",
      [],
      [],
    );
  }

  const result = collectCandidateSourceResults(input);
  if (result.failure) {
    return result.failure;
  }

  if (result.candidates.length === 0) {
    return createEmptyCandidateSourceFailure(result.rejectedCandidateRefs, result.dataQualityFlags);
  }

  return createVisualTargetGateSuccess("allow", collectVisualTargetFlags(result.dataQualityFlags), {
    bindingDecision: "allow",
    candidates: result.candidates,
    rejectedCandidateRefs: result.rejectedCandidateRefs,
  });
}