import { z } from "zod";

import { MOUSE_CLICK_FAILURE_REASONS } from "./shared/mouse-click-failure.js";
import { DEFAULT_MOUSE_CLICK_SAFETY_POLICY } from "./shared/mouse-click-policy.js";
import {
  MOUSE_CLICK_ABORT_DECISIONS,
  MOUSE_CLICK_CIRCUIT_BREAKER_STATES,
  MOUSE_CLICK_CLOCK_KIND,
  MOUSE_CLICK_GEOMETRY_DECISIONS,
  MOUSE_CLICK_IDEMPOTENCY_DECISIONS,
  MOUSE_CLICK_POLICY_DECISIONS,
  MOUSE_CLICK_PRIMITIVE_DECISIONS,
  MOUSE_CLICK_SAFETY_DECISIONS,
  MOUSE_CLICK_TIMEOUT_DECISIONS,
  MOUSE_CLICK_VERIFICATION_REF_POLICY,
} from "./shared/mouse-click-proof.js";
import { MOUSE_CLICK_PRE_ACTION_DECISIONS, MOUSE_CLICK_STATUSES } from "./shared/mouse-click-result.js";
import {
  MOUSE_CLICK_ABILITY_GROUP_ID,
  MOUSE_CLICK_BUTTONS,
  MOUSE_CLICK_CHILD_CAPABILITY_IDS,
  MOUSE_CLICK_COORDINATE_SPACES,
  MOUSE_CLICK_COUNTS,
} from "./shared/mouse-click-types.js";

const finiteNumber = z.number().finite();
const positiveFiniteNumber = z.number().finite().positive();
const positiveInt = z.number().int().positive();
const nonNegativeInt = z.number().int().nonnegative();
const nullableString = z.string().min(1).nullable().optional().default(null);
const nullableSessionId = z.string().min(1).nullable().optional().default(null);

export const MouseClickChildCapabilityIdSchema = z.enum(MOUSE_CLICK_CHILD_CAPABILITY_IDS);
export const MouseClickCoordinateSpaceSchema = z.enum(MOUSE_CLICK_COORDINATE_SPACES);
export const MouseClickButtonSchema = z.enum(MOUSE_CLICK_BUTTONS);
export const MouseClickCountSchema = z.union([z.literal(MOUSE_CLICK_COUNTS[0]), z.literal(MOUSE_CLICK_COUNTS[1])]);
export const MouseClickFailureReasonSchema = z.enum(MOUSE_CLICK_FAILURE_REASONS);
export const MouseClickStatusSchema = z.enum(MOUSE_CLICK_STATUSES);
export const MouseClickGeometryDecisionSchema = z.enum(MOUSE_CLICK_GEOMETRY_DECISIONS);
export const MouseClickPolicyDecisionSchema = z.enum(MOUSE_CLICK_POLICY_DECISIONS);
export const MouseClickSafetyDecisionSchema = z.enum(MOUSE_CLICK_SAFETY_DECISIONS);
export const MouseClickPrimitiveDecisionSchema = z.enum(MOUSE_CLICK_PRIMITIVE_DECISIONS);
export const MouseClickIdempotencyDecisionSchema = z.enum(MOUSE_CLICK_IDEMPOTENCY_DECISIONS);
export const MouseClickTimeoutDecisionSchema = z.enum(MOUSE_CLICK_TIMEOUT_DECISIONS);
export const MouseClickAbortDecisionSchema = z.enum(MOUSE_CLICK_ABORT_DECISIONS);
export const MouseClickCircuitBreakerStateSchema = z.enum(MOUSE_CLICK_CIRCUIT_BREAKER_STATES);
export const MouseClickPreActionDecisionSchema = z.enum(MOUSE_CLICK_PRE_ACTION_DECISIONS);

export const MouseClickPointSchema = z.object({
  x: finiteNumber,
  y: finiteNumber,
}).strict();

export const MouseClickBoundsSchema = z.object({
  width: positiveFiniteNumber,
  height: positiveFiniteNumber,
}).strict();

export const MouseClickSafetyPolicySchema = z.object({
  allowOperatorManual: z.boolean().default(DEFAULT_MOUSE_CLICK_SAFETY_POLICY.allowOperatorManual),
  operatorManualApprovalRef: nullableString,
  allowRightClick: z.boolean().default(DEFAULT_MOUSE_CLICK_SAFETY_POLICY.allowRightClick),
  allowDoubleClick: z.boolean().default(DEFAULT_MOUSE_CLICK_SAFETY_POLICY.allowDoubleClick),
  allowReplay: z.boolean().default(DEFAULT_MOUSE_CLICK_SAFETY_POLICY.allowReplay),
  allowDesktopScreenClick: z.boolean().default(DEFAULT_MOUSE_CLICK_SAFETY_POLICY.allowDesktopScreenClick),
  desktopScreenOperatorApprovalRef: nullableString,
  currentPhaseAllowsDesktopClick: z.boolean().default(DEFAULT_MOUSE_CLICK_SAFETY_POLICY.currentPhaseAllowsDesktopClick),
  platformProfileAllowsDesktopClick: z.boolean().default(DEFAULT_MOUSE_CLICK_SAFETY_POLICY.platformProfileAllowsDesktopClick),
  desktopOperatorApprovalValidUntil: nullableString,
  maxDurationMs: positiveInt.default(DEFAULT_MOUSE_CLICK_SAFETY_POLICY.maxDurationMs),
  primitiveTimeoutMs: positiveInt.default(DEFAULT_MOUSE_CLICK_SAFETY_POLICY.primitiveTimeoutMs),
  cooldownMs: nonNegativeInt.default(DEFAULT_MOUSE_CLICK_SAFETY_POLICY.cooldownMs),
  idempotencyTtlMs: positiveInt.default(DEFAULT_MOUSE_CLICK_SAFETY_POLICY.idempotencyTtlMs),
  maxIdempotencyReservations: positiveInt.default(DEFAULT_MOUSE_CLICK_SAFETY_POLICY.maxIdempotencyReservations),
  maxScopeEntries: positiveInt.default(DEFAULT_MOUSE_CLICK_SAFETY_POLICY.maxScopeEntries),
  requireStableRoundBinding: z.boolean().default(DEFAULT_MOUSE_CLICK_SAFETY_POLICY.requireStableRoundBinding),
  requireStableVideoVisitBinding: z.boolean().default(DEFAULT_MOUSE_CLICK_SAFETY_POLICY.requireStableVideoVisitBinding),
}).strict();

export const MouseClickGeometryGuardProofSchema = z.object({
  proofId: z.string().min(1),
  geometryGuardRef: z.string().min(1),
  abilityGroupId: z.literal("geometry-guard"),
  childCapabilityId: z.string().min(1),
  sourceAbilityGroupId: z.string().min(1),
  sourceChildCapabilityId: nullableString,
  sessionId: z.string().min(1),
  roundId: nullableString,
  videoVisitId: nullableString,
  status: z.literal("success"),
  guardDecision: z.literal("allow"),
  normalizedCoordinateSpace: MouseClickCoordinateSpaceSchema,
  normalizedClickPoint: MouseClickPointSchema,
  sourceBounds: MouseClickBoundsSchema.nullable().optional().default(null),
  sourceScreenshotEvidenceRef: nullableString,
  sourceTargetRef: nullableString,
  inputRef: nullableString,
  outputRef: nullableString,
}).strict();

const MouseClickBaseInputSchema = z.object({
  abilityGroupId: z.literal(MOUSE_CLICK_ABILITY_GROUP_ID).default(MOUSE_CLICK_ABILITY_GROUP_ID),
  sessionId: z.string().min(1),
  roundId: nullableString,
  videoVisitId: nullableString,
  requestedBy: z.string().min(1),
  purpose: z.string().min(1),
  sourceCoordinateProofRef: z.string().min(1),
  sourceEvidenceRef: nullableString,
  sourceTargetRef: z.string().min(1),
  geometryGuardProof: MouseClickGeometryGuardProofSchema,
  button: MouseClickButtonSchema.default("left"),
  clickCount: MouseClickCountSchema.default(1),
  bounds: MouseClickBoundsSchema,
  safetyPolicy: MouseClickSafetyPolicySchema.default(DEFAULT_MOUSE_CLICK_SAFETY_POLICY),
}).strict();

export const ClickBrowserCoordinateInputSchema = MouseClickBaseInputSchema.extend({
  childCapabilityId: z.literal("click-browser-coordinate"),
  geometryGuardProof: MouseClickGeometryGuardProofSchema.extend({
    normalizedCoordinateSpace: z.literal("browserViewport"),
  }),
}).strict();

export const ClickDesktopCoordinateInputSchema = MouseClickBaseInputSchema.extend({
  childCapabilityId: z.literal("click-desktop-coordinate"),
  geometryGuardProof: MouseClickGeometryGuardProofSchema.extend({
    normalizedCoordinateSpace: z.literal("desktopScreen"),
  }),
}).strict();

export const MouseClickAbilityInputSchema = z.discriminatedUnion("childCapabilityId", [
  ClickBrowserCoordinateInputSchema,
  ClickDesktopCoordinateInputSchema,
]);

export const MouseClickClockSchema = z.object({
  portKind: z.literal(MOUSE_CLICK_CLOCK_KIND),
  startedMonotonicMs: finiteNumber,
  endedMonotonicMs: finiteNumber,
}).strict();

export const MouseClickRuntimeProofSchema = z.object({
  proofId: z.string().min(1),
  runId: z.string().min(1),
  missionId: z.string().min(1),
  sessionId: nullableSessionId,
  roundId: nullableString,
  videoVisitId: nullableString,
  abilityGroupId: z.literal(MOUSE_CLICK_ABILITY_GROUP_ID),
  childCapabilityId: MouseClickChildCapabilityIdSchema,
  sourceAbilityGroupId: nullableString,
  sourceChildCapabilityId: nullableString,
  inputRef: z.string().min(1),
  outputRef: z.string().min(1),
  attemptRef: z.string().min(1),
  actionExecutionRef: nullableString,
  rejectionRef: nullableString,
  parseErrorRef: nullableString,
  receivedShapeHash: nullableString,
  geometryGuardRef: nullableString,
  geometryGuardProofRef: nullableString,
  sourceCoordinateProofRef: nullableString,
  sourceTargetRef: nullableString,
  sourceEvidenceRef: nullableString,
  coordinateSpace: MouseClickCoordinateSpaceSchema,
  sourceCoordinateSpace: MouseClickCoordinateSpaceSchema.nullable().default(null),
  requestedExecutionSpace: MouseClickCoordinateSpaceSchema,
  normalizedCoordinateSpace: MouseClickCoordinateSpaceSchema.nullable().default(null),
  requestedCoordinate: MouseClickPointSchema.nullable().default(null),
  executableCoordinate: MouseClickPointSchema.nullable().default(null),
  bounds: MouseClickBoundsSchema.nullable().default(null),
  sourceBounds: MouseClickBoundsSchema.nullable().default(null),
  targetBounds: MouseClickBoundsSchema.nullable().default(null),
  coordinateRoundingDecision: nullableString,
  scaleDecision: nullableString,
  transformDecision: nullableString,
  button: MouseClickButtonSchema,
  clickCount: MouseClickCountSchema,
  preActionDecision: MouseClickPreActionDecisionSchema,
  policyDecision: MouseClickPolicyDecisionSchema,
  policyDecisionReason: nullableString,
  geometryDecision: MouseClickGeometryDecisionSchema,
  safetyDecision: MouseClickSafetyDecisionSchema,
  safetyDecisionReason: nullableString,
  idempotencyKey: nullableString,
  idempotencyDecision: MouseClickIdempotencyDecisionSchema.nullable().default(null),
  primitiveDecision: MouseClickPrimitiveDecisionSchema,
  primitiveCallId: nullableString,
  primitiveExecutionRef: nullableString,
  primitiveTimeoutMs: nonNegativeInt,
  maxDurationMs: nonNegativeInt,
  timeoutDecision: MouseClickTimeoutDecisionSchema,
  abortDecision: MouseClickAbortDecisionSchema,
  circuitBreakerState: MouseClickCircuitBreakerStateSchema,
  clickSuppressedReason: nullableString,
  primitivePortKind: z.string().min(1),
  primitiveStartedAt: nullableString,
  primitiveEndedAt: nullableString,
  postActionVerificationRequired: z.boolean(),
  postActionVerificationHandoffRef: nullableString,
  verificationRefPolicy: z.literal(MOUSE_CLICK_VERIFICATION_REF_POLICY),
  startedAt: z.string().datetime(),
  endedAt: z.string().datetime(),
  durationMs: nonNegativeInt,
  status: MouseClickStatusSchema,
  failureReason: MouseClickFailureReasonSchema.nullable().default(null),
  reviewRequiredReason: nullableString,
  dataQualityFlags: z.array(z.string().min(1)).default([]),
  clock: MouseClickClockSchema,
}).strict().superRefine((value, context) => {
  if (value.startedAt > value.endedAt) {
    context.addIssue({ code: z.ZodIssueCode.custom, message: "startedAt must not be after endedAt", path: ["startedAt"] });
  }
  if (value.status === "success") {
    if (value.actionExecutionRef === null) {
      context.addIssue({ code: z.ZodIssueCode.custom, message: "success proof requires actionExecutionRef", path: ["actionExecutionRef"] });
    }
    if (value.primitiveExecutionRef === null) {
      context.addIssue({ code: z.ZodIssueCode.custom, message: "success proof requires primitiveExecutionRef", path: ["primitiveExecutionRef"] });
    }
    if (value.executableCoordinate === null) {
      context.addIssue({ code: z.ZodIssueCode.custom, message: "success proof requires executableCoordinate", path: ["executableCoordinate"] });
    }
    if (!value.postActionVerificationRequired || value.postActionVerificationHandoffRef === null) {
      context.addIssue({ code: z.ZodIssueCode.custom, message: "success proof requires post-action verification handoff", path: ["postActionVerificationHandoffRef"] });
    }
  }
  if (value.status !== "success" && value.executableCoordinate !== null) {
    context.addIssue({ code: z.ZodIssueCode.custom, message: "non-success proof must not expose executableCoordinate", path: ["executableCoordinate"] });
  }
});

export const MouseClickSuccessOutputSchema = z.object({
  attemptRef: z.string().min(1),
  actionExecutionRef: z.string().min(1),
  primitiveExecutionRef: z.string().min(1),
  normalizedClickPoint: MouseClickPointSchema,
  coordinateSpace: MouseClickCoordinateSpaceSchema,
  button: MouseClickButtonSchema,
  clickCount: MouseClickCountSchema,
  postActionVerificationRequired: z.literal(true),
  postActionVerificationHandoffRef: z.string().min(1),
}).strict();

const MouseClickBaseResultSchema = z.object({
  abilityGroupId: z.literal(MOUSE_CLICK_ABILITY_GROUP_ID),
  childCapabilityId: MouseClickChildCapabilityIdSchema,
  status: MouseClickStatusSchema,
  sessionId: nullableSessionId,
  roundId: nullableString,
  videoVisitId: nullableString,
  attemptRef: z.string().min(1),
  output: MouseClickSuccessOutputSchema.nullable().default(null),
  failureReason: MouseClickFailureReasonSchema.nullable().default(null),
  reviewRequiredReason: nullableString,
  statusMessage: z.string().min(1),
  policyDecision: MouseClickPolicyDecisionSchema,
  dataQualityFlags: z.array(z.string().min(1)).default([]),
  runtimeProof: MouseClickRuntimeProofSchema,
}).strict();

export const ClickBrowserCoordinateResultSchema = MouseClickBaseResultSchema.extend({
  childCapabilityId: z.literal("click-browser-coordinate"),
}).strict();

export const ClickDesktopCoordinateResultSchema = MouseClickBaseResultSchema.extend({
  childCapabilityId: z.literal("click-desktop-coordinate"),
}).strict();

export const MouseClickAbilityResultSchema = z.discriminatedUnion("childCapabilityId", [
  ClickBrowserCoordinateResultSchema,
  ClickDesktopCoordinateResultSchema,
]).superRefine((value, context) => {
  if (value.status === "success" && value.output === null) {
    context.addIssue({ code: z.ZodIssueCode.custom, message: "success requires output", path: ["output"] });
  }
  if (value.status !== "success" && value.output !== null) {
    context.addIssue({ code: z.ZodIssueCode.custom, message: "failed and review_required require output=null", path: ["output"] });
  }
  if (value.runtimeProof.status !== value.status) {
    context.addIssue({ code: z.ZodIssueCode.custom, message: "runtimeProof.status must equal result.status", path: ["runtimeProof", "status"] });
  }
  if (value.runtimeProof.attemptRef !== value.attemptRef) {
    context.addIssue({ code: z.ZodIssueCode.custom, message: "runtimeProof.attemptRef must equal result.attemptRef", path: ["runtimeProof", "attemptRef"] });
  }
});