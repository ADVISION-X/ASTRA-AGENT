export type ClipboardReadResult = {
  ok: boolean;
  text: string | null;
  message: string;
  portKind: string;
};

export type ClipboardWriteResult = {
  ok: boolean;
  message: string;
  portKind: string;
};

export interface ClipboardPort {
  readText(): Promise<ClipboardReadResult>;
  writeText(text: string): Promise<ClipboardWriteResult>;
}