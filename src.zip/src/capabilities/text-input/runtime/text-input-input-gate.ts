import type { ParsedTextInputAbilityInput, TextInputChildCapabilityId, TextInputKey, TextInputPolicy, TextInputTargetKind } from "../contract.js";
import { TextInputAbilityInputSchema, TextInputPolicySchema } from "../schema.js";
import { buildStableTextInputRef } from "../shared/text-input-types.js";

type UnknownObject = { [key: string]: unknown };

export type TextInputExecutionSeed = {
  attemptRef: string;
  inputRef: string;
  childCapabilityId: TextInputChildCapabilityId;
  sessionId: string;
  roundId: string | null;
  videoVisitId: string | null;
  requestedBy: string;
  purpose: string;
  sourceAbilityGroupId: string | null;
  sourceChildCapabilityId: string | null;
  approvedText: string | null;
  approvedTextRef: string | null;
  targetRef: string;
  targetProofRef: string;
  targetKind: TextInputTargetKind;
  targetEvidenceRefs: string[];
  operatorApprovalRef: string | null;
  key: TextInputKey | null;
  policy: TextInputPolicy;
  parseErrorRef: string | null;
  receivedShapeHash: string | null;
};

export type TextInputFailureEnvelope = {
  attemptRef: string;
  inputRef: string;
  childCapabilityId: TextInputChildCapabilityId;
  sessionId: string | null;
  roundId: string | null;
  videoVisitId: string | null;
  requestedBy: string | null;
  purpose: string | null;
  sourceAbilityGroupId: string | null;
  sourceChildCapabilityId: string | null;
  approvedText: string | null;
  approvedTextRef: string | null;
  targetRef: string | null;
  targetProofRef: string | null;
  targetKind: TextInputTargetKind;
  targetEvidenceRefs: string[];
  operatorApprovalRef: string | null;
  key: TextInputKey | null;
  policy: TextInputPolicy;
  parseErrorRef: string | null;
  receivedShapeHash: string | null;
};

export type TextInputResultSeed = TextInputExecutionSeed | TextInputFailureEnvelope;

function isObject(value: unknown): value is UnknownObject {
  return typeof value === "object" && value !== null;
}

function readNonEmptyString(value: unknown): string | null {
  return typeof value === "string" && value.trim().length > 0 ? value : null;
}

function resolveChildCapabilityId(value: unknown): TextInputChildCapabilityId {
  return typeof value === "string" && [
    "type-text",
    "paste-text",
    "clear-input",
    "replace-input",
    "press-key",
    "commit-input",
  ].includes(value)
    ? value as TextInputChildCapabilityId
    : "type-text";
}

function resolveTargetKind(value: unknown): TextInputTargetKind {
  if (value === "searchField" || value === "commentComposer" || value === "editableArea") {
    return value;
  }
  return "textField";
}

function resolveKey(value: unknown): TextInputKey | null {
  if (
    value === "Enter" ||
    value === "Tab" ||
    value === "Escape" ||
    value === "Backspace" ||
    value === "Delete" ||
    value === "ArrowUp" ||
    value === "ArrowDown" ||
    value === "ArrowLeft" ||
    value === "ArrowRight"
  ) {
    return value;
  }
  return null;
}

function formatParseIssues(input: unknown): string {
  const parsed = TextInputAbilityInputSchema.safeParse(input);
  if (parsed.success) {
    return "Text Input rejected invalid input schema.";
  }

  return parsed.error.issues
    .map((issue) => `${issue.path.join(".") || "root"}:${issue.message}`)
    .join(" | ");
}

export function parseTextInputAbilityInput(input: unknown):
  | { success: true; data: ParsedTextInputAbilityInput }
  | { success: false; statusMessage: string } {
  const parsed = TextInputAbilityInputSchema.safeParse(input);
  if (parsed.success) {
    return parsed;
  }

  return {
    success: false,
    statusMessage: `Text Input rejected invalid input schema. ${formatParseIssues(input)}`,
  };
}

export function buildTextInputExecutionSeed(input: ParsedTextInputAbilityInput): TextInputExecutionSeed {
  const inputRef = buildStableTextInputRef("text-input-input", [
    input.sessionId,
    input.childCapabilityId,
    input.targetRef,
    input.approvedTextRef,
    input.key,
    input.purpose,
  ]);

  return {
    attemptRef: buildStableTextInputRef("text-input-attempt", [inputRef, input.requestedBy]),
    inputRef,
    childCapabilityId: input.childCapabilityId,
    sessionId: input.sessionId,
    roundId: input.roundId,
    videoVisitId: input.videoVisitId,
    requestedBy: input.requestedBy,
    purpose: input.purpose,
    sourceAbilityGroupId: input.sourceAbilityGroupId,
    sourceChildCapabilityId: input.sourceChildCapabilityId,
    approvedText: input.approvedText,
    approvedTextRef: input.approvedTextRef,
    targetRef: input.targetRef,
    targetProofRef: input.targetProofRef,
    targetKind: input.targetKind,
    targetEvidenceRefs: input.targetEvidenceRefs,
    operatorApprovalRef: input.operatorApprovalRef,
    key: input.key,
    policy: input.policy,
    parseErrorRef: null,
    receivedShapeHash: null,
  };
}

function buildInvalidInputFailureEnvelope(input: unknown, fallbackChildCapabilityId?: TextInputChildCapabilityId): TextInputFailureEnvelope {
  const raw = isObject(input) ? input : null;
  const childCapabilityId = fallbackChildCapabilityId ?? resolveChildCapabilityId(raw?.childCapabilityId);
  const parseErrorText = formatParseIssues(input);
  const receivedShapeHash = buildStableTextInputRef("text-input-input-shape", raw ?? input);

  return {
    attemptRef: buildStableTextInputRef("text-input-attempt", [receivedShapeHash, childCapabilityId]),
    inputRef: buildStableTextInputRef("text-input-input", [receivedShapeHash, childCapabilityId]),
    childCapabilityId,
    sessionId: readNonEmptyString(raw?.sessionId),
    roundId: readNonEmptyString(raw?.roundId),
    videoVisitId: readNonEmptyString(raw?.videoVisitId),
    requestedBy: readNonEmptyString(raw?.requestedBy),
    purpose: readNonEmptyString(raw?.purpose),
    sourceAbilityGroupId: readNonEmptyString(raw?.sourceAbilityGroupId),
    sourceChildCapabilityId: readNonEmptyString(raw?.sourceChildCapabilityId),
    approvedText: typeof raw?.approvedText === "string" ? raw.approvedText : null,
    approvedTextRef: readNonEmptyString(raw?.approvedTextRef),
    targetRef: readNonEmptyString(raw?.targetRef),
    targetProofRef: readNonEmptyString(raw?.targetProofRef),
    targetKind: resolveTargetKind(raw?.targetKind),
    targetEvidenceRefs: Array.isArray(raw?.targetEvidenceRefs)
      ? raw.targetEvidenceRefs.filter((value): value is string => typeof value === "string" && value.length > 0)
      : [],
    operatorApprovalRef: readNonEmptyString(raw?.operatorApprovalRef),
    key: resolveKey(raw?.key),
    policy: TextInputPolicySchema.parse(raw?.policy),
    parseErrorRef: buildStableTextInputRef("text-input-parse-error", parseErrorText),
    receivedShapeHash,
  };
}

export function resolveTextInputFailureSeed(input: unknown, fallbackChildCapabilityId?: TextInputChildCapabilityId): TextInputResultSeed {
  const parsed = TextInputAbilityInputSchema.safeParse(input);
  if (parsed.success) {
    return buildTextInputExecutionSeed(parsed.data);
  }

  return buildInvalidInputFailureEnvelope(input, fallbackChildCapabilityId);
}