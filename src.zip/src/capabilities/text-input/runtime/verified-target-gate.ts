import type { ParsedTextInputAbilityInput } from "../contract.js";

export function validateVerifiedTarget(input: { request: ParsedTextInputAbilityInput }) {
  if (input.request.targetRef.length === 0) {
    return {
      ok: false as const,
      status: "failed" as const,
      failureReason: "target_ref_required" as const,
      reviewRequiredReason: null,
      policyDecision: "block" as const,
      statusMessage: "Text Input requires a verified targetRef.",
      dataQualityFlags: ["target_ref_required"],
    };
  }

  if (input.request.targetProofRef.length === 0) {
    return {
      ok: false as const,
      status: "failed" as const,
      failureReason: "target_proof_ref_required" as const,
      reviewRequiredReason: null,
      policyDecision: "block" as const,
      statusMessage: "Text Input requires a verified targetProofRef.",
      dataQualityFlags: ["target_proof_ref_required"],
    };
  }

  return {
    ok: true as const,
    policyDecision: "allow" as const,
    statusMessage: "Text Input verified-target gate passed.",
    dataQualityFlags: [] as string[],
  };
}