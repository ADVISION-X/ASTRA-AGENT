import type { TextInputChildCapabilityId, TextInputKey, TextInputTargetKind } from "../contract.js";
import type { TextInputRuntimeContext } from "./text-input-runtime-context.js";

export async function runPrimitiveTextInput(input: {
  context: TextInputRuntimeContext;
  attemptRef: string;
  actionExecutionRef: string;
  childCapabilityId: TextInputChildCapabilityId;
  targetRef: string;
  targetKind: TextInputTargetKind;
  approvedText: string | null;
  key: TextInputKey | null;
  timeoutMs: number;
}) {
  const startedSnapshot = input.context.clock.now();
  const primitiveResult = await input.context.executionPort.execute({
    attemptRef: input.attemptRef,
    actionExecutionRef: input.actionExecutionRef,
    childCapabilityId: input.childCapabilityId,
    targetRef: input.targetRef,
    targetKind: input.targetKind,
    targetLabel: `${input.targetKind}:${input.targetRef}`,
    approvedText: input.approvedText,
    key: input.key,
    timeoutMs: input.timeoutMs,
  });
  const endedSnapshot = input.context.clock.now();

  return {
    ok: primitiveResult.ok,
    primitiveExecutionRef: primitiveResult.primitiveExecutionRef,
    statusMessage: primitiveResult.message,
    failureReason: primitiveResult.failureReason,
    primitiveDecision: primitiveResult.ok
      ? ("succeeded" as const)
      : primitiveResult.failureReason === "primitive_aborted"
        ? ("aborted" as const)
        : primitiveResult.failureReason === "primitive_timeout"
          ? ("timed_out" as const)
          : ("failed" as const),
    primitivePortKind: primitiveResult.portKind,
    primitiveStartedAt: primitiveResult.startedAt,
    primitiveEndedAt: primitiveResult.endedAt,
    startedAt: primitiveResult.startedAt ?? startedSnapshot.isoTimestamp,
    endedAt: primitiveResult.endedAt ?? endedSnapshot.isoTimestamp,
    durationMs: Math.max(0, Math.round(endedSnapshot.monotonicMs - startedSnapshot.monotonicMs)),
    clock: {
      startedMonotonicMs: startedSnapshot.monotonicMs,
      endedMonotonicMs: endedSnapshot.monotonicMs,
    },
    dataQualityFlags: primitiveResult.ok ? [] : [primitiveResult.failureReason ?? "primitive_failed"],
  };
}