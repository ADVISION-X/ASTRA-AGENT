import { TextInputAbilityResultSchema } from "../schema.js";
import { buildStableTextInputRef } from "../shared/text-input-types.js";
import type { TextInputResultSeed } from "./text-input-input-gate.js";
import { buildTextInputRuntimeProof } from "./text-input-proof-builder.js";

export function buildTextInputResult(input: {
  seed: TextInputResultSeed;
  actionExecutionRef: string | null;
  primitiveExecutionRef: string | null;
  status: "success" | "failed" | "review_required";
  failureReason: string | null;
  reviewRequiredReason: string | null;
  statusMessage: string;
  policyDecision: "allow" | "block" | "review_required";
  clipboardDecision: "not_used" | "prepared" | "restored" | "failed";
  primitiveDecision: "not_run" | "succeeded" | "failed" | "aborted" | "timed_out";
  primitivePortKind: string;
  primitiveStartedAt: string | null;
  primitiveEndedAt: string | null;
  startedAt: string;
  endedAt: string;
  durationMs: number;
  clock: { startedMonotonicMs: number; endedMonotonicMs: number };
  dataQualityFlags: string[];
}) {
  const outputRef = buildStableTextInputRef("text-input-output", [input.seed.attemptRef, input.status]);
  const postActionVerificationRequired = input.status === "success";
  const postActionVerificationHandoffRef = postActionVerificationRequired && input.actionExecutionRef && input.primitiveExecutionRef
    ? buildStableTextInputRef("text-input-post-action-verification", [input.actionExecutionRef, input.primitiveExecutionRef])
    : null;
  const output = input.status === "success" && input.actionExecutionRef && input.primitiveExecutionRef
    ? {
        attemptRef: input.seed.attemptRef,
        actionExecutionRef: input.actionExecutionRef,
        primitiveExecutionRef: input.primitiveExecutionRef,
        targetRef: input.seed.targetRef ?? input.seed.inputRef,
        targetKind: input.seed.targetKind,
        actionKind: input.seed.childCapabilityId,
        approvedTextRef: input.seed.approvedTextRef,
        textLength: input.seed.approvedText?.length ?? 0,
        key: input.seed.key,
        postActionVerificationRequired: true as const,
        postActionVerificationHandoffRef,
      }
    : null;

  const runtimeProof = buildTextInputRuntimeProof({
    attemptRef: input.seed.attemptRef,
    childCapabilityId: input.seed.childCapabilityId,
    sessionId: input.seed.sessionId,
    roundId: input.seed.roundId,
    videoVisitId: input.seed.videoVisitId,
    sourceAbilityGroupId: input.seed.sourceAbilityGroupId,
    sourceChildCapabilityId: input.seed.sourceChildCapabilityId,
    inputRef: input.seed.inputRef,
    outputRef,
    actionExecutionRef: input.actionExecutionRef,
    primitiveExecutionRef: input.primitiveExecutionRef,
    approvedTextRef: input.seed.approvedTextRef,
    targetRef: input.seed.targetRef,
    targetProofRef: input.seed.targetProofRef,
    targetKind: input.seed.targetKind,
    targetEvidenceRefs: input.seed.targetEvidenceRefs,
    key: input.seed.key,
    textLength: input.seed.approvedText?.length ?? 0,
    policyDecision: input.policyDecision,
    clipboardDecision: input.clipboardDecision,
    primitiveDecision: input.primitiveDecision,
    primitivePortKind: input.primitivePortKind,
    primitiveStartedAt: input.primitiveStartedAt,
    primitiveEndedAt: input.primitiveEndedAt,
    maxDurationMs: input.seed.policy.maxDurationMs,
    primitiveTimeoutMs: input.seed.policy.primitiveTimeoutMs,
    postActionVerificationRequired,
    postActionVerificationHandoffRef,
    startedAt: input.startedAt,
    endedAt: input.endedAt,
    durationMs: input.durationMs,
    status: input.status,
    failureReason: input.failureReason,
    reviewRequiredReason: input.reviewRequiredReason,
    dataQualityFlags: input.dataQualityFlags,
    clock: input.clock,
  });

  return TextInputAbilityResultSchema.parse({
    abilityGroupId: "text-input",
    childCapabilityId: input.seed.childCapabilityId,
    status: input.status,
    sessionId: input.seed.sessionId,
    roundId: input.seed.roundId,
    videoVisitId: input.seed.videoVisitId,
    attemptRef: input.seed.attemptRef,
    output,
    failureReason: input.failureReason,
    reviewRequiredReason: input.reviewRequiredReason,
    statusMessage: input.statusMessage,
    policyDecision: input.policyDecision,
    dataQualityFlags: input.dataQualityFlags,
    runtimeProof,
  });
}