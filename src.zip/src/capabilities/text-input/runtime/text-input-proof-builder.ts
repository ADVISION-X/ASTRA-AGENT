import { TextInputRuntimeProofSchema } from "../schema.js";
import { buildStableTextInputRef } from "../shared/text-input-types.js";

export function buildTextInputRuntimeProof(input: {
  attemptRef: string;
  childCapabilityId: "type-text" | "paste-text" | "clear-input" | "replace-input" | "press-key" | "commit-input";
  sessionId: string | null;
  roundId: string | null;
  videoVisitId: string | null;
  sourceAbilityGroupId: string | null;
  sourceChildCapabilityId: string | null;
  inputRef: string;
  outputRef: string;
  actionExecutionRef: string | null;
  primitiveExecutionRef: string | null;
  approvedTextRef: string | null;
  targetRef: string | null;
  targetProofRef: string | null;
  targetKind: "textField" | "searchField" | "commentComposer" | "editableArea";
  targetEvidenceRefs: string[];
  key: "Enter" | "Tab" | "Escape" | "Backspace" | "Delete" | "ArrowUp" | "ArrowDown" | "ArrowLeft" | "ArrowRight" | null;
  textLength: number;
  policyDecision: "allow" | "block" | "review_required";
  clipboardDecision: "not_used" | "prepared" | "restored" | "failed";
  primitiveDecision: "not_run" | "succeeded" | "failed" | "aborted" | "timed_out";
  primitivePortKind: string;
  primitiveStartedAt: string | null;
  primitiveEndedAt: string | null;
  maxDurationMs: number;
  primitiveTimeoutMs: number;
  postActionVerificationRequired: boolean;
  postActionVerificationHandoffRef: string | null;
  startedAt: string;
  endedAt: string;
  durationMs: number;
  status: "success" | "failed" | "review_required";
  failureReason: string | null;
  reviewRequiredReason: string | null;
  dataQualityFlags: string[];
  clock: { startedMonotonicMs: number; endedMonotonicMs: number };
}) {
  return TextInputRuntimeProofSchema.parse({
    proofId: buildStableTextInputRef("text-input-proof", [input.attemptRef, input.status]),
    runId: buildStableTextInputRef("text-input-run", [input.attemptRef]),
    sessionId: input.sessionId,
    roundId: input.roundId,
    videoVisitId: input.videoVisitId,
    abilityGroupId: "text-input",
    childCapabilityId: input.childCapabilityId,
    sourceAbilityGroupId: input.sourceAbilityGroupId,
    sourceChildCapabilityId: input.sourceChildCapabilityId,
    inputRef: input.inputRef,
    outputRef: input.outputRef,
    attemptRef: input.attemptRef,
    actionExecutionRef: input.actionExecutionRef,
    primitiveExecutionRef: input.primitiveExecutionRef,
    approvedTextRef: input.approvedTextRef,
    targetRef: input.targetRef,
    targetProofRef: input.targetProofRef,
    targetKind: input.targetKind,
    targetEvidenceRefs: input.targetEvidenceRefs,
    actionKind: input.childCapabilityId,
    key: input.key,
    textLength: input.textLength,
    policyDecision: input.policyDecision,
    clipboardDecision: input.clipboardDecision,
    primitiveDecision: input.primitiveDecision,
    primitivePortKind: input.primitivePortKind,
    primitiveStartedAt: input.primitiveStartedAt,
    primitiveEndedAt: input.primitiveEndedAt,
    maxDurationMs: input.maxDurationMs,
    primitiveTimeoutMs: input.primitiveTimeoutMs,
    postActionVerificationRequired: input.postActionVerificationRequired,
    postActionVerificationHandoffRef: input.postActionVerificationHandoffRef,
    verificationRefPolicy: "target_proof_ref+approved_text_ref+action_execution_ref",
    startedAt: input.startedAt,
    endedAt: input.endedAt,
    durationMs: input.durationMs,
    status: input.status,
    failureReason: input.failureReason,
    reviewRequiredReason: input.reviewRequiredReason,
    dataQualityFlags: input.dataQualityFlags,
    clock: {
      portKind: "system-monotonic-clock",
      startedMonotonicMs: input.clock.startedMonotonicMs,
      endedMonotonicMs: input.clock.endedMonotonicMs,
    },
  });
}