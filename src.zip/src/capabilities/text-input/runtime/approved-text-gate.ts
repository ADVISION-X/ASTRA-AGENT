import type { ParsedTextInputAbilityInput } from "../contract.js";

const WRITING_CHILDREN = new Set(["type-text", "paste-text", "replace-input"]);

export function validateApprovedText(input: { request: ParsedTextInputAbilityInput }) {
  if (!WRITING_CHILDREN.has(input.request.childCapabilityId)) {
    return {
      ok: true as const,
      policyDecision: "allow" as const,
      statusMessage: "Text Input approved-text gate passed.",
      textLength: 0,
      dataQualityFlags: [] as string[],
    };
  }

  if (input.request.approvedText === null || input.request.approvedText.length === 0) {
    return {
      ok: false as const,
      status: "failed" as const,
      failureReason: "missing_approved_text" as const,
      reviewRequiredReason: null,
      policyDecision: "block" as const,
      statusMessage: "Text Input requires approvedText for the selected child capability.",
      dataQualityFlags: ["missing_approved_text"],
    };
  }

  if (input.request.approvedTextRef === null) {
    return {
      ok: false as const,
      status: "failed" as const,
      failureReason: "approved_text_ref_required" as const,
      reviewRequiredReason: null,
      policyDecision: "block" as const,
      statusMessage: "Text Input requires approvedTextRef for the selected child capability.",
      dataQualityFlags: ["approved_text_ref_required"],
    };
  }

  return {
    ok: true as const,
    policyDecision: "allow" as const,
    statusMessage: "Text Input approved-text gate passed.",
    textLength: input.request.approvedText.length,
    dataQualityFlags: [] as string[],
  };
}