import { buildStableTextInputRef } from "../shared/text-input-types.js";
import type { ParsedTextInputAbilityInput } from "../contract.js";
import { validateApprovedText } from "./approved-text-gate.js";
import { validateVerifiedTarget } from "./verified-target-gate.js";
import { validateTextInputPolicy } from "./text-input-policy-gate.js";
import { buildTextInputExecutionSeed } from "./text-input-input-gate.js";
import { buildTextInputResult } from "./text-input-result-builder.js";
import { runPrimitiveTextInput } from "./primitive-text-input-runner.js";
import type { TextInputRuntimeContext } from "./text-input-runtime-context.js";

function buildRejectedTextInputResult(input: {
  seed: ReturnType<typeof buildTextInputExecutionSeed>;
  context: TextInputRuntimeContext;
  status: "failed" | "review_required";
  failureReason: string | null;
  reviewRequiredReason: string | null;
  statusMessage: string;
  policyDecision: "allow" | "block" | "review_required";
  clipboardDecision: "not_used" | "prepared" | "restored" | "failed";
  dataQualityFlags: string[];
}) {
  const startedSnapshot = input.context.clock.now();
  const endedSnapshot = input.context.clock.now();

  return buildTextInputResult({
    seed: input.seed,
    actionExecutionRef: null,
    primitiveExecutionRef: null,
    status: input.status,
    failureReason: input.failureReason,
    reviewRequiredReason: input.reviewRequiredReason,
    statusMessage: input.statusMessage,
    policyDecision: input.policyDecision,
    clipboardDecision: input.clipboardDecision,
    primitiveDecision: "not_run",
    primitivePortKind: "not-run",
    primitiveStartedAt: null,
    primitiveEndedAt: null,
    startedAt: startedSnapshot.isoTimestamp,
    endedAt: endedSnapshot.isoTimestamp,
    durationMs: Math.max(0, Math.round(endedSnapshot.monotonicMs - startedSnapshot.monotonicMs)),
    clock: { startedMonotonicMs: startedSnapshot.monotonicMs, endedMonotonicMs: endedSnapshot.monotonicMs },
    dataQualityFlags: input.dataQualityFlags,
  });
}

export async function executeTextInput(input: {
  request: ParsedTextInputAbilityInput;
  context: TextInputRuntimeContext;
}) {
  const seed = buildTextInputExecutionSeed(input.request);

  const targetGate = validateVerifiedTarget({ request: input.request });
  if (!targetGate.ok) {
    return buildRejectedTextInputResult({
      seed,
      context: input.context,
      status: targetGate.status,
      failureReason: targetGate.failureReason,
      reviewRequiredReason: targetGate.reviewRequiredReason,
      statusMessage: targetGate.statusMessage,
      policyDecision: targetGate.policyDecision,
      clipboardDecision: "not_used",
      dataQualityFlags: targetGate.dataQualityFlags,
    });
  }

  const approvedTextGate = validateApprovedText({ request: input.request });
  if (!approvedTextGate.ok) {
    return buildRejectedTextInputResult({
      seed,
      context: input.context,
      status: approvedTextGate.status,
      failureReason: approvedTextGate.failureReason,
      reviewRequiredReason: approvedTextGate.reviewRequiredReason,
      statusMessage: approvedTextGate.statusMessage,
      policyDecision: approvedTextGate.policyDecision,
      clipboardDecision: "not_used",
      dataQualityFlags: approvedTextGate.dataQualityFlags,
    });
  }

  const policyGate = validateTextInputPolicy({ request: input.request });
  if (!policyGate.ok) {
    return buildRejectedTextInputResult({
      seed,
      context: input.context,
      status: policyGate.status,
      failureReason: policyGate.failureReason,
      reviewRequiredReason: policyGate.reviewRequiredReason,
      statusMessage: policyGate.statusMessage,
      policyDecision: policyGate.policyDecision,
      clipboardDecision: "not_used",
      dataQualityFlags: policyGate.dataQualityFlags,
    });
  }

  const actionExecutionRef = buildStableTextInputRef("text-input-action", [seed.attemptRef, seed.childCapabilityId]);
  let clipboardDecision: "not_used" | "prepared" | "restored" | "failed" = "not_used";
  let clipboardBackup: string | null = null;

  if (seed.childCapabilityId === "paste-text" && seed.approvedText !== null) {
    const backup = await input.context.clipboardPort.readText();
    if (!backup.ok) {
      return buildRejectedTextInputResult({
        seed,
        context: input.context,
        status: "failed",
        failureReason: "clipboard_unavailable",
        reviewRequiredReason: null,
        statusMessage: backup.message,
        policyDecision: "block",
        clipboardDecision: "failed",
        dataQualityFlags: ["clipboard_unavailable"],
      });
    }

    clipboardBackup = backup.text;
    const writeResult = await input.context.clipboardPort.writeText(seed.approvedText);
    if (!writeResult.ok) {
      return buildRejectedTextInputResult({
        seed,
        context: input.context,
        status: "failed",
        failureReason: "clipboard_unavailable",
        reviewRequiredReason: null,
        statusMessage: writeResult.message,
        policyDecision: "block",
        clipboardDecision: "failed",
        dataQualityFlags: ["clipboard_unavailable"],
      });
    }

    clipboardDecision = "prepared";
  }

  const primitiveResult = await runPrimitiveTextInput({
    context: input.context,
    attemptRef: seed.attemptRef,
    actionExecutionRef,
    childCapabilityId: seed.childCapabilityId,
    targetRef: seed.targetRef,
    targetKind: seed.targetKind,
    approvedText: seed.approvedText,
    key: seed.key,
    timeoutMs: seed.policy.primitiveTimeoutMs,
  });

  if (seed.childCapabilityId === "paste-text" && seed.policy.restoreClipboard) {
    const restoreResult = await input.context.clipboardPort.writeText(clipboardBackup ?? "");
    clipboardDecision = restoreResult.ok ? "restored" : "failed";
  }

  if (!primitiveResult.ok) {
    return buildTextInputResult({
      seed,
      actionExecutionRef,
      primitiveExecutionRef: primitiveResult.primitiveExecutionRef,
      status: "failed",
      failureReason: primitiveResult.failureReason ?? "primitive_failed",
      reviewRequiredReason: null,
      statusMessage: primitiveResult.statusMessage,
      policyDecision: "allow",
      clipboardDecision,
      primitiveDecision: primitiveResult.primitiveDecision,
      primitivePortKind: primitiveResult.primitivePortKind,
      primitiveStartedAt: primitiveResult.primitiveStartedAt,
      primitiveEndedAt: primitiveResult.primitiveEndedAt,
      startedAt: primitiveResult.startedAt,
      endedAt: primitiveResult.endedAt,
      durationMs: primitiveResult.durationMs,
      clock: primitiveResult.clock,
      dataQualityFlags: primitiveResult.dataQualityFlags,
    });
  }

  const successFlags = clipboardDecision === "failed" ? ["clipboard_restore_failed"] : [];
  return buildTextInputResult({
    seed,
    actionExecutionRef,
    primitiveExecutionRef: primitiveResult.primitiveExecutionRef,
    status: "success",
    failureReason: null,
    reviewRequiredReason: null,
    statusMessage: primitiveResult.statusMessage,
    policyDecision: "allow",
    clipboardDecision,
    primitiveDecision: primitiveResult.primitiveDecision,
    primitivePortKind: primitiveResult.primitivePortKind,
    primitiveStartedAt: primitiveResult.primitiveStartedAt,
    primitiveEndedAt: primitiveResult.primitiveEndedAt,
    startedAt: primitiveResult.startedAt,
    endedAt: primitiveResult.endedAt,
    durationMs: primitiveResult.durationMs,
    clock: primitiveResult.clock,
    dataQualityFlags: successFlags,
  });
}