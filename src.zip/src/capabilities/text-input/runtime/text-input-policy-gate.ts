import type { ParsedTextInputAbilityInput } from "../contract.js";

export function validateTextInputPolicy(input: { request: ParsedTextInputAbilityInput }) {
  const { request } = input;

  if (request.approvedText !== null && request.approvedText.length > request.policy.maxTextLength) {
    return {
      ok: false as const,
      status: "failed" as const,
      failureReason: "text_too_long" as const,
      reviewRequiredReason: null,
      policyDecision: "block" as const,
      statusMessage: "Text Input rejected text that exceeds policy.maxTextLength.",
      dataQualityFlags: ["text_too_long"],
    };
  }

  if (request.childCapabilityId === "paste-text" && !request.policy.allowPaste) {
    return {
      ok: false as const,
      status: "failed" as const,
      failureReason: "paste_disabled" as const,
      reviewRequiredReason: null,
      policyDecision: "block" as const,
      statusMessage: "Text Input paste-text is disabled by policy.",
      dataQualityFlags: ["paste_disabled"],
    };
  }

  if (request.childCapabilityId === "replace-input" && !request.policy.allowReplace) {
    return {
      ok: false as const,
      status: "failed" as const,
      failureReason: "replace_disabled" as const,
      reviewRequiredReason: null,
      policyDecision: "block" as const,
      statusMessage: "Text Input replace-input is disabled by policy.",
      dataQualityFlags: ["replace_disabled"],
    };
  }

  if (request.childCapabilityId === "commit-input" && !request.policy.allowCommit) {
    return {
      ok: false as const,
      status: "failed" as const,
      failureReason: "commit_disabled" as const,
      reviewRequiredReason: null,
      policyDecision: "block" as const,
      statusMessage: "Text Input commit-input is disabled by policy.",
      dataQualityFlags: ["commit_disabled"],
    };
  }

  return {
    ok: true as const,
    policyDecision: "allow" as const,
    statusMessage: "Text Input policy gate passed.",
    dataQualityFlags: [] as string[],
  };
}