import { z } from "zod";

import { TEXT_INPUT_FAILURE_REASONS } from "./shared/text-input-failure.js";
import { DEFAULT_TEXT_INPUT_POLICY } from "./shared/text-input-policy.js";
import {
  TEXT_INPUT_CLIPBOARD_DECISIONS,
  TEXT_INPUT_CLOCK_KIND,
  TEXT_INPUT_POLICY_DECISIONS,
  TEXT_INPUT_PRIMITIVE_DECISIONS,
  TEXT_INPUT_VERIFICATION_REF_POLICY,
} from "./shared/text-input-proof.js";
import { TEXT_INPUT_STATUSES } from "./shared/text-input-result.js";
import {
  TEXT_INPUT_ABILITY_GROUP_ID,
  TEXT_INPUT_CHILD_CAPABILITY_IDS,
  TEXT_INPUT_KEYS,
  TEXT_INPUT_TARGET_KINDS,
} from "./shared/text-input-types.js";

const nullableString = z.string().min(1).nullable().optional().default(null);
const nonNegativeInt = z.number().int().nonnegative();
const positiveInt = z.number().int().positive();

export const TextInputChildCapabilityIdSchema = z.enum(TEXT_INPUT_CHILD_CAPABILITY_IDS);
export const TextInputTargetKindSchema = z.enum(TEXT_INPUT_TARGET_KINDS);
export const TextInputKeySchema = z.enum(TEXT_INPUT_KEYS);
export const TextInputFailureReasonSchema = z.enum(TEXT_INPUT_FAILURE_REASONS);
export const TextInputStatusSchema = z.enum(TEXT_INPUT_STATUSES);
export const TextInputPolicyDecisionSchema = z.enum(TEXT_INPUT_POLICY_DECISIONS);
export const TextInputPrimitiveDecisionSchema = z.enum(TEXT_INPUT_PRIMITIVE_DECISIONS);
export const TextInputClipboardDecisionSchema = z.enum(TEXT_INPUT_CLIPBOARD_DECISIONS);

export const TextInputPolicySchema = z.object({
  maxTextLength: positiveInt.default(DEFAULT_TEXT_INPUT_POLICY.maxTextLength),
  primitiveTimeoutMs: positiveInt.default(DEFAULT_TEXT_INPUT_POLICY.primitiveTimeoutMs),
  maxDurationMs: positiveInt.default(DEFAULT_TEXT_INPUT_POLICY.maxDurationMs),
  allowPaste: z.boolean().default(DEFAULT_TEXT_INPUT_POLICY.allowPaste),
  allowReplace: z.boolean().default(DEFAULT_TEXT_INPUT_POLICY.allowReplace),
  allowCommit: z.boolean().default(DEFAULT_TEXT_INPUT_POLICY.allowCommit),
  restoreClipboard: z.boolean().default(DEFAULT_TEXT_INPUT_POLICY.restoreClipboard),
  allowEmptyWrite: z.boolean().default(DEFAULT_TEXT_INPUT_POLICY.allowEmptyWrite),
}).strict();

const TextInputBaseSchema = z.object({
  abilityGroupId: z.literal(TEXT_INPUT_ABILITY_GROUP_ID).default(TEXT_INPUT_ABILITY_GROUP_ID),
  sessionId: z.string().min(1),
  roundId: nullableString,
  videoVisitId: nullableString,
  requestedBy: z.string().min(1),
  purpose: z.string().min(1),
  sourceAbilityGroupId: nullableString,
  sourceChildCapabilityId: nullableString,
  targetRef: z.string().min(1),
  targetProofRef: z.string().min(1),
  targetKind: TextInputTargetKindSchema,
  targetEvidenceRefs: z.array(z.string().min(1)).max(10).default([]),
  operatorApprovalRef: nullableString,
  policy: TextInputPolicySchema.default(DEFAULT_TEXT_INPUT_POLICY),
}).strict();

export const TypeTextAbilityInputSchema = TextInputBaseSchema.extend({
  childCapabilityId: z.literal("type-text"),
  approvedText: z.string().min(1).max(DEFAULT_TEXT_INPUT_POLICY.maxTextLength),
  approvedTextRef: z.string().min(1),
  key: z.null().optional().default(null),
}).strict();

export const PasteTextAbilityInputSchema = TextInputBaseSchema.extend({
  childCapabilityId: z.literal("paste-text"),
  approvedText: z.string().min(1).max(DEFAULT_TEXT_INPUT_POLICY.maxTextLength),
  approvedTextRef: z.string().min(1),
  key: z.null().optional().default(null),
}).strict();

export const ClearInputAbilityInputSchema = TextInputBaseSchema.extend({
  childCapabilityId: z.literal("clear-input"),
  approvedText: z.null().optional().default(null),
  approvedTextRef: z.null().optional().default(null),
  key: z.null().optional().default(null),
}).strict();

export const ReplaceInputAbilityInputSchema = TextInputBaseSchema.extend({
  childCapabilityId: z.literal("replace-input"),
  approvedText: z.string().min(1).max(DEFAULT_TEXT_INPUT_POLICY.maxTextLength),
  approvedTextRef: z.string().min(1),
  key: z.null().optional().default(null),
}).strict();

export const PressKeyAbilityInputSchema = TextInputBaseSchema.extend({
  childCapabilityId: z.literal("press-key"),
  approvedText: z.null().optional().default(null),
  approvedTextRef: z.null().optional().default(null),
  key: TextInputKeySchema,
}).strict();

export const CommitInputAbilityInputSchema = TextInputBaseSchema.extend({
  childCapabilityId: z.literal("commit-input"),
  approvedText: z.null().optional().default(null),
  approvedTextRef: z.null().optional().default(null),
  key: TextInputKeySchema.default("Enter"),
}).strict();

export const TextInputAbilityInputSchema = z.discriminatedUnion("childCapabilityId", [
  TypeTextAbilityInputSchema,
  PasteTextAbilityInputSchema,
  ClearInputAbilityInputSchema,
  ReplaceInputAbilityInputSchema,
  PressKeyAbilityInputSchema,
  CommitInputAbilityInputSchema,
]);

export const TextInputClockSchema = z.object({
  portKind: z.literal(TEXT_INPUT_CLOCK_KIND),
  startedMonotonicMs: z.number().finite(),
  endedMonotonicMs: z.number().finite(),
}).strict();

export const TextInputRuntimeProofSchema = z.object({
  proofId: z.string().min(1),
  runId: z.string().min(1),
  sessionId: z.string().min(1).nullable().default(null),
  roundId: nullableString,
  videoVisitId: nullableString,
  abilityGroupId: z.literal(TEXT_INPUT_ABILITY_GROUP_ID),
  childCapabilityId: TextInputChildCapabilityIdSchema,
  sourceAbilityGroupId: nullableString,
  sourceChildCapabilityId: nullableString,
  inputRef: z.string().min(1),
  outputRef: z.string().min(1),
  attemptRef: z.string().min(1),
  actionExecutionRef: nullableString,
  primitiveExecutionRef: nullableString,
  approvedTextRef: nullableString,
  targetRef: nullableString,
  targetProofRef: nullableString,
  targetKind: TextInputTargetKindSchema,
  targetEvidenceRefs: z.array(z.string().min(1)).default([]),
  actionKind: TextInputChildCapabilityIdSchema,
  key: TextInputKeySchema.nullable().default(null),
  textLength: nonNegativeInt,
  policyDecision: TextInputPolicyDecisionSchema,
  clipboardDecision: TextInputClipboardDecisionSchema,
  primitiveDecision: TextInputPrimitiveDecisionSchema,
  primitivePortKind: z.string().min(1),
  primitiveStartedAt: nullableString,
  primitiveEndedAt: nullableString,
  maxDurationMs: nonNegativeInt,
  primitiveTimeoutMs: nonNegativeInt,
  postActionVerificationRequired: z.boolean(),
  postActionVerificationHandoffRef: nullableString,
  verificationRefPolicy: z.literal(TEXT_INPUT_VERIFICATION_REF_POLICY),
  startedAt: z.string().datetime(),
  endedAt: z.string().datetime(),
  durationMs: nonNegativeInt,
  status: TextInputStatusSchema,
  failureReason: TextInputFailureReasonSchema.nullable().default(null),
  reviewRequiredReason: nullableString,
  dataQualityFlags: z.array(z.string().min(1)).default([]),
  clock: TextInputClockSchema,
}).strict().superRefine((value, context) => {
  if (value.startedAt > value.endedAt) {
    context.addIssue({ code: z.ZodIssueCode.custom, message: "startedAt must not be after endedAt", path: ["startedAt"] });
  }
  if (value.status === "success") {
    if (value.actionExecutionRef === null) {
      context.addIssue({ code: z.ZodIssueCode.custom, message: "success proof requires actionExecutionRef", path: ["actionExecutionRef"] });
    }
    if (value.primitiveExecutionRef === null) {
      context.addIssue({ code: z.ZodIssueCode.custom, message: "success proof requires primitiveExecutionRef", path: ["primitiveExecutionRef"] });
    }
    if (value.postActionVerificationRequired !== true || value.postActionVerificationHandoffRef === null) {
      context.addIssue({ code: z.ZodIssueCode.custom, message: "success proof requires post-action verification handoff", path: ["postActionVerificationHandoffRef"] });
    }
  }
});

export const TextInputSuccessOutputSchema = z.object({
  attemptRef: z.string().min(1),
  actionExecutionRef: z.string().min(1),
  primitiveExecutionRef: z.string().min(1),
  targetRef: z.string().min(1),
  targetKind: TextInputTargetKindSchema,
  actionKind: TextInputChildCapabilityIdSchema,
  approvedTextRef: nullableString,
  textLength: nonNegativeInt,
  key: TextInputKeySchema.nullable().default(null),
  postActionVerificationRequired: z.literal(true),
  postActionVerificationHandoffRef: z.string().min(1),
}).strict();

export const TextInputAbilityResultSchema = z.object({
  abilityGroupId: z.literal(TEXT_INPUT_ABILITY_GROUP_ID),
  childCapabilityId: TextInputChildCapabilityIdSchema,
  status: TextInputStatusSchema,
  sessionId: z.string().min(1).nullable().default(null),
  roundId: nullableString,
  videoVisitId: nullableString,
  attemptRef: z.string().min(1),
  output: TextInputSuccessOutputSchema.nullable().default(null),
  failureReason: TextInputFailureReasonSchema.nullable().default(null),
  reviewRequiredReason: nullableString,
  statusMessage: z.string().min(1),
  policyDecision: TextInputPolicyDecisionSchema,
  dataQualityFlags: z.array(z.string().min(1)).default([]),
  runtimeProof: TextInputRuntimeProofSchema,
}).strict().superRefine((value, context) => {
  if (value.status === "success" && value.output === null) {
    context.addIssue({ code: z.ZodIssueCode.custom, message: "success requires output", path: ["output"] });
  }
  if (value.status !== "success" && value.output !== null) {
    context.addIssue({ code: z.ZodIssueCode.custom, message: "failed and review_required require output=null", path: ["output"] });
  }
  if (value.runtimeProof.status !== value.status) {
    context.addIssue({ code: z.ZodIssueCode.custom, message: "runtimeProof.status must equal result.status", path: ["runtimeProof", "status"] });
  }
  if (value.runtimeProof.attemptRef !== value.attemptRef) {
    context.addIssue({ code: z.ZodIssueCode.custom, message: "runtimeProof.attemptRef must equal result.attemptRef", path: ["runtimeProof", "attemptRef"] });
  }
});