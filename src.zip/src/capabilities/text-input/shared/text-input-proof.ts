export const TEXT_INPUT_POLICY_DECISIONS = ["allow", "block", "review_required"] as const;
export const TEXT_INPUT_PRIMITIVE_DECISIONS = ["not_run", "succeeded", "failed", "aborted", "timed_out"] as const;
export const TEXT_INPUT_CLIPBOARD_DECISIONS = ["not_used", "prepared", "restored", "failed"] as const;
export const TEXT_INPUT_CLOCK_KIND = "system-monotonic-clock" as const;
export const TEXT_INPUT_VERIFICATION_REF_POLICY = "target_proof_ref+approved_text_ref+action_execution_ref" as const;