export const DEFAULT_TEXT_INPUT_POLICY = {
  maxTextLength: 4000,
  primitiveTimeoutMs: 5000,
  maxDurationMs: 10000,
  allowPaste: true,
  allowReplace: true,
  allowCommit: true,
  restoreClipboard: true,
  allowEmptyWrite: false,
} as const;