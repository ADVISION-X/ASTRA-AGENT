type PromptContract = {
  id: string;
  taskType: string;
  modelRole: "vision" | "ocr" | "commentUnderstanding" | "productSignal";
  promptVersion: string;
  schemaVersion: string;
  purpose: string;
  forbiddenOutputs: string[];
};

const PROMPT_CONTRACTS: readonly PromptContract[] = [
  {
    id: "visual-mission-judge-v1",
    taskType: "vision.visualMissionActionPlan",
    modelRole: "vision",
    promptVersion: "v1",
    schemaVersion: "visualMissionActionPlan.v1",
    purpose: "Return governed visual mission judgment JSON only.",
    forbiddenOutputs: ["raw coordinates", "browser commands", "DOM selectors", "Nerve Bus payload", "Forensics payload"],
  },
  {
    id: "comments.disabled_by_policy.v1",
    taskType: "comments.intent_analysis",
    modelRole: "commentUnderstanding",
    promptVersion: "comments.disabled_by_policy.v1",
    schemaVersion: "comment-signal.v1",
    purpose: "Analyze cleaned comments and return JSON only.",
    forbiddenOutputs: ["free-form prose", "HTML", "markdown"],
  },
];

const getPromptContract = (taskType: string) => {
  const contract = PROMPT_CONTRACTS.find((entry) => entry.taskType === taskType);
  if (!contract) {
    throw new Error(`Unsupported local AI task type: ${taskType}`);
  }
  return contract;
};

const getPromptContractById = (id: string) => PROMPT_CONTRACTS.find((entry) => entry.id === id) ?? null;

const getRequiredModelRole = (taskType: string) => getPromptContract(taskType).modelRole;

const listPromptContracts = () => [...PROMPT_CONTRACTS];

export {
  getPromptContract,
  getPromptContractById,
  getRequiredModelRole,
  listPromptContracts,
};

export type { PromptContract };