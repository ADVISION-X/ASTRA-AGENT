import { buildVisualMissionJudgePrompt } from "../../capabilities/ai/index.js";

export function buildLocalAiVisualMissionActionPlanPromptParts(
  input: Parameters<typeof buildVisualMissionJudgePrompt>[0],
) {
  return buildVisualMissionJudgePrompt(input);
}