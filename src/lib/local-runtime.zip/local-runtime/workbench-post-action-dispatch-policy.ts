import type { AbilityCommandEnvelope } from "../../capabilities/nerve-bus/shared/nerve-bus-envelope.js";
import type { WorkbenchPayloadDocument as NerveBusPayloadDocument } from "./workbench-payload.js";
import { payloadDocumentToObject, payloadValueToString } from "./workbench-payload.js";

type SupportedPostActionChildCapabilityId =
  | "observe-page-open-attempt"
  | "observe-comments-panel-open-attempt"
  | "observe-comments-panel-close-attempt"
  | "observe-not-interested-attempt"
  | "observe-target-state-transition"
  | "verify-action-result";

export type PostActionInputPolicy = {
  childCapabilityId: SupportedPostActionChildCapabilityId;
  outcomeType: "page_opened" | "comments_panel_opened" | "comments_panel_closed" | "not_interested_applied" | "target_state_changed";
  sourceAbilityGroupId: "open" | "mouse-click" | "mouse-scroll";
  sourceChildCapabilityId: "open-tiktok" | "open-facebook" | "click-browser-coordinate" | "scroll-browser-viewport";
  sourceActionType: string;
  verificationMode: "observation_only" | "visual_evidence" | "before_after_comparison";
  requireAfterEvidence: boolean;
  requireBeforeAfterComparison: boolean;
  requiresVisualEvidence: boolean;
  executionRefField: "primitiveExecutionRef" | "scrollExecutionRef";
};

const POST_ACTION_POLICY_BY_COMMAND: Partial<Record<string, PostActionInputPolicy>> = {
  "observe-page-open-attempt": {
    childCapabilityId: "observe-page-open-attempt",
    outcomeType: "page_opened",
    sourceAbilityGroupId: "open",
    sourceChildCapabilityId: "open-tiktok",
    sourceActionType: "open_page",
    verificationMode: "observation_only",
    requireAfterEvidence: false,
    requireBeforeAfterComparison: false,
    requiresVisualEvidence: false,
    executionRefField: "primitiveExecutionRef",
  },
  "observe-comments-panel-open-attempt": {
    childCapabilityId: "observe-comments-panel-open-attempt",
    outcomeType: "comments_panel_opened",
    sourceAbilityGroupId: "mouse-click",
    sourceChildCapabilityId: "click-browser-coordinate",
    sourceActionType: "open_comments",
    verificationMode: "visual_evidence",
    requireAfterEvidence: true,
    requireBeforeAfterComparison: false,
    requiresVisualEvidence: true,
    executionRefField: "primitiveExecutionRef",
  },
  "observe-comments-panel-close-attempt": {
    childCapabilityId: "observe-comments-panel-close-attempt",
    outcomeType: "comments_panel_closed",
    sourceAbilityGroupId: "mouse-click",
    sourceChildCapabilityId: "click-browser-coordinate",
    sourceActionType: "close_comments",
    verificationMode: "visual_evidence",
    requireAfterEvidence: true,
    requireBeforeAfterComparison: false,
    requiresVisualEvidence: true,
    executionRefField: "primitiveExecutionRef",
  },
  "observe-not-interested-attempt": {
    childCapabilityId: "observe-not-interested-attempt",
    outcomeType: "not_interested_applied",
    sourceAbilityGroupId: "mouse-click",
    sourceChildCapabilityId: "click-browser-coordinate",
    sourceActionType: "not_interested",
    verificationMode: "before_after_comparison",
    requireAfterEvidence: true,
    requireBeforeAfterComparison: true,
    requiresVisualEvidence: false,
    executionRefField: "primitiveExecutionRef",
  },
};

const DEFAULT_POST_ACTION_POLICY: PostActionInputPolicy = {
  childCapabilityId: "verify-action-result",
  outcomeType: "target_state_changed",
  sourceAbilityGroupId: "mouse-click",
  sourceChildCapabilityId: "click-browser-coordinate",
  sourceActionType: "click_target_state_change",
  verificationMode: "before_after_comparison",
  requireAfterEvidence: true,
  requireBeforeAfterComparison: true,
  requiresVisualEvidence: false,
  executionRefField: "primitiveExecutionRef",
};

export const normalizePageStateLogin = (loginState: string | null | undefined) => {
  if (loginState === "logged_in") {
    return "ready" as const;
  }
  if (loginState === "login_required" || loginState === "review_required") {
    return loginState;
  }
  return "unknown" as const;
};

const resolveExpectedOpenHost = (inputPayload: NerveBusPayloadDocument): string | null => {
  const targetUrl = payloadValueToString(payloadDocumentToObject(inputPayload).targetUrl);
  if (!targetUrl) {
    return null;
  }

  if (!URL.canParse(targetUrl)) {
    return null;
  }

  return new URL(targetUrl).hostname;
};

export const resolvePostActionInputPolicy = (envelope: AbilityCommandEnvelope): PostActionInputPolicy => {
  return POST_ACTION_POLICY_BY_COMMAND[envelope.commandName] ?? DEFAULT_POST_ACTION_POLICY;
};

export const buildExpectedOutcome = (
  envelope: AbilityCommandEnvelope,
  inputPayload: NerveBusPayloadDocument,
  policy: PostActionInputPolicy,
) => ({
  outcomeType: policy.outcomeType,
  description: inputPayload.summary,
  expectedUrlHost: policy.childCapabilityId === "observe-page-open-attempt" ? resolveExpectedOpenHost(inputPayload) : null,
  expectedUrlPrefix: null,
  expectedState: null,
  expectedTargetType: null,
  requiresBeforeAfterComparison: policy.requireBeforeAfterComparison,
  requiresVisualEvidence: policy.requiresVisualEvidence,
});

export const buildVerificationPolicy = (policy: PostActionInputPolicy) => ({
  verificationMode: policy.verificationMode,
  requireAfterEvidence: policy.requireAfterEvidence,
  requireBeforeAfterComparison: policy.requireBeforeAfterComparison,
  allowSelfReportedSuccess: false,
});

export const buildPostActionChainFields = (envelope: AbilityCommandEnvelope) => ({
  missionId: envelope.missionId,
  runId: envelope.runId,
  sessionId: envelope.sessionId,
  roundId: envelope.roundId,
  videoVisitId: envelope.videoVisitId,
  stepId: envelope.stepId,
  bindingPackageId: envelope.bindingPackageId,
  bindingPackageVersion: envelope.bindingPackageVersion,
  selectedBindingId: envelope.mapId,
  bindingVersion: envelope.bindingVersion,
  bindingActivationRef: envelope.bindingActivationRef,
  bindingSnapshotRef: envelope.bindingSnapshotRef,
  capabilityCallId: envelope.capabilityCallId,
  nerveBusEnvelopeId: envelope.nerveBusEnvelopeId,
});