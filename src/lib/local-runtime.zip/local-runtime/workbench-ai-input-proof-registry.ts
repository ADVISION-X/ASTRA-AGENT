type WorkbenchAiInputProofSummary = {
  promptInputRef: string;
  aiInputArtifactRef: string;
  aiInputStorageRef: string;
  sourceScreenshotEvidenceId: string;
  sourceStorageRef: string;
  preparedImageHash: string;
  preparedImageWidth: number;
  preparedImageHeight: number;
  coordinateSpace: "ai_input_pixels";
};

const inputProofRegistry = new Map<string, WorkbenchAiInputProofSummary>();

const recordAiInputProofSummary = (input: WorkbenchAiInputProofSummary) => {
  inputProofRegistry.set(input.promptInputRef, input);
};

const resolveAiInputProofSummary = (promptInputRef: string | null | undefined) => {
  if (!promptInputRef) {
    return null;
  }

  return inputProofRegistry.get(promptInputRef) ?? null;
};

export {
  recordAiInputProofSummary,
  resolveAiInputProofSummary,
};

export type { WorkbenchAiInputProofSummary };