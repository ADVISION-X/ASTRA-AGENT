import type { VisualMissionActionPlanOutput } from "../../types/visual-mission-action-plan.js";
import type { AiAbilityResult } from "../../capabilities/ai/index.js";

type AiSummaryBase<TTaskType extends string, TOutput, TInput = unknown> = {
  aiResultRef: string;
  aiProofRef: string;
  taskType: TTaskType;
  missionId: string;
  runId: string;
  capturedAt: string;
  promptContractId: string;
  promptContractVersion: string;
  promptCatalogVersion: string;
  aiInputArtifactRef: string | null;
  input: TInput;
  output: TOutput;
};

type AiProductPresenceOutputSummary = AiSummaryBase<
  "product_presence_judgment",
  {
    isProductVideo: boolean | null;
    mustReview: boolean;
    taskDecision: string;
    actionPlan: {
      actions: Array<{ actionCode: string }>;
    };
    confidence: number | null;
    visibleProductTypes: string[];
    reason: string;
  }
>;

type AiVisualMissionActionPlanOutputSummary = AiSummaryBase<
  "visual_mission_judgment",
  VisualMissionActionPlanOutput
>;

type AiVisualTargetCandidateOutputSummary = AiSummaryBase<
  "visual_target_candidate_analysis",
  {
    targetCandidates: Array<{
      candidateId: string;
      targetType: string;
      boundingBox: { x: number; y: number; width: number; height: number };
      clickPoint: { x: number; y: number };
      confidence: number;
      coordinateSpace: string;
      visibleText: string | null;
      uncertainty: string[];
      evidenceObservations: string[];
    }>;
  }
>;

type AiOcrCleanupOutputSummary = AiSummaryBase<
  "ocr_cleanup",
  {
    cleanedComments: string[];
    uncertainText: string[];
  },
  {
    rawCommentBlocks: unknown[];
  }
>;

type AiPagePreparationOutputSummary = AiSummaryBase<
  "page_preparation_judgment",
  {
    decision: "yes" | "no";
    nonExecutableSummary?: string;
  }
>;

type AnyAiSummary =
  | AiOcrCleanupOutputSummary
  | AiPagePreparationOutputSummary
  | AiProductPresenceOutputSummary
  | AiVisualMissionActionPlanOutputSummary
  | AiVisualTargetCandidateOutputSummary;

const resultSummaryRegistry = new Map<string, AnyAiSummary>();

const resolveSummary = (aiResultRef: string | null | undefined) => {
  if (!aiResultRef) {
    return null;
  }

  return resultSummaryRegistry.get(aiResultRef) ?? null;
};

const recordWorkbenchAiResultSummary = (input: {
  aiResultRef: string;
  aiResult: AiAbilityResult;
}) => {
  if (input.aiResult.taskType !== "visual_mission_judgment" || !input.aiResult.output) {
    return;
  }

  resultSummaryRegistry.set(input.aiResultRef, {
    aiResultRef: input.aiResultRef,
    aiProofRef: input.aiResult.runtimeProof.proofId,
    taskType: "visual_mission_judgment",
    missionId: input.aiResult.missionId,
    runId: input.aiResult.runId,
    capturedAt: input.aiResult.createdAt,
    promptContractId: input.aiResult.promptContractId,
    promptContractVersion: input.aiResult.promptContractVersion,
    promptCatalogVersion: input.aiResult.promptCatalogVersion,
    aiInputArtifactRef: input.aiResult.runtimeProof.inputRefs[0] ?? null,
    input: {},
    output: input.aiResult.output,
  });
};

const resolveAiOcrCleanupOutputSummary = (aiResultRef: string | null | undefined) => {
  const summary = resolveSummary(aiResultRef);
  return summary?.taskType === "ocr_cleanup" ? summary : null;
};

const resolveAiPagePreparationOutputSummary = (aiResultRef: string | null | undefined) => {
  const summary = resolveSummary(aiResultRef);
  return summary?.taskType === "page_preparation_judgment" ? summary : null;
};

const resolveAiProductPresenceOutputSummary = (aiResultRef: string | null | undefined) => {
  const summary = resolveSummary(aiResultRef);
  return summary?.taskType === "product_presence_judgment" ? summary : null;
};

const resolveAiVisualMissionActionPlanOutputSummary = (aiResultRef: string | null | undefined) => {
  const summary = resolveSummary(aiResultRef);
  return summary?.taskType === "visual_mission_judgment" ? summary : null;
};

const resolveAiVisualTargetCandidateOutputSummary = (aiResultRef: string | null | undefined) => {
  const summary = resolveSummary(aiResultRef);
  return summary?.taskType === "visual_target_candidate_analysis" ? summary : null;
};

export {
  recordWorkbenchAiResultSummary,
  resolveAiOcrCleanupOutputSummary,
  resolveAiPagePreparationOutputSummary,
  resolveAiProductPresenceOutputSummary,
  resolveAiVisualMissionActionPlanOutputSummary,
  resolveAiVisualTargetCandidateOutputSummary,
};

export type {
  AiOcrCleanupOutputSummary,
  AiPagePreparationOutputSummary,
  AiProductPresenceOutputSummary,
  AiVisualMissionActionPlanOutputSummary,
  AiVisualTargetCandidateOutputSummary,
};