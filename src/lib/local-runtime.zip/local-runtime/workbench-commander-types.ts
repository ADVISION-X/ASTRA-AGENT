import type { CommanderConsoleAbilityGroup as ExternalCommanderConsoleAbilityGroup } from "../../capabilities/commander-console/contract.js";

export type WorkbenchCommanderConsoleAbilityGroup = ExternalCommanderConsoleAbilityGroup;

/**
 * CommanderMissionDashboardView — owned by the local-runtime workbench layer, NOT by commander-console.
 * Commander-console only provides a minimal CommanderMissionStatusView.
 * This full view is assembled by the workbench from local runtime state.
 */
export type WorkbenchCommanderMissionDashboardView = {
  mission: {
    missionId: string | null;
    humanGoal: string;
    status: string;
    missionRunRef: string | null;
    currentRoundIndex: number;
    requestedPlatform: string | null;
    selectedBindingId: string | null;
    lastHumanCommand: string | null;
    reviewRequiredReason: string | null;
    failureReason: string | null;
    startedAt: string | null;
    updatedAt: string | null;
    endedAt: string | null;
  };
  runtime: {
    runtimeStatus: string;
    currentStep: string | null;
    reviewReason: string | null;
    totalSeenCount: number;
    evidencePacketCount: number;
    browseLedgerCount: number;
    candidateCount: number;
    lastAiFailureReason: string | null;
  };
  browser: {
    dataMode: string;
    platformId: string;
    platformLabel: string;
    realPlatformConnection: string;
    browserMode: string;
    browserExecutable: string | null;
    browserProfileRef: string;
    browserProfileStatus: string;
    browserProfileDirectory: string;
    browserProfileProvisioning: string;
    browserProfileVerificationStatus: string;
    browserProfileVerificationReason: string;
    loginState: string;
    lastLoginCheckAt: string | null;
    loginRequiredReason: string | null;
    reviewRequiredReason: string | null;
    storeScope: string;
    executionMode: string;
    fallbackMode: string;
    geometryGuard: string;
    viewport: string;
    calibration: string;
    orientation: string;
  };
  health: Array<{
    id: string;
    label: string;
    tone: "normal" | "good" | "warn" | "danger" | "muted";
    detail: string;
    ownerResponsible?: string | null;
    actionableMessage?: string | null;
    failureReason?: string | null;
    missionRuntimeAvailable?: boolean;
    checkedAt?: string | null;
  }>;
  capabilityRoster: Array<{
    abilityGroupId: string;
    displayName: string;
    currentStrength: string;
    purpose: string;
  }>;
  candidates: Array<{
    id: string;
    category: string;
    useCase: string;
    score: number;
    purchaseIntent: string;
    reviewStatus: string;
    evidenceCount: number;
    notes: string[];
    createdAt: string;
    updatedAt: string;
  }>;
  reviewQueue: Array<{ id: string; primary: string; secondary: string; detail: string }>;
  evidencePackets: Array<{ id: string; primary: string; secondary: string; detail: string }>;
  browseLedger: Array<{ id: string; primary: string; secondary: string; detail: string }>;
  failedRecords: Array<{ id: string; primary: string; secondary: string; detail: string }>;
  runtimeProof: Array<{
    id: string;
    createdAt: string;
    step: string;
    status: string;
    message: string;
  }>;
  auditSummary: {
    phase: string;
    activeLawDomains: string[];
    lastGeneratedAt: string | null;
    lastRunGeneratedAt: string | null;
    totals: {
      inspectors: number;
      passed: number;
      failed: number;
      blocking: number;
    } | null;
  };
};