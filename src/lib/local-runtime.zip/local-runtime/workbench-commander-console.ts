import { createCommanderConsoleAbilityGroup } from "../../capabilities/commander-console/ability-group.js";
import type { CommanderMissionStatusView } from "../../capabilities/commander-console/schema.js";
import type { WorkbenchRuntime } from "./workbench-contract.js";
import type { WorkbenchCommanderMissionDashboardView } from "./workbench-commander-types.js";
import { createCommandTransport } from "./workbench-commander-command-transport.js";

type CommanderConsoleAbilityGroup = ReturnType<typeof createCommanderConsoleAbilityGroup>;

// ─── Workbench-assembled mission status → dashboard view ─────────────────────
//
// Commander-console only returns a minimal CommanderMissionStatusView.
// The workbench assembles the full CommanderMissionDashboardView from:
//   1. Minimal mission status from show-mission-status
//   2. Browser session state from local runtime
//   3. Capability roster from local runtime
//   4. Empty forensics/audit collections (forensics owns those)
//
// Note: evidence packets, browse ledger, candidates, failed records, runtime proof,
// and audit summary are assembled by the workbench from the local runtime, NOT
// from Commander read models. Commander does not own these read models.

const buildMissionSection = (status: CommanderMissionStatusView) => ({
  missionId: status.missionId,
  humanGoal: status.userRequirementSummary ?? "",
  status: status.status,
  missionRunRef: null,
  currentRoundIndex: 0,
  requestedPlatform: status.currentPlatform,
  selectedBindingId: null,
  lastHumanCommand: null,
  reviewRequiredReason: status.reviewRequiredReason,
  failureReason: status.lastStopReason,
  startedAt: status.startedAt,
  updatedAt: status.updatedAt,
  endedAt: null,
});

const buildRuntimeSection = (status: CommanderMissionStatusView) => ({
  runtimeStatus: status.status,
  currentStep: null,
  reviewReason: status.reviewRequiredReason,
  totalSeenCount: 0,
  evidencePacketCount: status.savedEvidenceCount,
  browseLedgerCount: 0,
  candidateCount: 0,
  lastAiFailureReason: null,
});

const buildBrowserSection = (runtime: WorkbenchRuntime) => {
  const browser = runtime.browserController.getSessionState();
  return {
    dataMode: "real-platform" as const,
    platformId: "agent-shell",
    platformLabel: "Mission-governed multi-platform agent shell",
    realPlatformConnection: "current local Chrome session",
    browserMode: "current-chrome" as const,
    browserExecutable: browser.browserExecutable,
    browserProfileRef: browser.browserProfileRef,
    browserProfileStatus: browser.profileStatus,
    browserProfileDirectory: browser.profileDirectory,
    browserProfileProvisioning: "operator-managed" as const,
    browserProfileVerificationStatus: browser.profileVerificationStatus,
    browserProfileVerificationReason: browser.profileVerificationReason ?? "browser session available",
    loginState: browser.loginState,
    lastLoginCheckAt: browser.lastLoginCheckAt,
    loginRequiredReason: browser.loginRequiredReason,
    reviewRequiredReason: browser.reviewRequiredReason,
    storeScope: "local enforcement store",
    executionMode: "live",
    fallbackMode: "none",
    geometryGuard: "capability-owned at execution time",
    viewport: "browser-managed",
    calibration: "not_applicable",
    orientation: "capability-owned",
  };
};

const buildBrowserFallbackSection = (runtime: WorkbenchRuntime, failureReason: string) => {
  const browser = runtime.browserController.getSessionState();
  return {
    dataMode: "real-platform" as const,
    platformId: "agent-shell",
    platformLabel: "Mission-governed multi-platform agent shell",
    realPlatformConnection: "current local Chrome session",
    browserMode: "current-chrome" as const,
    browserExecutable: browser.browserExecutable,
    browserProfileRef: browser.browserProfileRef,
    browserProfileStatus: browser.profileStatus,
    browserProfileDirectory: browser.profileDirectory,
    browserProfileProvisioning: "operator-managed" as const,
    browserProfileVerificationStatus: browser.profileVerificationStatus,
    browserProfileVerificationReason: browser.profileVerificationReason ?? failureReason,
    loginState: browser.loginState,
    lastLoginCheckAt: browser.lastLoginCheckAt,
    loginRequiredReason: browser.loginRequiredReason,
    reviewRequiredReason: browser.reviewRequiredReason,
    storeScope: "local enforcement store",
    executionMode: "dashboard degraded fallback",
    fallbackMode: "status-read timeout fallback",
    geometryGuard: "capability-owned at execution time",
    viewport: "not_available_in_fallback",
    calibration: "not_applicable",
    orientation: "capability-owned",
  };
};

const buildFallbackCommanderConsoleSnapshot = (
  runtime: WorkbenchRuntime,
  failureReason: string,
): WorkbenchCommanderMissionDashboardView => {
  const now = new Date().toISOString();
  return {
    mission: {
      missionId: null,
      humanGoal: "",
      status: "review_required",
      missionRunRef: null,
      currentRoundIndex: 0,
      requestedPlatform: null,
      selectedBindingId: null,
      lastHumanCommand: null,
      reviewRequiredReason: failureReason,
      failureReason: null,
      startedAt: null,
      updatedAt: now,
      endedAt: null,
    },
    runtime: {
      runtimeStatus: "review_required",
      currentStep: "show-mission-status",
      reviewReason: failureReason,
      totalSeenCount: 0,
      evidencePacketCount: 0,
      browseLedgerCount: 0,
      candidateCount: 0,
      lastAiFailureReason: null,
    },
    browser: buildBrowserFallbackSection(runtime, failureReason),
    health: [{
      id: "commander-status",
      label: "Commander Status",
      tone: "warn" as const,
      detail: "Status read failed; serving fallback shell so startup stays alive.",
      ownerResponsible: "Commander Console",
      actionableMessage: "Check mission runtime availability.",
      failureReason,
      missionRuntimeAvailable: false,
      checkedAt: now,
    }],
    capabilityRoster: [],
    candidates: [],
    reviewQueue: [],
    evidencePackets: [],
    browseLedger: [],
    failedRecords: [],
    runtimeProof: [{
      id: "commander-fallback",
      createdAt: now,
      step: "show-mission-status",
      status: "review_required",
      message: failureReason,
    }],
    auditSummary: {
      phase: "unknown",
      activeLawDomains: [],
      lastGeneratedAt: null,
      lastRunGeneratedAt: null,
      totals: null,
    },
  };
};

const buildSnapshotFromStatus = (
  status: CommanderMissionStatusView,
  runtime: WorkbenchRuntime,
): WorkbenchCommanderMissionDashboardView => ({
  mission: buildMissionSection(status),
  runtime: buildRuntimeSection(status),
  browser: buildBrowserSection(runtime),
  health: [],
  capabilityRoster: [],
  candidates: [],
  reviewQueue: [],
  evidencePackets: [],
  browseLedger: [],
  failedRecords: [],
  runtimeProof: [],
  auditSummary: {
    phase: "active",
    activeLawDomains: [],
    lastGeneratedAt: null,
    lastRunGeneratedAt: null,
    totals: null,
  },
});

// ─── Factory ──────────────────────────────────────────────────────────────────

export const createWorkbenchCommanderConsole = (
  runtime: WorkbenchRuntime,
): CommanderConsoleAbilityGroup => {
  const missionSelectionState = { lastMissionId: null as string | null };
  const rawTransport = createCommandTransport(
    runtime,
    missionSelectionState,
    (input) => runtime.nerveBusAbilityGroup.dispatchHumanCommand(input),
  );

  // Adapt emitHumanCommand → CommandTransportPort.sendHumanCommandEnvelope
  const commandTransport: import("../../capabilities/commander-console/envelope.js").CommandTransportPort = {
    sendHumanCommandEnvelope: async (envelope) => {
      try {
        const result = await rawTransport.emitHumanCommand({
          commandId: envelope.commandId,
          commandType: envelope.commandType,
          priority: "normal",
          operatorRef: envelope.operatorRef,
          targetMissionId: envelope.missionId,
          selectedBindingId: null,
          targetRecordRef: null,
          requestedPlatformId: (envelope.requestedPlatformId as import("./workbench-contract.js").RequestedPlatformId) ?? null,
          humanGoal: envelope.userRequirementText,
          maxRounds: envelope.maxRounds ?? null,
          maxMinutes: envelope.maxMinutes ?? null,
          operatorNote: null,
          idempotencyKey: envelope.idempotencyKey,
          timeoutMs: envelope.timeoutMs,
          payload: envelope.payload as Record<string, unknown>,
        });
        return {
          ok: result.status === "accepted",
          transportRef: result.envelopeRef ?? null,
          failureReason: result.failureReason ?? null,
        };
      } catch (err) {
        return {
          ok: false,
          transportRef: null,
          failureReason: err instanceof Error ? err.message : "Transport error",
        };
      }
    },
  };

  const getMissionStatus = (): CommanderMissionStatusView => {
    const missionState = (runtime as Record<string, unknown>)["missionRuntime"] as {
      getState?: () => {
        missionId?: string | null;
        status?: string;
        requestedPlatformId?: string | null;
        userRequirementText?: string | null;
        startedAt?: string | null;
        stopReason?: string | null;
        reviewRequiredReason?: string | null;
        savedEvidenceCount?: number;
        failedActionCount?: number;
      } | null;
    } | null;
    const state = missionState?.getState?.() ?? null;
    const now = new Date().toISOString();
    return {
      missionId: state?.missionId ?? null,
      status: (state?.status as CommanderMissionStatusView["status"]) ?? "unknown",
      currentPlatform: state?.requestedPlatformId ?? null,
      userRequirementSummary: state?.userRequirementText ?? null,
      startedAt: state?.startedAt ?? null,
      updatedAt: now,
      lastStopReason: state?.stopReason ?? null,
      reviewRequiredReason: state?.reviewRequiredReason ?? null,
      savedEvidenceCount: state?.savedEvidenceCount ?? 0,
      failedActionCount: state?.failedActionCount ?? 0,
    };
  };

  return createCommanderConsoleAbilityGroup({
    defaultOperatorRef: "commander-console:operator",
    commandTransport,
    getMissionStatus,
  });
};

export const getCommanderConsoleSnapshot = async (
  runtime: WorkbenchRuntime,
): Promise<WorkbenchCommanderMissionDashboardView> => {
  const result = await runtime.commanderConsole.execute({
    childCapabilityId: "show-mission-status",
    operatorRef: "commander-console:shell",
    input: {},
  });
  if (result.status !== "success" || result.output === null) {
    return buildFallbackCommanderConsoleSnapshot(
      runtime,
      result.failureReason ?? result.reviewRequiredReason ?? "Failed to read mission status.",
    );
  }
  return buildSnapshotFromStatus(result.output as CommanderMissionStatusView, runtime);
};

type CommanderConsoleAbilityGroup = ReturnType<typeof createCommanderConsoleAbilityGroup>;

type CommanderConsoleFallbackContext = {
  failureReason: string;
  now: string;
  browser: ReturnType<WorkbenchRuntime["browserController"]["getSessionState"]>;
};

const buildCommanderConsoleFallbackMissionSection = (context: CommanderConsoleFallbackContext) => ({
  missionId: null,
  humanGoal: "",
  status: "review_required" as const,
  missionRunRef: null,
  currentRoundIndex: 0,
  requestedPlatform: null,
  selectedBindingId: null,
  lastHumanCommand: null,
  reviewRequiredReason: context.failureReason,
  failureReason: null,
  startedAt: null,
  updatedAt: context.now,
  endedAt: null,
});

const buildCommanderConsoleFallbackRuntimeSection = (context: CommanderConsoleFallbackContext) => ({
  runtimeStatus: "review_required" as const,
  currentStep: "show-mission-dashboard",
  reviewReason: context.failureReason,
  totalSeenCount: 0,
  evidencePacketCount: 0,
  browseLedgerCount: 0,
  candidateCount: 0,
  lastAiFailureReason: null,
});

const buildCommanderConsoleFallbackBrowserSection = (context: CommanderConsoleFallbackContext) => ({
  dataMode: "real-platform" as const,
  platformId: "agent-shell",
  platformLabel: "Mission-governed multi-platform agent shell",
  realPlatformConnection: "current local Chrome session",
  browserMode: "current-chrome" as const,
  browserExecutable: context.browser.browserExecutable,
  browserProfileRef: context.browser.browserProfileRef,
  browserProfileStatus: context.browser.profileStatus,
  browserProfileDirectory: context.browser.profileDirectory,
  browserProfileProvisioning: "operator-managed" as const,
  browserProfileVerificationStatus: context.browser.profileVerificationStatus,
  browserProfileVerificationReason: context.browser.profileVerificationReason ?? "dashboard fallback is serving current browser session metadata",
  loginState: context.browser.loginState,
  lastLoginCheckAt: context.browser.lastLoginCheckAt,
  loginRequiredReason: context.browser.loginRequiredReason,
  reviewRequiredReason: context.browser.reviewRequiredReason,
  storeScope: "local phase-04 enforcement store",
  executionMode: "dashboard degraded fallback",
  fallbackMode: "read-model timeout fallback",
  geometryGuard: "capability-owned at execution time",
  viewport: "not_available_in_dashboard_fallback",
  calibration: "not_applicable",
  orientation: "capability-owned",
});

const buildCommanderConsoleFallbackHealthSection = (context: CommanderConsoleFallbackContext) => ([{
  id: "commander-dashboard",
  label: "Commander Dashboard",
  tone: "warn" as const,
  detail: "Dashboard read model timed out; serving fallback shell so startup stays alive.",
  ownerResponsible: "Commander Console",
  actionableMessage: "Inspect read-model latency and state size; app shell remains available.",
  failureReason: context.failureReason,
  missionRuntimeAvailable: false,
  checkedAt: context.now,
}]);

const buildCommanderConsoleFallbackRuntimeProofSection = (context: CommanderConsoleFallbackContext) => ([{
  id: "commander-dashboard:fallback",
  createdAt: context.now,
  step: "show-mission-dashboard",
  status: "review_required" as const,
  message: context.failureReason,
}]);

const buildCommanderConsoleFallbackAuditSummarySection = () => ({
  phase: "unknown",
  activeLawDomains: [],
  lastGeneratedAt: null,
  lastRunGeneratedAt: null,
  totals: null,
});

const buildFallbackCommanderConsoleSnapshot = (
  runtime: WorkbenchRuntime,
  failureReason: string,
): CommanderMissionDashboardView => {
  const context = {
    failureReason,
    now: new Date().toISOString(),
    browser: runtime.browserController.getSessionState(),
  };
  return {
    mission: buildCommanderConsoleFallbackMissionSection(context),
    runtime: buildCommanderConsoleFallbackRuntimeSection(context),
    browser: buildCommanderConsoleFallbackBrowserSection(context),
    health: buildCommanderConsoleFallbackHealthSection(context),
    capabilityRoster: [],
    candidates: [],
    reviewQueue: [],
    evidencePackets: [],
    browseLedger: [],
    failedRecords: [],
    runtimeProof: buildCommanderConsoleFallbackRuntimeProofSection(context),
    auditSummary: buildCommanderConsoleFallbackAuditSummarySection(),
  };
};

export const createWorkbenchCommanderConsole = (
  runtime: WorkbenchRuntime,
): CommanderConsoleAbilityGroup => {
  const missionSelectionState = { lastMissionId: null };
  return createCommanderConsoleAbilityGroup({
    defaultOperatorRef: "commander-console:operator",
    commandTransport: createCommandTransport(runtime, missionSelectionState),
    missionReadModel: createMissionReadModel(runtime, missionSelectionState),
    forensicsReadModel: createForensicsReadModel(runtime),
    capabilityHealthReadModel: createCapabilityHealthReadModel(runtime),
    auditReadModel: createAuditReadModel(),
    runtimeProofReadModel: createRuntimeProofReadModel(runtime),
  });
};

export const getCommanderConsoleSnapshot = async (
  runtime: WorkbenchRuntime,
): Promise<CommanderMissionDashboardView> => {
  const result = await runtime.commanderConsole.execute({ childCapabilityId: "show-mission-dashboard", operatorRef: "commander-console:shell", input: {} });
  if (result.status !== "success" || result.output === null) {
    return buildFallbackCommanderConsoleSnapshot(runtime, result.failureReason ?? result.reviewRequiredReason ?? "Failed to read commander dashboard.");
  }
  return result.output as CommanderMissionDashboardView;
};
