import type {
  AiRequestDispatchInput,
} from "../../capabilities/nerve-bus/contract.js";

import {
  payloadDocumentToObject,
  payloadValueToString,
} from "./workbench-payload.js";
import {
  buildWorkbenchAiInputRefs,
  ensureWorkbenchAiInputProof,
  resolveWorkbenchAiInputProofSummary,
} from "./workbench-nerve-bus-ai-input-proof-support.js";
import { buildWorkbenchVisualMissionActionPlanInput } from "./workbench-visual-mission-action-plan-input.js";

type WorkbenchAiRequestEnvelope = AiRequestDispatchInput["envelope"];
type WorkbenchAiPayloadDocument = AiRequestDispatchInput["inputPayload"];
type WorkbenchAiExecuteInput = Parameters<import("./workbench-contract.js").WorkbenchRuntime["aiAbilityGroup"]["execute"]>[0];

const PAGE_PREPARATION_TASK_TYPE = "page_preparation_judgment";
const PRODUCT_PRESENCE_TASK_TYPE = "product_presence_judgment";
const VISUAL_MISSION_ACTION_PLAN_TASK_TYPE = "visual_mission_judgment";
const VISUAL_TARGET_CANDIDATE_TASK_TYPE = "visual_target_candidate_analysis";
const SUPPORTED_WORKBENCH_AI_TASK_TYPES = [
  "page_preparation_judgment",
  "product_presence_judgment",
  "visual_observation",
  "visual_mission_judgment",
  "visual_target_candidate_analysis",
  "ocr_cleanup",
  "comment_signal_summary",
  "product_signal_summary",
  "evidence_packet_analysis",
  "map_authoring",
  "schema_validation_only",
] as const;

type SupportedWorkbenchAiTaskType = (typeof SUPPORTED_WORKBENCH_AI_TASK_TYPES)[number];

const isSupportedWorkbenchAiTaskType = (taskType: string): taskType is SupportedWorkbenchAiTaskType =>
  SUPPORTED_WORKBENCH_AI_TASK_TYPES.some((candidate) => candidate === taskType);

const resolveAiTaskType = (envelope: WorkbenchAiRequestEnvelope): (typeof SUPPORTED_WORKBENCH_AI_TASK_TYPES)[number] => {
  const taskType = envelope.taskType;
  if (isSupportedWorkbenchAiTaskType(taskType)) {
    return taskType;
  }
  throw new Error(`Workbench AI request has unsupported taskType: ${taskType}`);
};

const requireChainField = (value: string | null | undefined): string => {
  if (!value) {
    throw new Error("Workbench AI request is missing required governed visual-mission chain fields.");
  }

  return value;
};

const buildDefaultAiInputPayload = (inputPayload: WorkbenchAiPayloadDocument) => {
  return payloadDocumentToObject(inputPayload);
};

const buildUniqueAiInputRefs = (refs: Array<string | null | undefined>) => Array.from(new Set(
  refs.filter((ref): ref is string => typeof ref === "string" && ref.length > 0),
));

const resolveVisionSamplingStrategy = (aiInputRefs: string[]) =>
  aiInputRefs.length > 1 ? "route_plan_or_ability_owned_sampling" : "single_frame_fallback";

const buildMultiFrameEvidenceSetId = (
  envelope: WorkbenchAiRequestEnvelope,
  samplingStrategy: string,
  frameCount: number,
) => (
  frameCount > 1
    ? `${envelope.missionId}:${envelope.videoVisitId ?? envelope.stepId}:${samplingStrategy}`
    : null
);

const buildVisionImageCollectionInputPayload = (
  envelope: WorkbenchAiRequestEnvelope,
  inputPayload: WorkbenchAiPayloadDocument,
) => {
  const payload = payloadDocumentToObject(inputPayload);
  const preparedInputRef = payloadValueToString(payload.promptInputRef) ?? envelope.aiInputRefs[0] ?? null;
  const proof = resolveWorkbenchAiInputProofSummary(preparedInputRef) ?? null;
  const screenshotEvidenceId = proof?.sourceScreenshotEvidenceId ?? payloadValueToString(payload.screenshotEvidenceRef) ?? preparedInputRef;
  const aiInputRefs = buildUniqueAiInputRefs([
    preparedInputRef,
    ...envelope.aiInputRefs,
  ]);
  const inputMode = aiInputRefs.length > 1 ? "multi_image" : "single_frame_fallback";
  const samplingStrategy = resolveVisionSamplingStrategy(aiInputRefs);
  const frameCount = Math.max(aiInputRefs.length, 1);

  return {
    inputMode,
    multiFrameEvidenceSetId: buildMultiFrameEvidenceSetId(envelope, samplingStrategy, frameCount),
    contactSheetEvidenceId: inputMode === "multi_image" ? null : preparedInputRef,
    frameEvidenceIds: inputMode === "multi_image" ? aiInputRefs : [],
    screenshotEvidenceId,
    screenshotRegion: null,
    sourceUrl: payloadValueToString(payload.targetUrl) ?? "workbench://local-runtime/product-presence",
    samplingStrategy,
    sampledFrameCount: frameCount,
    validFrameCount: aiInputRefs.length,
    expectedFrameCount: frameCount,
    fallbackReason: inputMode === "single_frame_fallback" ? "lightweight_current_video_viewport" : null,
    missingFrames: [],
    summary: inputPayload.summary,
    tags: ["workbench", envelope.promptContractId],
  };
};

const buildSchemaValidationInputPayload = (
  envelope: WorkbenchAiRequestEnvelope,
  inputPayload: WorkbenchAiPayloadDocument,
) => ({
  candidate: {
    diagnostic: true,
    status: "success",
    sourceSummary: inputPayload.summary,
    promptContractId: envelope.promptContractId,
    expectedOutputSchema: envelope.outputSchemaRef,
    inputRefs: envelope.aiInputRefs,
  },
  sourceRef: envelope.aiInputRefs[0] ?? inputPayload.documentRef,
  validationContextRef: `${envelope.envelopeId}:schema-validation-only`,
});

const isVisionImageCollectionTask = (taskType: SupportedWorkbenchAiTaskType): boolean => (
  taskType === PAGE_PREPARATION_TASK_TYPE
  || taskType === PRODUCT_PRESENCE_TASK_TYPE
  || taskType === VISUAL_TARGET_CANDIDATE_TASK_TYPE
);

const buildWorkbenchAiInputPayload = (
  envelope: WorkbenchAiRequestEnvelope,
  inputPayload: WorkbenchAiPayloadDocument,
) => {
  if (envelope.taskType === "schema_validation_only") {
    return buildSchemaValidationInputPayload(envelope, inputPayload);
  }
  if (envelope.taskType === VISUAL_MISSION_ACTION_PLAN_TASK_TYPE) {
    return buildWorkbenchVisualMissionActionPlanInput(inputPayload);
  }
  if (isVisionImageCollectionTask(envelope.taskType)) {
    return buildVisionImageCollectionInputPayload(envelope, inputPayload);
  }

  return buildDefaultAiInputPayload(inputPayload);
};

const resolveWorkbenchAiInputModality = (taskType: SupportedWorkbenchAiTaskType) =>
  taskType === "schema_validation_only" ? "structured_record" as const : "image_collection" as const;

const resolveWorkbenchAiProviderPolicy = (taskType: SupportedWorkbenchAiTaskType) =>
  taskType === "schema_validation_only"
    ? { requireLocalOnly: true, allowPaidProvider: false, providerAllowlist: ["internal-schema-validator"], operatorApprovalRef: null }
    : { requireLocalOnly: true, allowPaidProvider: false, providerAllowlist: ["local-vision-ai"], operatorApprovalRef: null };

const resolveWorkbenchAiQualityPolicy = (taskType: SupportedWorkbenchAiTaskType) =>
  taskType === PAGE_PREPARATION_TASK_TYPE || taskType === PRODUCT_PRESENCE_TASK_TYPE || taskType === VISUAL_MISSION_ACTION_PLAN_TASK_TYPE || taskType === VISUAL_TARGET_CANDIDATE_TASK_TYPE
    ? { minimumConfidence: null, requireSchemaValidation: true }
    : { minimumConfidence: 0.6, requireSchemaValidation: true };

const resolveWorkbenchAiSafetyPolicy = (taskType: SupportedWorkbenchAiTaskType) =>
  taskType === PAGE_PREPARATION_TASK_TYPE || taskType === PRODUCT_PRESENCE_TASK_TYPE || taskType === VISUAL_MISSION_ACTION_PLAN_TASK_TYPE || taskType === VISUAL_TARGET_CANDIDATE_TASK_TYPE
    ? { reviewOnLowConfidence: false, reviewOnSchemaFailure: true, reviewOnPolicyViolation: true }
    : { reviewOnLowConfidence: true, reviewOnSchemaFailure: true, reviewOnPolicyViolation: true };

export const throwIfAborted = (signal: AbortSignal) => {
  if (signal.aborted) {
    throw new Error(typeof signal.reason === "string" ? signal.reason : "Transport aborted before AI completion.");
  }
};

export const buildWorkbenchAiAbilityRequest = (
  envelope: WorkbenchAiRequestEnvelope,
  inputPayload: WorkbenchAiPayloadDocument,
): WorkbenchAiExecuteInput => {
  const taskType = resolveAiTaskType(envelope);
  ensureWorkbenchAiInputProof(envelope, inputPayload);
  const visualMissionInput = taskType === VISUAL_MISSION_ACTION_PLAN_TASK_TYPE
    ? buildWorkbenchVisualMissionActionPlanInput(inputPayload)
    : null;

  return {
    abilityGroupId: "ai" as const,
    missionId: envelope.missionId,
    taskType,
    inputModality: resolveWorkbenchAiInputModality(taskType),
    inputRefs: buildWorkbenchAiInputRefs(envelope, inputPayload),
    promptContractId: envelope.promptContractId,
    expectedOutputSchema: envelope.outputSchemaRef,
    requestedBy: "orchestration" as const,
    transportedBy: "nerve-bus" as const,
    sessionId: envelope.sessionId,
    runId: envelope.runId,
    roundId: envelope.roundId,
    videoVisitId: envelope.videoVisitId,
    stepId: envelope.stepId,
    capabilityCallId: envelope.capabilityCallId,
    nerveBusEnvelopeId: envelope.envelopeId,
    bindingPackageId: envelope.bindingPackageId,
    bindingPackageVersion: envelope.bindingPackageVersion,
    selectedBindingId: envelope.mapId,
    bindingVersion: envelope.bindingVersion,
    bindingActivationRef: envelope.bindingActivationRef,
    bindingSnapshotRef: requireChainField(envelope.bindingSnapshotRef),
    promptCatalogVersion: requireChainField(envelope.promptContractVersion),
    userRequirementRef: visualMissionInput?.userRequirementRef ?? null,
    userRequirementText: visualMissionInput?.userRequirementText ?? inputPayload.summary,
    platformId: visualMissionInput?.platformContext.platformId ?? payloadValueToString(payloadDocumentToObject(inputPayload).requestedPlatformId) ?? "unknown-platform",
    platformProfileRef: visualMissionInput?.platformContext.targetProfileRef ?? null,
    originalScreenshotRef: visualMissionInput?.originalScreenshotRef ?? envelope.aiInputRefs[0] ?? "missing-original-screenshot-ref",
    coordinateGridScreenshotRef: visualMissionInput?.coordinateGridScreenshotRef ?? envelope.aiInputRefs[0] ?? "missing-grid-screenshot-ref",
    gridSpecRef: visualMissionInput?.gridSpecRef ?? "missing-grid-spec-ref",
    visualMissionInputRef: payloadValueToString(payloadDocumentToObject(inputPayload).visualMissionInputRef),
    systemManualRef: visualMissionInput?.systemManualRef ?? "missing-system-manual-ref",
    muscleMemoryCatalogVersion: "workbench-muscle-memory-catalog",
    continuityBundleRef: visualMissionInput?.roundMissionPacketRef ?? null,
    qualityPolicy: resolveWorkbenchAiQualityPolicy(taskType),
    providerPolicy: resolveWorkbenchAiProviderPolicy(taskType),
    costPolicy: { maxEstimatedCost: 0 },
    dataPolicy: { allowExternalTransmission: false, redactSensitiveData: true },
    safetyPolicy: resolveWorkbenchAiSafetyPolicy(taskType),
    input: visualMissionInput ?? buildWorkbenchAiInputPayload({ ...envelope, taskType }, inputPayload),
  };
};
