import type { WorkbenchLocalModelRole } from "./workbench-local-ai-role-types.js";

const roleState = new Map<WorkbenchLocalModelRole, boolean>([
  ["vision", true],
  ["ocr", true],
  ["commentUnderstanding", true],
  ["productSignal", true],
]);

export const getWorkbenchLocalAiRoleControls = async () => ({
  roles: Array.from(roleState.entries()).map(([role, enabled]) => ({ role, enabled })),
});

export const setWorkbenchLocalAiRoleStartupState = (input: {
  role: WorkbenchLocalModelRole;
  enabled: boolean;
}) => {
  roleState.set(input.role, input.enabled);
};