import type { AiAbilityResult } from "../../capabilities/ai/index.js";
import type { EvidenceRef } from "../../types/evidence.js";
import type { WorkbenchRuntime } from "./workbench-contract.js";

type WorkbenchAiRequestEnvelope = import("../../capabilities/nerve-bus/contract.js").AiRequestDispatchInput["envelope"];

const isRecord = (value: unknown): value is Record<string, unknown> => typeof value === "object" && value !== null;

const readString = (value: unknown): string | null => typeof value === "string" && value.length > 0 ? value : null;

const buildEvidenceRefs = (aiResult: AiAbilityResult): EvidenceRef[] => aiResult.runtimeProof.inputRefs.map((id) => ({
  id,
  kind: "video-screenshot",
  summary: "AI visual mission evidence input.",
}));

const withAuthoritativeRef = (aiResult: AiAbilityResult, authoritativeAiResultRef: string): AiAbilityResult => ({
  ...aiResult,
  runtimeProof: {
    ...aiResult.runtimeProof,
    outputRefs: [authoritativeAiResultRef],
  },
});

async function persistWorkbenchAiResult(input: {
  runtime: WorkbenchRuntime;
  envelope: WorkbenchAiRequestEnvelope;
  aiResult: AiAbilityResult;
}) {
  const persisted = await input.runtime.forensicsPersistenceAbilityGroup.writeAiResultRecord({
    abilityGroupId: "forensics-persistence",
    childCapabilityId: "write-ai-result-record",
    recordType: "ai_result_record",
    requestedBy: "orchestration",
    sourceAbilityGroupId: "ai",
    sourceChildCapabilityId: input.aiResult.childCapabilityId,
    missionId: input.envelope.missionId,
    runId: input.envelope.runId,
    sessionId: input.envelope.sessionId,
    roundId: input.envelope.roundId ?? `${input.envelope.sessionId}:round:unknown`,
    videoVisitId: input.envelope.videoVisitId ?? null,
    stepId: input.envelope.stepId,
    bindingPackageId: input.envelope.bindingPackageId ?? null,
    bindingPackageVersion: input.envelope.bindingPackageVersion ?? null,
    selectedBindingId: input.envelope.mapId ?? null,
    bindingVersion: input.envelope.bindingVersion ?? null,
    bindingSnapshotRef: input.envelope.bindingSnapshotRef ?? null,
    capabilityCallId: input.envelope.capabilityCallId,
    inputRefs: input.aiResult.runtimeProof.inputRefs,
    outputRefs: input.aiResult.runtimeProof.outputRefs,
    sourceRecordRefs: [],
    parentRefs: [],
    artifactRefs: [],
    promptContractId: input.aiResult.promptContractId,
    promptContractVersion: input.aiResult.promptContractVersion,
    promptCatalogVersion: input.aiResult.promptCatalogVersion,
    persistencePolicy: { mode: "append", allowPartialRefs: true },
    dataQualityFlags: input.aiResult.runtimeProof.dataQualityFlags,
    payload: {
      aiResult: {
        status: input.aiResult.status,
        abilityGroupId: input.aiResult.abilityGroupId,
        childCapabilityId: input.aiResult.childCapabilityId,
        taskType: input.aiResult.taskType,
        modelProvider: input.aiResult.modelProvider,
        modelName: input.aiResult.modelName,
        modelRole: input.aiResult.modelRole,
        runtime: input.aiResult.runtime,
        implementationStatus: input.aiResult.implementationStatus,
        output: input.aiResult.output,
        rawOutputRef: input.aiResult.rawOutputRef,
        schemaValidationStatus: input.aiResult.schemaValidationStatus,
        confidence: input.aiResult.confidence,
        failureReason: input.aiResult.failureReason,
        durationMs: input.aiResult.durationMs,
        costEstimate: null,
        evidenceRefs: buildEvidenceRefs(input.aiResult),
        debugLogRef: null,
        runtimeProof: input.aiResult.runtimeProof,
        promptVersion: input.aiResult.promptVersion,
        schemaVersion: input.aiResult.schemaVersion,
        createdAt: input.aiResult.createdAt,
      },
    },
  });

  const output = isRecord(persisted.output) ? persisted.output : null;
  const authoritativeAiResultRef = readString(output?.recordRef);

  if (!authoritativeAiResultRef) {
    throw new Error("AI result persistence succeeded without recordRef.");
  }

  return {
    authoritativeAiResultRef,
    aiResult: withAuthoritativeRef(input.aiResult, authoritativeAiResultRef),
  };
}

export { persistWorkbenchAiResult };