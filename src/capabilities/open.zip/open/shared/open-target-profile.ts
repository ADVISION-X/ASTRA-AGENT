export const OPEN_ABILITY_GROUP_ID = "open" as const;

export const OPEN_CHILD_CAPABILITY_IDS = [
  "open-tiktok",
  "open-facebook",
  "open-local-workbench",
  "open-local-program",
] as const;

export const OPEN_PLATFORM_IDS = [
  "tiktok-web",
  "facebook-web",
  "local-workbench",
  "macos-local",
] as const;

export const TIKTOK_PLATFORM_ID = "tiktok-web" as const;
export const DEFAULT_TIKTOK_URL = "https://www.tiktok.com/foryou";

export const OPEN_TARGET_KINDS = [
  "platform-feed",
  "local-workbench",
  "local-program",
] as const;

export const OPEN_ALLOWED_CALLERS = [
  "orchestration",
  "nerve-bus",
] as const;

export const OPEN_POST_OPEN_CLASSIFICATIONS = [
  "platform_feed",
  "local_workbench",
  "local_program",
  "wrong_domain",
  "login_wall",
  "security_wall",
  "captcha_wall",
  "permission_wall",
  "blank_page",
  "unexpected_redirect",
  "unknown",
] as const;
