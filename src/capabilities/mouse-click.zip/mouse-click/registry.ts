import type { MouseClickChildCapability, MouseClickChildCapabilityId } from "./contract.js";
import { createLeftClickBrowserViewportOnceCapability } from "./children/left-click-browser-viewport-once/implementation.js";
import { createDoubleLeftClickBrowserViewportCapability } from "./children/double-left-click-browser-viewport/implementation.js";
import { createRightClickBrowserViewportOnceCapability } from "./children/right-click-browser-viewport-once/implementation.js";
import { createClickBrowserCoordinateCapability } from "./children/click-browser-coordinate/implementation.js";
import { createClickDesktopCoordinateCapability } from "./children/click-desktop-coordinate/implementation.js";

const CHILDREN = [
  createLeftClickBrowserViewportOnceCapability(),
  createDoubleLeftClickBrowserViewportCapability(),
  createRightClickBrowserViewportOnceCapability(),
  createClickBrowserCoordinateCapability(),
  createClickDesktopCoordinateCapability(),
] as const;

export function createMouseClickCapabilityRegistry(): Map<MouseClickChildCapabilityId, MouseClickChildCapability> {
  return new Map(CHILDREN.map((child) => [child.childCapabilityId, child]));
}

export function listMouseClickChildren(): MouseClickChildCapabilityId[] {
  return CHILDREN.map((child) => child.childCapabilityId);
}