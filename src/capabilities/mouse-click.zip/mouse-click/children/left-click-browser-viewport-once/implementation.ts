import type { MouseClickChildCapability } from "../../contract.js";
import { MOUSE_CLICK_ABILITY_GROUP_ID } from "../../contract.js";
import { executeMouseClick } from "../../runtime/mouse-click-executor.js";
import { LeftClickBrowserViewportOnceInputSchema, LeftClickBrowserViewportOnceResultSchema } from "./schema.js";

export function createLeftClickBrowserViewportOnceCapability(): MouseClickChildCapability {
  return {
    abilityGroupId: MOUSE_CLICK_ABILITY_GROUP_ID,
    childCapabilityId: "left-click-browser-viewport-once",
    async execute(input, context) {
      const parsedInput = LeftClickBrowserViewportOnceInputSchema.parse({ ...input, button: "left", clickCount: 1 });
      return LeftClickBrowserViewportOnceResultSchema.parse(await executeMouseClick({
        request: parsedInput,
        expectedCoordinateSpace: "browserViewport",
        context,
      }));
    },
  };
}
