import type { z } from "zod";

import { LeftClickBrowserViewportOnceInputSchema, LeftClickBrowserViewportOnceResultSchema } from "../../schema.js";

export type LeftClickBrowserViewportOnceInput = z.output<typeof LeftClickBrowserViewportOnceInputSchema>;
export type LeftClickBrowserViewportOnceResult = z.output<typeof LeftClickBrowserViewportOnceResultSchema>;
