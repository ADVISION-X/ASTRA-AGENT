export {
  LeftClickBrowserViewportOnceInputSchema,
  LeftClickBrowserViewportOnceResultSchema,
} from "../../schema.js";
