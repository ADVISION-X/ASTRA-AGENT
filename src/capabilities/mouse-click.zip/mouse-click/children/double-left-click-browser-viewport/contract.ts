import type { z } from "zod";

import { DoubleLeftClickBrowserViewportInputSchema, DoubleLeftClickBrowserViewportResultSchema } from "../../schema.js";

export type DoubleLeftClickBrowserViewportInput = z.output<typeof DoubleLeftClickBrowserViewportInputSchema>;
export type DoubleLeftClickBrowserViewportResult = z.output<typeof DoubleLeftClickBrowserViewportResultSchema>;
