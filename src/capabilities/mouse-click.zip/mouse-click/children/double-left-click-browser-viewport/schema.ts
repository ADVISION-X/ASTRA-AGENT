export {
  DoubleLeftClickBrowserViewportInputSchema,
  DoubleLeftClickBrowserViewportResultSchema,
} from "../../schema.js";
