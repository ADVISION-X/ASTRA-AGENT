import type { MouseClickChildCapability } from "../../contract.js";
import { MOUSE_CLICK_ABILITY_GROUP_ID } from "../../contract.js";
import { executeMouseClick } from "../../runtime/mouse-click-executor.js";
import { DoubleLeftClickBrowserViewportInputSchema, DoubleLeftClickBrowserViewportResultSchema } from "./schema.js";

export function createDoubleLeftClickBrowserViewportCapability(): MouseClickChildCapability {
  return {
    abilityGroupId: MOUSE_CLICK_ABILITY_GROUP_ID,
    childCapabilityId: "double-left-click-browser-viewport",
    async execute(input, context) {
      const parsedInput = DoubleLeftClickBrowserViewportInputSchema.parse({ ...input, button: "left", clickCount: 2 });
      return DoubleLeftClickBrowserViewportResultSchema.parse(await executeMouseClick({
        request: parsedInput,
        expectedCoordinateSpace: "browserViewport",
        context,
      }));
    },
  };
}
