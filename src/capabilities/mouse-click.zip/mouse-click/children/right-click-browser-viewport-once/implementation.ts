import type { MouseClickChildCapability } from "../../contract.js";
import { MOUSE_CLICK_ABILITY_GROUP_ID } from "../../contract.js";
import { executeMouseClick } from "../../runtime/mouse-click-executor.js";
import { RightClickBrowserViewportOnceInputSchema, RightClickBrowserViewportOnceResultSchema } from "./schema.js";

export function createRightClickBrowserViewportOnceCapability(): MouseClickChildCapability {
  return {
    abilityGroupId: MOUSE_CLICK_ABILITY_GROUP_ID,
    childCapabilityId: "right-click-browser-viewport-once",
    async execute(input, context) {
      const parsedInput = RightClickBrowserViewportOnceInputSchema.parse({ ...input, button: "right", clickCount: 1 });
      return RightClickBrowserViewportOnceResultSchema.parse(await executeMouseClick({
        request: parsedInput,
        expectedCoordinateSpace: "browserViewport",
        context,
      }));
    },
  };
}
