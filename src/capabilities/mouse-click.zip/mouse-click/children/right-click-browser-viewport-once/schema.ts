export {
  RightClickBrowserViewportOnceInputSchema,
  RightClickBrowserViewportOnceResultSchema,
} from "../../schema.js";
