import type { z } from "zod";

import { RightClickBrowserViewportOnceInputSchema, RightClickBrowserViewportOnceResultSchema } from "../../schema.js";

export type RightClickBrowserViewportOnceInput = z.output<typeof RightClickBrowserViewportOnceInputSchema>;
export type RightClickBrowserViewportOnceResult = z.output<typeof RightClickBrowserViewportOnceResultSchema>;
