import { LocalAiGateway } from "../../../lib/local-ai/local-ai-gateway.js";
import { getPromptContract } from "../../../lib/local-ai/prompt-registry.js";
import type { LocalAiHealth, LocalAiTaskRequest, LocalAiTaskResult, LocalAiTaskType } from "../../../types/local-ai.js";
import type { AiAbilityInput, AiAbilityResult, AiExecutionOptions, AiPromptContract, AiRuntimeBridge, AiRuntimeHealth, AiTaskType } from "../contract.js";
import { loadAiModelRoster } from "../model-roster.js";
import { routeAiTaskToChild } from "../task-router.js";
import { validateAiAbilityResult, validateAiRuntimeHealth } from "../schema-validation.js";

const LEGACY_TASK_BY_AI: Partial<Record<AiTaskType, LocalAiTaskType>> = {
  product_presence_judgment: "vision.productPresence",
  visual_observation: "vision.productPresence",
  visual_target_candidate_analysis: "vision.productPresence",
  ocr_cleanup: "comments.ocr_cleanup",
  comment_signal_summary: "comments.intent_analysis",
  product_signal_summary: "product.signal_summary",
};

const PRIMARY_AI_TASK_BY_LEGACY: Record<LocalAiTaskType, AiTaskType> = {
  "vision.productPresence": "product_presence_judgment",
  "comments.ocr_cleanup": "ocr_cleanup",
  "comments.intent_analysis": "comment_signal_summary",
  "product.signal_summary": "product_signal_summary",
};

function toAiPromptContract(taskType: AiTaskType): AiPromptContract {
  const legacyTaskType = LEGACY_TASK_BY_AI[taskType];
  if (legacyTaskType) {
    const contract = getPromptContract(legacyTaskType);
    return {
      taskType,
      modelRole: contract.modelRole === "commentUnderstanding" ? "commentUnderstanding" : contract.modelRole,
      promptId: contract.promptId,
      promptVersion: contract.promptVersion,
      schemaVersion: contract.schemaVersion,
      purpose: contract.purpose,
      forbiddenOutputs: [...contract.forbiddenOutputs],
    };
  }

  if (taskType === "evidence_packet_analysis") {
    return { taskType, modelRole: "future", promptId: "ai.evidence_packet_analysis.disabled", promptVersion: "evidence_packet_analysis.v1", schemaVersion: "ai.evidence_packet_analysis.v1", purpose: "Reserved paid analysis path for evidence-packet cognition.", forbiddenOutputs: ["implicit_paid_fallback"] };
  }

  return { taskType, modelRole: "schemaValidator", promptId: "ai.schema_validation_only.internal", promptVersion: "schema_validation_only.v1", schemaVersion: "ai.schema_validation_only.v1", purpose: "Validate a governed AI payload against the declared schema boundary.", forbiddenOutputs: ["schema_bypass"] };
}

function toAiRuntimeHealth(health: LocalAiHealth): AiRuntimeHealth {
  return validateAiRuntimeHealth({
    overallStatus: health.overallStatus,
    implementationStatus: health.implementationStatus,
    dependencies: {
      gateway: health.ollamaStatus,
      vision: health.visionModelStatus,
      text: health.textModelStatus,
      ocr: health.ocrStatus,
    },
    configuredModels: health.configuredModels,
    availableModels: health.availableModels,
    lastCheckedAt: health.lastCheckedAt,
    failureReason: health.failureReason,
    lastTaskType: health.lastTaskType ? PRIMARY_AI_TASK_BY_LEGACY[health.lastTaskType] : null,
    lastFailureReason: health.lastFailureReason,
    lastInvocationStatus: health.lastInvocationStatus,
  });
}

function toLocalAiTaskRequest(input: AiAbilityInput): LocalAiTaskRequest {
  const legacyTaskType = LEGACY_TASK_BY_AI[input.taskType];
  if (!legacyTaskType) {
    throw new Error(`Local AI runtime adapter cannot execute ${input.taskType}.`);
  }

  const promptContract = toAiPromptContract(input.taskType);
  const id = `${input.sessionId}:${input.taskType}:${input.roundId ?? "no-round"}`;
  switch (legacyTaskType) {
    case "vision.productPresence":
      return { id, taskType: legacyTaskType, modelRole: "vision", promptVersion: promptContract.promptVersion, schemaVersion: promptContract.schemaVersion, evidenceRefs: input.inputRefs, input: input.input as LocalAiTaskRequest["input"] } as LocalAiTaskRequest;
    case "comments.ocr_cleanup":
      return { id, taskType: legacyTaskType, modelRole: "ocr", promptVersion: promptContract.promptVersion, schemaVersion: promptContract.schemaVersion, evidenceRefs: input.inputRefs, input: input.input as LocalAiTaskRequest["input"] } as LocalAiTaskRequest;
    case "comments.intent_analysis":
      return { id, taskType: legacyTaskType, modelRole: "commentUnderstanding", promptVersion: promptContract.promptVersion, schemaVersion: promptContract.schemaVersion, evidenceRefs: input.inputRefs, input: input.input as LocalAiTaskRequest["input"] } as LocalAiTaskRequest;
    case "product.signal_summary":
      return { id, taskType: legacyTaskType, modelRole: "productSignal", promptVersion: promptContract.promptVersion, schemaVersion: promptContract.schemaVersion, evidenceRefs: input.inputRefs, input: input.input as LocalAiTaskRequest["input"] } as LocalAiTaskRequest;
  }
}

function toPublicOutput(taskType: AiTaskType, result: LocalAiTaskResult): unknown {
  if (result.taskType !== "vision.productPresence") {
    return result.result;
  }

  const { taskType: _taskType, promptId: _promptId, promptVersion: _promptVersion, schemaVersion: _schemaVersion, ...output } = result.result;
  return output;
}

function buildRuntimeProof(input: AiAbilityInput, result: LocalAiTaskResult, status: AiAbilityResult["status"], startedAt: string, endedAt: string): AiAbilityResult["runtimeProof"] {
  const durationMs = Math.max(0, new Date(endedAt).getTime() - new Date(startedAt).getTime());
  return {
    abilityGroupId: "ai",
    childCapabilityId: routeAiTaskToChild(input.taskType),
    sessionId: input.sessionId,
    roundId: input.roundId,
    videoVisitId: input.videoVisitId,
    startedAt,
    endedAt,
    durationMs,
    status,
    reason: result.id,
    failureReason: status === "success" ? null : result.implementationStatus,
    reviewRequiredReason: status === "review_required" ? result.implementationStatus : null,
    inputRefs: input.inputRefs.map((ref) => ref.id),
    outputRefs: [result.id],
    evidenceRefs: input.inputRefs.map((ref) => ref.id),
    actionLogRefs: [],
    nextAbilityGroup: null,
    nextChildAbility: null,
    dataQualityFlags: [],
  };
}

function toAiAbilityResult(input: AiAbilityInput, result: LocalAiTaskResult, startedAt: string, endedAt: string): AiAbilityResult {
  const promptContract = toAiPromptContract(input.taskType);
  const durationMs = Math.max(0, new Date(endedAt).getTime() - new Date(startedAt).getTime());
  return validateAiAbilityResult({
    status: result.implementationStatus === "local_ai_unavailable" ? "failed" : "success",
    abilityGroupId: "ai",
    childCapabilityId: routeAiTaskToChild(input.taskType),
    taskType: input.taskType,
    modelProvider: "local",
    modelName: result.model,
    modelRole: promptContract.modelRole,
    runtime: result.runtime,
    implementationStatus: result.implementationStatus,
    output: toPublicOutput(input.taskType, result),
    rawOutputRef: null,
    schemaValidationStatus: "valid",
    confidence: result.confidence,
    failureReason: result.implementationStatus === "local_ai_unavailable" ? result.implementationStatus : null,
    durationMs,
    costEstimate: null,
    evidenceRefs: input.inputRefs,
    debugLogRef: null,
    runtimeProof: buildRuntimeProof(input, result, result.implementationStatus === "local_ai_unavailable" ? "failed" : "success", startedAt, endedAt),
    promptVersion: result.promptVersion,
    schemaVersion: result.schemaVersion,
    createdAt: result.createdAt,
  });
}

function buildSchemaValidationOnlyResult(input: AiAbilityInput): AiAbilityResult {
  const startedAt = new Date().toISOString();
  const endedAt = startedAt;
  return validateAiAbilityResult({
    status: "success",
    abilityGroupId: "ai",
    childCapabilityId: routeAiTaskToChild(input.taskType),
    taskType: input.taskType,
    modelProvider: "internal",
    modelName: "schema-validator",
    modelRole: "schemaValidator",
    runtime: "internal",
    implementationStatus: "validated",
    output: { valid: true, issues: [] },
    rawOutputRef: null,
    schemaValidationStatus: "valid",
    confidence: 1,
    failureReason: null,
    durationMs: 0,
    costEstimate: null,
    evidenceRefs: input.inputRefs,
    debugLogRef: null,
    runtimeProof: {
      abilityGroupId: "ai",
      childCapabilityId: routeAiTaskToChild(input.taskType),
      sessionId: input.sessionId,
      roundId: input.roundId,
      videoVisitId: input.videoVisitId,
      startedAt,
      endedAt,
      durationMs: 0,
      status: "success",
      reason: "schema_validation_only",
      failureReason: null,
      reviewRequiredReason: null,
      inputRefs: input.inputRefs.map((ref) => ref.id),
      outputRefs: [],
      evidenceRefs: input.inputRefs.map((ref) => ref.id),
      actionLogRefs: [],
      nextAbilityGroup: null,
      nextChildAbility: null,
      dataQualityFlags: [],
    },
    promptVersion: "schema_validation_only.v1",
    schemaVersion: "ai.schema_validation_only.v1",
    createdAt: startedAt,
  });
}

export function createDefaultAiRuntimeBridge(): AiRuntimeBridge {
  const gateway = new LocalAiGateway();

  return {
    async execute(input, options) {
      if (input.taskType === "schema_validation_only") {
        return buildSchemaValidationOnlyResult(input);
      }

      const startedAt = new Date().toISOString();
      const legacyRequest = toLocalAiTaskRequest(input);
      const result = await gateway.execute(legacyRequest, options?.debugHook ? { debugHook: options.debugHook } : {});
      return toAiAbilityResult(input, result, startedAt, new Date().toISOString());
    },
    async getHealth() {
      const report = await gateway.getHealth();
      return { ok: report.ok, detail: report.detail, health: toAiRuntimeHealth(report.health) };
    },
    async getRuntimeHealth() {
      return toAiRuntimeHealth(await gateway.getRuntimeHealth());
    },
    resolvePromptContract(taskType) {
      return toAiPromptContract(taskType);
    },
    getModelRoster() {
      return loadAiModelRoster();
    },
  };
}