import type { AiAbilityInput } from "../contract.js";

export const AI_ALLOWED_CALLERS = ["orchestration", "nerve-bus"] as const;

export const AI_FORBIDDEN_RESPONSIBILITIES = [
  "execute_platform_actions",
  "bypass_nerve_bus",
  "import_other_group_children",
  "implicit_paid_fallback",
] as const;

export function assertAiReadOnlyBoundary(reason: string): void {
  const normalizedReason = reason.toLowerCase();
  const actionKeywords = ["click", "scroll", "open_comments", "like_or_save", "not_interested", "open_target_page"];
  if (actionKeywords.some((keyword) => normalizedReason.includes(keyword))) {
    throw new Error("AI Ability Group cannot execute platform actions directly.");
  }
}

export function hasExplicitPaidExecutionPolicy(input: Pick<AiAbilityInput, "providerPolicy" | "dataPolicy" | "costPolicy">): boolean {
  return input.providerPolicy.allowPaidProvider
    && input.providerPolicy.providerAllowlist.length > 0
    && input.providerPolicy.operatorApprovalRef !== null
    && input.dataPolicy.allowExternalTransmission
    && input.costPolicy.maxEstimatedCost !== null;
}

export function isPaidAiPolicyEnabled(input: Pick<AiAbilityInput, "providerPolicy" | "dataPolicy" | "costPolicy">): boolean {
  return hasExplicitPaidExecutionPolicy(input) && !input.providerPolicy.requireLocalOnly;
}