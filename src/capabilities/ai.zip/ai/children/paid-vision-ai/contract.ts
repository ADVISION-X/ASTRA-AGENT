import type { z } from "zod";

import { PaidVisionAiInputSchema, PaidVisionAiResultSchema } from "../../schema.js";

export type PaidVisionAiInput = z.output<typeof PaidVisionAiInputSchema>;
export type PaidVisionAiResult = z.output<typeof PaidVisionAiResultSchema>;
