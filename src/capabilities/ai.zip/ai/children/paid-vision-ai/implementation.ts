import type { AiChildCapability, AiChildContract } from "../../contract.js";
import { AI_ABILITY_GROUP_ID } from "../../contract.js";
import { executeAiChild } from "../../runtime/ai-executor.js";
import { AiChildReadinessSchema } from "../../schema.js";
import { PaidVisionAiInputSchema, PaidVisionAiResultSchema } from "./schema.js";

export function createPaidVisionAiCapability(): AiChildCapability {
  const contract: AiChildContract = {
    abilityGroupId: AI_ABILITY_GROUP_ID,
    childCapabilityId: "paid-vision-ai",
    providerKind: "paid",
    supportedTaskTypes: ["visual_observation", "visual_target_candidate_analysis"] as const,
    modelRole: "vision",
    runtimeOwner: "ai-executor" as const,
    implementationStatus: "disabled_by_policy",
    purpose: "Reserved paid vision path that remains governed-disabled.",
  };

  return {
    contract,
    implementation: {
      async execute(input, context) {
        return PaidVisionAiResultSchema.parse(await executeAiChild({
          request: PaidVisionAiInputSchema.parse(input),
          childContract: contract,
          context,
        }));
      },
      async checkReadiness() {
        return AiChildReadinessSchema.parse({
          abilityGroupId: "ai",
          childCapabilityId: "paid-vision-ai",
          providerKind: "paid",
          status: "disabled_by_policy",
          supportedTaskTypes: [...contract.supportedTaskTypes],
          detail: "paid vision provider is declared but disabled by policy.",
          enabledByPolicy: false,
        });
      },
    },
  };
}
