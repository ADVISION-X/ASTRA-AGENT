import type { z } from "zod";

import { LocalVisionAiInputSchema, LocalVisionAiResultSchema } from "../../schema.js";

export type LocalVisionAiInput = z.output<typeof LocalVisionAiInputSchema>;
export type LocalVisionAiResult = z.output<typeof LocalVisionAiResultSchema>;
