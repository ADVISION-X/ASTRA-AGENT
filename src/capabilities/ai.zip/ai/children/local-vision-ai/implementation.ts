import type { AiChildCapability, AiChildContract } from "../../contract.js";
import { AI_ABILITY_GROUP_ID } from "../../contract.js";
import { executeAiChild } from "../../runtime/ai-executor.js";
import { AiChildReadinessSchema } from "../../schema.js";
import { LocalVisionAiInputSchema, LocalVisionAiResultSchema } from "./schema.js";

export function createLocalVisionAiCapability(): AiChildCapability {
  const contract: AiChildContract = {
    abilityGroupId: AI_ABILITY_GROUP_ID,
    childCapabilityId: "local-vision-ai",
    providerKind: "local",
    supportedTaskTypes: ["product_presence_judgment", "visual_observation", "visual_target_candidate_analysis"] as const,
    modelRole: "vision",
    runtimeOwner: "ai-executor" as const,
    implementationStatus: "local_runtime",
    purpose: "Run local governed vision cognition through ai-executor.",
  };

  return {
    contract,
    implementation: {
      async execute(input, context) {
        return LocalVisionAiResultSchema.parse(await executeAiChild({
          request: LocalVisionAiInputSchema.parse(input),
          childContract: contract,
          context,
        }));
      },
      async checkReadiness(context) {
        const health = await context.runtime.getRuntimeHealth();
        return AiChildReadinessSchema.parse({
          abilityGroupId: "ai",
          childCapabilityId: "local-vision-ai",
          providerKind: "local",
          status: health.dependencies.vision === "ready" ? "ready" : "unavailable",
          supportedTaskTypes: [...contract.supportedTaskTypes],
          detail: `vision=${health.dependencies.vision}`,
          enabledByPolicy: true,
        });
      },
    },
  };
}
