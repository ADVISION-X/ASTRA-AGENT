import type { z } from "zod";

import { LocalOcrAiInputSchema, LocalOcrAiResultSchema } from "../../schema.js";

export type LocalOcrAiInput = z.output<typeof LocalOcrAiInputSchema>;
export type LocalOcrAiResult = z.output<typeof LocalOcrAiResultSchema>;
