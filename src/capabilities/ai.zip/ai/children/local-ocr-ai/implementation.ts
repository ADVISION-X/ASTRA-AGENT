import type { AiChildCapability, AiChildContract } from "../../contract.js";
import { AI_ABILITY_GROUP_ID } from "../../contract.js";
import { executeAiChild } from "../../runtime/ai-executor.js";
import { AiChildReadinessSchema } from "../../schema.js";
import { LocalOcrAiInputSchema, LocalOcrAiResultSchema } from "./schema.js";

export function createLocalOcrAiCapability(): AiChildCapability {
  const contract: AiChildContract = {
    abilityGroupId: AI_ABILITY_GROUP_ID,
    childCapabilityId: "local-ocr-ai",
    providerKind: "local",
    supportedTaskTypes: ["ocr_cleanup"] as const,
    modelRole: "ocr",
    runtimeOwner: "ai-executor" as const,
    implementationStatus: "local_runtime",
    purpose: "Run local governed OCR cognition through ai-executor.",
  };

  return {
    contract,
    implementation: {
      async execute(input, context) {
        return LocalOcrAiResultSchema.parse(await executeAiChild({
          request: LocalOcrAiInputSchema.parse(input),
          childContract: contract,
          context,
        }));
      },
      async checkReadiness(context) {
        const health = await context.runtime.getRuntimeHealth();
        return AiChildReadinessSchema.parse({
          abilityGroupId: "ai",
          childCapabilityId: "local-ocr-ai",
          providerKind: "local",
          status: health.dependencies.ocr === "ready" ? "ready" : "unavailable",
          supportedTaskTypes: [...contract.supportedTaskTypes],
          detail: `ocr=${health.dependencies.ocr}`,
          enabledByPolicy: true,
        });
      },
    },
  };
}
