export { LocalOcrAiInputSchema, LocalOcrAiResultSchema } from "../../schema.js";
