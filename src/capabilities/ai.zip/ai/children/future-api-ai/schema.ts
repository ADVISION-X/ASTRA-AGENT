export const FutureApiAiSchemaPlaceholder = "future-api-ai";
