import type { AiChildCapability, AiChildContract } from "../../contract.js";
import { AI_ABILITY_GROUP_ID } from "../../contract.js";
import { dispatchAiFailure } from "../../runtime/ai-dispatch-failure.js";
import { AiChildReadinessSchema } from "../../schema.js";

export function createFutureApiAiCapability(): AiChildCapability {
  const contract: AiChildContract = {
    abilityGroupId: AI_ABILITY_GROUP_ID,
    childCapabilityId: "future-api-ai",
    providerKind: "future",
    supportedTaskTypes: [] as const,
    modelRole: "future",
    runtimeOwner: "ai-executor" as const,
    implementationStatus: "disabled_by_policy",
    purpose: "Future API slot remains disabled until law unfreezes.",
  };

  return {
    contract,
    implementation: {
      async execute(_input, context) {
        return dispatchAiFailure({
          rawInput: {
            abilityGroupId: "ai",
            taskType: "evidence_packet_analysis",
            inputModality: "structured_record",
            inputRefs: [],
            promptContractId: "ai.evidence_packet_analysis.disabled",
            expectedOutputSchema: "ai.evidence_packet_analysis.v1",
            requestedBy: "orchestration",
            transportedBy: "nerve-bus",
            sessionId: "future-disabled",
            roundId: null,
            videoVisitId: null,
            qualityPolicy: { minimumConfidence: 0.6, requireSchemaValidation: true },
            providerPolicy: { requireLocalOnly: false, allowPaidProvider: false, providerAllowlist: ["future-api-ai"], operatorApprovalRef: null },
            costPolicy: { maxEstimatedCost: 0 },
            dataPolicy: { allowExternalTransmission: false, redactSensitiveData: true },
            safetyPolicy: { reviewOnLowConfidence: true, reviewOnSchemaFailure: true, reviewOnPolicyViolation: true },
            input: { packetSummary: "future-disabled", evidenceIds: ["future-disabled"], notes: [] },
          },
          context,
          childCapabilityId: "future-api-ai",
          taskType: "evidence_packet_analysis",
          failureReason: "provider_disabled",
          statusMessage: "future-api-ai is governed-disabled.",
        });
      },
      async checkReadiness() {
        return AiChildReadinessSchema.parse({
          abilityGroupId: "ai",
          childCapabilityId: "future-api-ai",
          providerKind: "future",
          status: "disabled_by_policy",
          supportedTaskTypes: [],
          detail: "future api provider is disabled pending law unfreeze.",
          enabledByPolicy: false,
        });
      },
    },
  };
}
