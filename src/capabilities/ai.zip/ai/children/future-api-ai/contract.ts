export type FutureApiAiInput = never;
export type FutureApiAiResult = never;
