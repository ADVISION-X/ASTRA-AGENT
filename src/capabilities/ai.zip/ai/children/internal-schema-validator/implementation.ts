import type { AiChildCapability, AiChildContract } from "../../contract.js";
import { AI_ABILITY_GROUP_ID } from "../../contract.js";
import { executeAiChild } from "../../runtime/ai-executor.js";
import { AiChildReadinessSchema } from "../../schema.js";
import { InternalSchemaValidatorInputSchema, InternalSchemaValidatorResultSchema } from "./schema.js";

export function createInternalSchemaValidatorCapability(): AiChildCapability {
  const contract: AiChildContract = {
    abilityGroupId: AI_ABILITY_GROUP_ID,
    childCapabilityId: "internal-schema-validator",
    providerKind: "internal",
    supportedTaskTypes: ["schema_validation_only"] as const,
    modelRole: "schemaValidator",
    runtimeOwner: "ai-executor" as const,
    implementationStatus: "internal_validator",
    purpose: "Run internal schema validation only through ai-executor.",
  };

  return {
    contract,
    implementation: {
      async execute(input, context) {
        return InternalSchemaValidatorResultSchema.parse(await executeAiChild({
          request: InternalSchemaValidatorInputSchema.parse(input),
          childContract: contract,
          context,
        }));
      },
      async checkReadiness() {
        return AiChildReadinessSchema.parse({
          abilityGroupId: "ai",
          childCapabilityId: "internal-schema-validator",
          providerKind: "internal",
          status: "ready",
          supportedTaskTypes: [...contract.supportedTaskTypes],
          detail: "internal schema validation is ready and does not enter LocalAiGateway.",
          enabledByPolicy: true,
        });
      },
    },
  };
}
