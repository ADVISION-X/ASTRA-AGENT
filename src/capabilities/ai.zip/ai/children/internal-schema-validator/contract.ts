import type { z } from "zod";

import { InternalSchemaValidatorInputSchema, InternalSchemaValidatorResultSchema } from "../../schema.js";

export type InternalSchemaValidatorInput = z.output<typeof InternalSchemaValidatorInputSchema>;
export type InternalSchemaValidatorResult = z.output<typeof InternalSchemaValidatorResultSchema>;
