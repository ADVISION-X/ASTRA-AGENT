import type { AiChildCapability, AiChildContract } from "../../contract.js";
import { AI_ABILITY_GROUP_ID } from "../../contract.js";
import { executeAiChild } from "../../runtime/ai-executor.js";
import { AiChildReadinessSchema } from "../../schema.js";
import { PaidAnalysisAiInputSchema, PaidAnalysisAiResultSchema } from "./schema.js";

export function createPaidAnalysisAiCapability(): AiChildCapability {
  const contract: AiChildContract = {
    abilityGroupId: AI_ABILITY_GROUP_ID,
    childCapabilityId: "paid-analysis-ai",
    providerKind: "paid",
    supportedTaskTypes: ["evidence_packet_analysis"] as const,
    modelRole: "future",
    runtimeOwner: "ai-executor" as const,
    implementationStatus: "disabled_by_policy",
    purpose: "Reserved paid analysis path that remains governed-disabled.",
  };

  return {
    contract,
    implementation: {
      async execute(input, context) {
        return PaidAnalysisAiResultSchema.parse(await executeAiChild({
          request: PaidAnalysisAiInputSchema.parse(input),
          childContract: contract,
          context,
        }));
      },
      async checkReadiness() {
        return AiChildReadinessSchema.parse({
          abilityGroupId: "ai",
          childCapabilityId: "paid-analysis-ai",
          providerKind: "paid",
          status: "disabled_by_policy",
          supportedTaskTypes: [...contract.supportedTaskTypes],
          detail: "paid analysis provider is declared but disabled by policy.",
          enabledByPolicy: false,
        });
      },
    },
  };
}
