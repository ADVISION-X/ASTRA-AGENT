import type { z } from "zod";

import { PaidAnalysisAiInputSchema, PaidAnalysisAiResultSchema } from "../../schema.js";

export type PaidAnalysisAiInput = z.output<typeof PaidAnalysisAiInputSchema>;
export type PaidAnalysisAiResult = z.output<typeof PaidAnalysisAiResultSchema>;
