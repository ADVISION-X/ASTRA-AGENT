import type { AiChildCapability, AiChildContract } from "../../contract.js";
import { AI_ABILITY_GROUP_ID } from "../../contract.js";
import { executeAiChild } from "../../runtime/ai-executor.js";
import { AiChildReadinessSchema } from "../../schema.js";
import { LocalTextAiInputSchema, LocalTextAiResultSchema } from "./schema.js";

export function createLocalTextAiCapability(): AiChildCapability {
  const contract: AiChildContract = {
    abilityGroupId: AI_ABILITY_GROUP_ID,
    childCapabilityId: "local-text-ai",
    providerKind: "local",
    supportedTaskTypes: ["comment_signal_summary", "product_signal_summary"] as const,
    modelRole: "multi-role",
    runtimeOwner: "ai-executor" as const,
    implementationStatus: "local_runtime",
    purpose: "Run local governed text cognition through ai-executor.",
  };

  return {
    contract,
    implementation: {
      async execute(input, context) {
        return LocalTextAiResultSchema.parse(await executeAiChild({
          request: LocalTextAiInputSchema.parse(input),
          childContract: contract,
          context,
        }));
      },
      async checkReadiness(context) {
        const [health, roster] = await Promise.all([context.runtime.getRuntimeHealth(), context.modelRoster.load(context.clock)]);
        const entry = roster.entries.find((item) => item.childCapabilityId === "local-text-ai");
        return AiChildReadinessSchema.parse({
          abilityGroupId: "ai",
          childCapabilityId: "local-text-ai",
          providerKind: "local",
          status: health.dependencies.text === "ready" ? "ready" : "unavailable",
          supportedTaskTypes: [...contract.supportedTaskTypes],
          detail: `text=${health.dependencies.text}; models=${entry?.modelOrTool ?? "unknown"}`,
          enabledByPolicy: true,
        });
      },
    },
  };
}
