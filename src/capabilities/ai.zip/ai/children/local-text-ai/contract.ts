import type { z } from "zod";

import { LocalTextAiInputSchema, LocalTextAiResultSchema } from "../../schema.js";

export type LocalTextAiInput = z.output<typeof LocalTextAiInputSchema>;
export type LocalTextAiResult = z.output<typeof LocalTextAiResultSchema>;
