import type { AiExecutionContext, AiTaskType, ParsedAiAbilityInput } from "../contract.js";
import { AiInputSchema } from "../schema.js";
import { buildNonAuthoritativeOutput } from "../shared/ai-output.js";
import { buildAiResult } from "./ai-result-builder.js";

function buildFallbackRequest(taskType: AiTaskType, childCapabilityId: Parameters<typeof buildAiResult>[0]["childContract"]["childCapabilityId"], context: AiExecutionContext): ParsedAiAbilityInput {
  const promptContract = context.promptRegistry.resolvePromptContract(taskType);
  const common = {
    abilityGroupId: "ai",
    inputRefs: [],
    promptContractId: promptContract.promptId,
    requestedBy: "orchestration",
    transportedBy: "nerve-bus",
    sessionId: "invalid-session",
    roundId: null,
    videoVisitId: null,
    qualityPolicy: { minimumConfidence: 0.6, requireSchemaValidation: true },
    providerPolicy: { requireLocalOnly: true, allowPaidProvider: false, providerAllowlist: [childCapabilityId], operatorApprovalRef: null },
    costPolicy: { maxEstimatedCost: 0 },
    dataPolicy: { allowExternalTransmission: false, redactSensitiveData: true },
    safetyPolicy: { reviewOnLowConfidence: true, reviewOnSchemaFailure: true, reviewOnPolicyViolation: true },
  };

  switch (taskType) {
    case "product_presence_judgment":
    case "visual_observation":
    case "visual_target_candidate_analysis":
      return AiInputSchema.parse({
        ...common,
        taskType,
        inputModality: "image_collection",
        expectedOutputSchema: `ai.${taskType}.v1`,
        input: {
          inputMode: "single_frame_fallback",
          multiFrameEvidenceSetId: null,
          contactSheetEvidenceId: null,
          frameEvidenceIds: [],
          screenshotEvidenceId: null,
          screenshotRegion: null,
          sourceUrl: "invalid://input",
          samplingStrategy: "single_frame_fallback",
          sampledFrameCount: 1,
          validFrameCount: 0,
          expectedFrameCount: 1,
          fallbackReason: "invalid input",
          missingFrames: [],
          summary: "invalid input",
          tags: [],
        },
      });
    case "ocr_cleanup":
      return AiInputSchema.parse({
        ...common,
        taskType,
        inputModality: "text_blocks",
        expectedOutputSchema: "ai.ocr_cleanup.v1",
        input: { rawCommentBlocks: [] },
      });
    case "comment_signal_summary":
      return AiInputSchema.parse({
        ...common,
        taskType,
        inputModality: "text_blocks",
        expectedOutputSchema: "ai.comment_signal_summary.v1",
        input: { cleanedComments: ["invalid"] },
      });
    case "product_signal_summary":
      return AiInputSchema.parse({
        ...common,
        taskType,
        inputModality: "structured_record",
        expectedOutputSchema: "ai.product_signal_summary.v1",
        input: {
          videoSummary: "invalid",
          productPresence: buildNonAuthoritativeOutput("product_presence_judgment", "invalid input"),
          commentSignals: buildNonAuthoritativeOutput("comment_signal_summary", "invalid input"),
        },
      });
    case "evidence_packet_analysis":
      return AiInputSchema.parse({
        ...common,
        taskType,
        inputModality: "structured_record",
        expectedOutputSchema: "ai.evidence_packet_analysis.v1",
        input: { packetSummary: "invalid", evidenceIds: ["invalid"], notes: [] },
      });
    case "schema_validation_only":
      return AiInputSchema.parse({
        ...common,
        taskType,
        inputModality: "structured_record",
        expectedOutputSchema: "ai.schema_validation_only.v1",
        input: { candidate: null },
      });
  }
}

export function dispatchAiFailure(input: {
  rawInput: unknown;
  context: AiExecutionContext;
  childCapabilityId: Parameters<typeof buildAiResult>[0]["childContract"]["childCapabilityId"];
  taskType: AiTaskType;
  failureReason: string;
  statusMessage: string;
}) {
  const started = input.context.clock.startRun();
  const ended = input.context.clock.finishRun(started);
  const parsed = AiInputSchema.safeParse(input.rawInput);
  const fallbackRequest = parsed.success ? parsed.data : buildFallbackRequest(input.taskType, input.childCapabilityId, input.context);
  const promptContract = input.context.promptRegistry.resolvePromptContract(fallbackRequest.taskType);

  return buildAiResult({
    request: fallbackRequest,
    childContract: {
      abilityGroupId: "ai",
      childCapabilityId: input.childCapabilityId,
      providerKind: "local",
      supportedTaskTypes: [fallbackRequest.taskType],
      modelRole: promptContract.modelRole,
      runtimeOwner: "ai-executor",
      implementationStatus: "dispatch_failure",
      purpose: input.statusMessage,
    },
    promptContract,
    status: "failed",
    modelProvider: fallbackRequest.taskType === "schema_validation_only" ? "internal" : "local",
    modelName: "unavailable",
    modelRole: promptContract.modelRole,
    runtime: "ai-dispatch-failure",
    implementationStatus: "dispatch_failure",
    outputAuthority: "non_authoritative",
    output: buildNonAuthoritativeOutput(fallbackRequest.taskType, input.statusMessage),
    rawOutputRef: null,
    schemaValidationStatus: "invalid",
    confidence: null,
    failureReason: input.failureReason,
    reviewRequiredReason: null,
    costEstimate: null,
    createdAt: ended.endedAt,
    started,
    ended,
    providerDecision: "blocked",
    dataPolicyDecision: "not_applicable",
    costPolicyDecision: "not_applicable",
    safetyPolicyDecision: "allow",
    schemaDecision: "blocked",
    qualityDecision: "blocked",
    outputBoundaryDecision: "allow",
    disabledProviderDecision: "not_applicable",
    dataQualityFlags: [input.statusMessage],
  });
}
