import { collectForbiddenActionTerms } from "../shared/ai-policy.js";

export function evaluateAiOutputBoundary(output: unknown): { decision: "allow" | "review_required" | "blocked"; reason: string | null; flags: string[] } {
  const flags = collectForbiddenActionTerms(output);
  if (flags.length === 0) {
    return { decision: "allow", reason: null, flags: [] };
  }

  return {
    decision: "blocked",
    reason: "output_boundary_blocked",
    flags,
  };
}
