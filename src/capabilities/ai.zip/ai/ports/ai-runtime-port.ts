import type { AiAbilityInput, AiRuntimeExecutionOutput, AiRuntimeHealth } from "../contract.js";

export interface AiRuntimePort {
  execute(request: AiAbilityInput): Promise<AiRuntimeExecutionOutput>;
  getHealth(): Promise<{ ok: boolean; detail: string; health: AiRuntimeHealth }>;
  getRuntimeHealth(): Promise<AiRuntimeHealth>;
}
