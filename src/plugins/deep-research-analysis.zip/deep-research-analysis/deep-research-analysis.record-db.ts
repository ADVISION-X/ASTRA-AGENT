import { mkdirSync } from "node:fs";
import path from "node:path";

import Database from "better-sqlite3";

import { createId } from "../../lib/local-runtime/ids.js";
import {
    DEEP_RESEARCH_ANALYSIS_DB_RELATIVE_PATH,
    MISSING_RENDERED_PROMPT_TEXT
} from "./deep-research-analysis.records.js";
export {
    mapAnswerRow,
    mapExportRow,
    mapFinalAdjudicationRow,
    mapInteractionRow,
    mapJobRow,
    mapResearchPlanRow,
    mapSubQuestionRow
} from "./deep-research-analysis.record-db-mappers.js";

const DEEP_RESEARCH_ANALYSIS_SCHEMA_SQL = [
  `CREATE TABLE IF NOT EXISTS research_jobs (
    id TEXT PRIMARY KEY,
    user_question TEXT NOT NULL,
    analysis_goal TEXT,
    language TEXT NOT NULL,
    max_sub_questions INTEGER NOT NULL,
    output_format TEXT NOT NULL,
    status TEXT NOT NULL,
    phase TEXT NOT NULL,
    failure_reason TEXT,
    review_reason TEXT,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
  )`,
  `CREATE TABLE IF NOT EXISTS research_sub_questions (
    id TEXT PRIMARY KEY,
    job_id TEXT NOT NULL,
    interaction_id TEXT NOT NULL,
    model_question_id TEXT NOT NULL,
    ordinal INTEGER NOT NULL,
    title TEXT NOT NULL,
    question_text TEXT NOT NULL,
    purpose TEXT NOT NULL,
    why_it_matters TEXT,
    decision_weight TEXT,
    analysis_focus TEXT,
    required_evidence_json TEXT NOT NULL DEFAULT '[]',
    scope TEXT NOT NULL,
    expected_answer_shape TEXT NOT NULL,
    priority TEXT,
    omission_risk TEXT,
    prompt_bundle_json TEXT NOT NULL DEFAULT '{}',
    created_at TEXT NOT NULL,
    UNIQUE(job_id, model_question_id),
    UNIQUE(job_id, ordinal)
  )`,
  `CREATE TABLE IF NOT EXISTS research_plans (
    id TEXT PRIMARY KEY,
    job_id TEXT NOT NULL UNIQUE,
    interaction_id TEXT NOT NULL,
    research_plan_json TEXT NOT NULL,
    plan_hash TEXT NOT NULL,
    created_at TEXT NOT NULL
  )`,
  `CREATE TABLE IF NOT EXISTS research_interactions (
    id TEXT PRIMARY KEY,
    job_id TEXT NOT NULL,
    phase TEXT NOT NULL,
    sub_question_id TEXT,
    prompt_id TEXT NOT NULL,
    prompt_version TEXT NOT NULL,
    prompt_hash TEXT NOT NULL,
    rendered_prompt_text TEXT NOT NULL,
    dom_ref TEXT,
    raw_response_text TEXT NOT NULL,
    raw_response_hash TEXT NOT NULL,
    normalized_text TEXT,
    parse_status TEXT NOT NULL,
    provider_kind TEXT,
    provider_proof_json TEXT,
    created_at TEXT NOT NULL
  )`,
  `CREATE TABLE IF NOT EXISTS research_answers (
    id TEXT PRIMARY KEY,
    job_id TEXT NOT NULL,
    interaction_id TEXT NOT NULL,
    sub_question_id TEXT NOT NULL,
    answer_kind TEXT NOT NULL,
    answer_text TEXT NOT NULL,
    key_points_json TEXT NOT NULL,
    evidence_mentions_json TEXT NOT NULL,
    assumptions_json TEXT NOT NULL,
    limitations_json TEXT NOT NULL,
    contradiction_points_json TEXT NOT NULL,
    parsed_payload_json TEXT NOT NULL DEFAULT '{}',
    created_at TEXT NOT NULL
  )`,
  `CREATE TABLE IF NOT EXISTS research_final_adjudications (
    id TEXT PRIMARY KEY,
    job_id TEXT NOT NULL,
    interaction_id TEXT NOT NULL,
    prompt_id TEXT NOT NULL,
    prompt_version TEXT NOT NULL,
    raw_final_answer_text TEXT NOT NULL,
    raw_response_hash TEXT NOT NULL,
    preferred_format TEXT NOT NULL,
    parsed_json_index_json TEXT,
    parse_status TEXT NOT NULL,
    prompt_bundle_snapshot_json TEXT NOT NULL,
    created_at TEXT NOT NULL
  )`,
  `CREATE TABLE IF NOT EXISTS research_exports (
    id TEXT PRIMARY KEY,
    job_id TEXT NOT NULL,
    export_kind TEXT NOT NULL,
    file_path TEXT NOT NULL,
    file_hash TEXT NOT NULL,
    payload_hash TEXT NOT NULL,
    payload_json TEXT NOT NULL DEFAULT '{}',
    created_at TEXT NOT NULL
  )`,
  `CREATE INDEX IF NOT EXISTS idx_research_sub_questions_job ON research_sub_questions(job_id, ordinal)`,
  `CREATE INDEX IF NOT EXISTS idx_research_interactions_job ON research_interactions(job_id, created_at)`,
  `CREATE INDEX IF NOT EXISTS idx_research_answers_job ON research_answers(job_id, answer_kind, created_at)`,
  `CREATE INDEX IF NOT EXISTS idx_research_exports_job ON research_exports(job_id, export_kind, created_at)`,
] as const;

export const getCurrentTimestamp = (): string => new Date().toISOString();

type SqliteColumnInfo = {
  name: string;
};

type PreviousSchemaSubQuestionRow = {
  id: string;
  job_id: string;
  interaction_id: string;
  ordinal: number;
  title: string;
  question_text: string;
  purpose: string;
  scope: string;
  expected_answer_shape: string;
  created_at: string;
};

const hasColumn = (
  db: Database.Database,
  tableName: string,
  columnName: string,
): boolean =>
  (db.prepare(`PRAGMA table_info(${tableName})`).all() as SqliteColumnInfo[])
    .some((column) => column.name === columnName);

const listPreviousSchemaSubQuestionRows = (db: Database.Database): PreviousSchemaSubQuestionRow[] =>
  db.prepare(
    `SELECT id, job_id, interaction_id, ordinal, title, question_text, purpose, scope,
      expected_answer_shape, created_at
    FROM research_sub_questions
    ORDER BY job_id ASC, ordinal ASC`,
  ).all() as PreviousSchemaSubQuestionRow[];

const createSubQuestionsV2Table = (db: Database.Database): void => {
  db.exec(`
    CREATE TABLE research_sub_questions_v2 (
      id TEXT PRIMARY KEY,
      job_id TEXT NOT NULL,
      interaction_id TEXT NOT NULL,
      model_question_id TEXT NOT NULL,
      ordinal INTEGER NOT NULL,
      title TEXT NOT NULL,
      question_text TEXT NOT NULL,
      purpose TEXT NOT NULL,
      why_it_matters TEXT,
      decision_weight TEXT,
      analysis_focus TEXT,
      required_evidence_json TEXT NOT NULL DEFAULT '[]',
      scope TEXT NOT NULL,
      expected_answer_shape TEXT NOT NULL,
       priority TEXT,
       omission_risk TEXT,
      prompt_bundle_json TEXT NOT NULL DEFAULT '{}',
       created_at TEXT NOT NULL,
      UNIQUE(job_id, model_question_id),
      UNIQUE(job_id, ordinal)
    )
  `);
};

const copyPreviousSchemaSubQuestionRows = (
  db: Database.Database,
  previousSchemaRows: readonly PreviousSchemaSubQuestionRow[],
): Map<string, string> => {
  const insert = db.prepare(
    `INSERT INTO research_sub_questions_v2 (
      id, job_id, interaction_id, model_question_id, ordinal, title, question_text,
      purpose, why_it_matters, decision_weight, analysis_focus, required_evidence_json,
      scope, expected_answer_shape, priority, omission_risk, prompt_bundle_json, created_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
  );
  const idRemap = new Map<string, string>();
  for (const row of previousSchemaRows) {
    const systemId = createId("deep_research_sub_question");
    idRemap.set(`${row.job_id}\u0000${row.id}`, systemId);
    insert.run(
      systemId,
      row.job_id,
      row.interaction_id,
      row.id,
      row.ordinal,
      row.title,
      row.question_text,
      row.purpose,
      null,
      null,
      null,
      "[]",
      row.scope,
      row.expected_answer_shape,
      null,
      null,
      "{}",
      row.created_at,
    );
  }
  return idRemap;
};

const remapSubQuestionReferences = (
  db: Database.Database,
  previousSchemaRows: readonly PreviousSchemaSubQuestionRow[],
  idRemap: ReadonlyMap<string, string>,
): void => {
  const updateInteractions = db.prepare(
    `UPDATE research_interactions SET sub_question_id = ? WHERE job_id = ? AND sub_question_id = ?`,
  );
  const updateAnswers = db.prepare(
    `UPDATE research_answers SET sub_question_id = ? WHERE job_id = ? AND sub_question_id = ?`,
  );
  for (const row of previousSchemaRows) {
    const systemId = idRemap.get(`${row.job_id}\u0000${row.id}`);
    if (!systemId) continue;
    updateInteractions.run(systemId, row.job_id, row.id);
    updateAnswers.run(systemId, row.job_id, row.id);
  }
};

const migrateResearchSubQuestionsSchema = (db: Database.Database): void => {
  if (hasColumn(db, "research_sub_questions", "model_question_id")) return;
  const previousSchemaRows = listPreviousSchemaSubQuestionRows(db);
  const migrate = db.transaction(() => {
    createSubQuestionsV2Table(db);
    const idRemap = copyPreviousSchemaSubQuestionRows(db, previousSchemaRows);
    remapSubQuestionReferences(db, previousSchemaRows, idRemap);
    db.exec("DROP TABLE research_sub_questions");
    db.exec("ALTER TABLE research_sub_questions_v2 RENAME TO research_sub_questions");
  });
  migrate();
};

const migrateResearchInteractionsRenderedPromptText = (db: Database.Database): void => {
  if (!hasColumn(db, "research_interactions", "rendered_prompt_text")) {
    db.exec("ALTER TABLE research_interactions ADD COLUMN rendered_prompt_text TEXT");
  }
  db.prepare(
    `UPDATE research_interactions
     SET rendered_prompt_text = ?
     WHERE rendered_prompt_text IS NULL OR trim(rendered_prompt_text) = ''`,
  ).run(MISSING_RENDERED_PROMPT_TEXT);
};

const migrateResearchSubQuestionStructuredFields = (db: Database.Database): void => {
  if (!hasColumn(db, "research_sub_questions", "why_it_matters")) {
    db.exec("ALTER TABLE research_sub_questions ADD COLUMN why_it_matters TEXT");
  }
  if (!hasColumn(db, "research_sub_questions", "decision_weight")) {
    db.exec("ALTER TABLE research_sub_questions ADD COLUMN decision_weight TEXT");
  }
  if (!hasColumn(db, "research_sub_questions", "analysis_focus")) {
    db.exec("ALTER TABLE research_sub_questions ADD COLUMN analysis_focus TEXT");
  }
  if (!hasColumn(db, "research_sub_questions", "required_evidence_json")) {
    db.exec("ALTER TABLE research_sub_questions ADD COLUMN required_evidence_json TEXT NOT NULL DEFAULT '[]'");
  }
  if (!hasColumn(db, "research_sub_questions", "priority")) {
    db.exec("ALTER TABLE research_sub_questions ADD COLUMN priority TEXT");
  }
  if (!hasColumn(db, "research_sub_questions", "omission_risk")) {
    db.exec("ALTER TABLE research_sub_questions ADD COLUMN omission_risk TEXT");
  }
  if (!hasColumn(db, "research_sub_questions", "prompt_bundle_json")) {
    db.exec("ALTER TABLE research_sub_questions ADD COLUMN prompt_bundle_json TEXT NOT NULL DEFAULT '{}'");
  }
  db.prepare(
    `UPDATE research_sub_questions
     SET required_evidence_json = '[]'
     WHERE required_evidence_json IS NULL OR trim(required_evidence_json) = ''`,
  ).run();
  db.prepare(
    `UPDATE research_sub_questions
     SET prompt_bundle_json = '{}'
     WHERE prompt_bundle_json IS NULL OR trim(prompt_bundle_json) = ''`,
  ).run();
};

const migrateResearchAnswersParsedPayload = (db: Database.Database): void => {
  if (!hasColumn(db, "research_answers", "parsed_payload_json")) {
    db.exec("ALTER TABLE research_answers ADD COLUMN parsed_payload_json TEXT NOT NULL DEFAULT '{}' ");
  }
  db.prepare(
    `UPDATE research_answers
     SET parsed_payload_json = '{}'
     WHERE parsed_payload_json IS NULL OR trim(parsed_payload_json) = ''`,
  ).run();
};

const migrateResearchAnswersRemoveConfidence = (db: Database.Database): void => {
  if (!hasColumn(db, "research_answers", "confidence")) {
    return;
  }
  const migrate = db.transaction(() => {
    db.exec(`
      CREATE TABLE research_answers_v2 (
        id TEXT PRIMARY KEY,
        job_id TEXT NOT NULL,
        interaction_id TEXT NOT NULL,
        sub_question_id TEXT NOT NULL,
        answer_kind TEXT NOT NULL,
        answer_text TEXT NOT NULL,
        key_points_json TEXT NOT NULL,
        evidence_mentions_json TEXT NOT NULL,
        assumptions_json TEXT NOT NULL,
        limitations_json TEXT NOT NULL,
        contradiction_points_json TEXT NOT NULL,
        parsed_payload_json TEXT NOT NULL DEFAULT '{}',
        created_at TEXT NOT NULL
      )
    `);
    db.exec(`
      INSERT INTO research_answers_v2 (
        id, job_id, interaction_id, sub_question_id, answer_kind, answer_text,
        key_points_json, evidence_mentions_json, assumptions_json, limitations_json,
        contradiction_points_json, parsed_payload_json, created_at
      )
      SELECT
        id, job_id, interaction_id, sub_question_id, answer_kind, answer_text,
        key_points_json, evidence_mentions_json, assumptions_json, limitations_json,
        contradiction_points_json, parsed_payload_json, created_at
      FROM research_answers
    `);
    db.exec("DROP TABLE research_answers");
    db.exec("ALTER TABLE research_answers_v2 RENAME TO research_answers");
  });
  migrate();
};

const migrateResearchExportsPayloadJson = (db: Database.Database): void => {
  if (!hasColumn(db, "research_exports", "payload_json")) {
    db.exec("ALTER TABLE research_exports ADD COLUMN payload_json TEXT NOT NULL DEFAULT '{}' ");
  }
  db.prepare(
    `UPDATE research_exports
     SET payload_json = '{}'
     WHERE payload_json IS NULL OR trim(payload_json) = ''`,
  ).run();
};

const pruneResearchExportKindsSingleFlow = (db: Database.Database): void => {
  db.prepare(
    `DELETE FROM research_exports
     WHERE export_kind NOT IN (
       'final-adjudication-raw.md',
       'full-case-file.md',
       'full-case-file.json',
       'structured-index.json',
       'business-report.html',
       'evidence-index.json'
     )`,
  ).run();
};

export const resolveDeepResearchDbPath = (dataDir: string): string =>
  path.join(dataDir, DEEP_RESEARCH_ANALYSIS_DB_RELATIVE_PATH);

export const createDeepResearchDatabase = (dataDir: string): Database.Database => {
  const dbPath = resolveDeepResearchDbPath(dataDir);
  mkdirSync(path.dirname(dbPath), { recursive: true });
  const db = new Database(dbPath);
  db.pragma("journal_mode = WAL");
  db.pragma("synchronous = NORMAL");
  for (const statement of DEEP_RESEARCH_ANALYSIS_SCHEMA_SQL) {
    db.exec(statement);
  }
  migrateResearchSubQuestionsSchema(db);
  migrateResearchInteractionsRenderedPromptText(db);
  migrateResearchSubQuestionStructuredFields(db);
  migrateResearchAnswersParsedPayload(db);
  migrateResearchAnswersRemoveConfidence(db);
  migrateResearchExportsPayloadJson(db);
  pruneResearchExportKindsSingleFlow(db);
  for (const statement of DEEP_RESEARCH_ANALYSIS_SCHEMA_SQL) {
    db.exec(statement);
  }
  return db;
};
